<?php
require '../database/db_conn.php';

// Get the current month and year
$currentMonth = date('m');
$currentYear = date('Y');

// Calculate the overall total sales for the month
$totalSalesQuery = "
    SELECT SUM(total_price) AS overall_total_sales
    FROM sales
    WHERE MONTH(ordered_at) = :month AND YEAR(ordered_at) = :year
";

$totalSalesStmt = $conn->prepare($totalSalesQuery);
$totalSalesStmt->bindValue(':month', $currentMonth, PDO::PARAM_INT);
$totalSalesStmt->bindValue(':year', $currentYear, PDO::PARAM_INT);
$totalSalesStmt->execute();

$totalSalesRow = $totalSalesStmt->fetch(PDO::FETCH_ASSOC);
$overallTotalSales = $totalSalesRow['overall_total_sales'];

// Fetch top 10 products for the current month
$topProductsQuery = "
    SELECT prod_id, prod_name, SUM(total_price) AS total_sold
    FROM sales
    WHERE MONTH(ordered_at) = :month AND YEAR(ordered_at) = :year
    GROUP BY prod_id, prod_name
    ORDER BY total_sold DESC
    LIMIT 10
";

$topProductsStmt = $conn->prepare($topProductsQuery);
$topProductsStmt->bindValue(':month', $currentMonth, PDO::PARAM_INT);
$topProductsStmt->bindValue(':year', $currentYear, PDO::PARAM_INT);
$topProductsStmt->execute();

$products = [];
while ($row = $topProductsStmt->fetch(PDO::FETCH_ASSOC)) {
    $percentage = ($overallTotalSales > 0) ? ($row['total_sold'] / $overallTotalSales) * 100 : 0;
    $row['percentage_of_total'] = round($percentage, 2); // Round to 2 decimal places
    $products[] = $row;
}

// Return the results as JSON
echo json_encode($products);