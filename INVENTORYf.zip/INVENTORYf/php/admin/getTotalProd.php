<?php
require '../database/db_conn.php';


// SQL query to fetch the count of products
$sql = "SELECT COUNT(*) as prod_count FROM products";
$stmt = $conn->prepare($sql);
$stmt->execute();

// Fetching the product count
$productCount = $stmt->fetch(PDO::FETCH_ASSOC);

// Close the connection
$conn = null;

// Convert the result to JSON
$jsonData = json_encode($productCount, JSON_PRETTY_PRINT);

echo $jsonData;
