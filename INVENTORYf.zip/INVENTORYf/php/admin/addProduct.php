<?php
require '../database/db_conn.php';

// Function to insert a new product
function insertProduct($conn, $data) {
    // Extract data from the passed array
    extract($data);

    // Prepare the SQL statement for inserting
    $sql = "INSERT INTO products (barcode, prod_name, prod_price, prod_image, prod_qty) VALUES (:barcode, :prod_name, :prod_price, :prod_image, :prod_qty)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':barcode', $barcode);
    $stmt->bindParam(':prod_name', $prod_name);
    $stmt->bindParam(':prod_price', $prod_price);
    $stmt->bindParam(':prod_image', $prod_image);
    $stmt->bindParam(':prod_qty', $prod_qty);

    if ($stmt->execute()) {
        return ['success' => true, 'message' => 'Product inserted successfully'];
    } else {
        return ['success' => false, 'message' => 'Failed to insert product'];
    }
}

// Function to insert a log entry
function insertLog($conn, $user_id, $user_name, $log_type, $log_info) {
    $logStmt = $conn->prepare("
        INSERT INTO logs (user_type, user_name, user_id, log_type, log_info) 
        VALUES (:user_type, :user_name, :user_id, :log_type, :log_info)
    ");

    $user_type = 'admin'; // Assuming the user is an admin

    $logStmt->bindParam(':user_type', $user_type);
    $logStmt->bindParam(':user_name', $user_name);
    $logStmt->bindParam(':user_id', $user_id);
    $logStmt->bindParam(':log_type', $log_type);
    $logStmt->bindParam(':log_info', $log_info);

    if (!$logStmt->execute()) {
        throw new PDOException("Failed to insert log entry");
    }
}

// Example usage:
// Assuming you have JSON data coming from a POST request
$received_data = json_decode(file_get_contents("php://input"), true); // Changed to true to get an associative array

if (!empty($received_data['prod_name']) && !empty($received_data['barcode']) && !empty($received_data['prod_price']) && !empty($received_data['prod_image']) && !empty($received_data['prod_qty'])) {
    try {
        // Insert the product
        $result = insertProduct($conn, $received_data);

        if ($result['success']) {
            // If the product insertion was successful, log the action
            session_start();
            $user_id = $_SESSION['admin_id'];
            $user_name = $_SESSION['admin_name'];
            $log_type = 'product_addition';
            $log_info = "Admin \"$admin_name\" added a product with Barcode: " . $received_data['barcode'];

            insertLog($conn, $user_id, $user_name, $log_type, $log_info);
        }

        echo json_encode($result);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => "Error: " . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Required fields are missing in the request']);
}

// Close the connection
$conn = null;