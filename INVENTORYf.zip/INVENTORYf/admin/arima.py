import pandas as pd
from statsmodels.tsa.arima.model import ARIMA
import mysql.connector

# Connect to MySQL
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="sbc_inventory"
)

cursor = db.cursor()

# Fetch historical sales data for each product
cursor.execute("SELECT prod_id, ordered_at,SUM(overall_total) AS total_sales FROM sales GROUP BY prod_name ORDER BY ordered_at")
data = cursor.fetchall()

df = pd.DataFrame(data, columns=['prod_id', 'ordered_at', 'overall_total'])

# Generate ARIMA predictions for each product
for product_id in df['prod_id'].unique():
    product_data = df[df['prod_id'] == product_id].set_index('ordered_at')['overall_total']

    # ARIMA model fitting
    model = ARIMA(product_data, order=(5, 1, 0))
    model_fit = model.fit()

    # Forecasting the next period (for example, 30 days)
    forecast = model_fit.forecast(steps=30)

    # Store the forecast back into the database
    for date, prediction in enumerate(forecast):
        cursor.execute(
            "INSERT INTO product_forecast (prod_id, forecast_date, forecast_value) VALUES (%s, %s, %s)",
            (product_id, date, prediction)
        )
    db.commit()
