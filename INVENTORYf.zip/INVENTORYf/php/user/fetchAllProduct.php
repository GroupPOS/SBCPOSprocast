<?php
require '../database/db_conn.php';


// SQL query to fetch orders
$sql = "SELECT p.*, 
            COALESCE(AVG(r.prod_rate), 0) AS average_rating, 
            COUNT(r.id) AS rating_count
        FROM products p
        LEFT JOIN ratings r ON p.prod_id = r.prod_id
        WHERE p.status = 'live' 
        GROUP BY p.prod_id
        ORDER BY p.prod_name;
        " ;

$stmt = $conn->prepare($sql);
$stmt->execute();

// Fetching orders
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Close the connection
$conn = null;

// Convert the aggregated data to JSON
$jsonData = json_encode($orders);

echo $jsonData;
