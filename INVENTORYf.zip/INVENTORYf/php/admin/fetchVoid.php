<?php
require '../database/db_conn.php';

// SQL query to fetch orders
$sql = "SELECT * FROM void" ;
$stmt = $conn->prepare($sql);
$stmt->execute();

// Fetching orders
$sales = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Close the connection
$conn = null;

// Convert the aggregated data to JSON
$jsonData = json_encode($sales);

echo $jsonData;
