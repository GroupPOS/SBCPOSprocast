<?php
require '../database/db_conn.php';


session_start();

$received_data = json_decode(file_get_contents("php://input"));
$order_id = $received_data->order_id;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        // Begin transaction
        $conn->beginTransaction();

        // Update the order status to 'cancelled'
        $query = "UPDATE orders SET status = 'cancelled' WHERE order_id = :order_id";
        $stmt = $conn->prepare($query);
        $stmt->bindValue(':order_id', $order_id, PDO::PARAM_INT);

        if ($stmt->execute()) {
            // Commit the transaction for order status update
            $conn->commit();

            // Insert log entry for order cancellation
            $logStmt = $conn->prepare("
                INSERT INTO logs (user_type, user_name, user_id, log_type, log_info) 
                VALUES (:user_type, :user_name, :user_id, :log_type, :log_info)
            ");

            $user_id = $_SESSION['user_id'];
            $user_name = $_SESSION['user_name'];
            $user_type = 'user';
            $log_type = 'order_cancellation';
            $log_info = $user_name . " cancelled Order ID: " . $order_id;

            $logStmt->bindParam(':user_type', $user_type);
            $logStmt->bindParam(':user_name', $user_name);
            $logStmt->bindParam(':user_id', $user_id);
            $logStmt->bindParam(':log_type', $log_type);
            $logStmt->bindParam(':log_info', $log_info);

            if ($logStmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'Order cancelled and log created']);
            } else {
                echo json_encode(['success' => true, 'message' => 'Order cancelled but log creation failed']);
            }
        } else {
            $conn->rollBack();
            echo json_encode(['success' => false, 'message' => 'Failed to cancel order']);
        }
    } catch (PDOException $e) {
        $conn->rollBack();
        echo json_encode(['success' => false, 'message' => "Error: " . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>
