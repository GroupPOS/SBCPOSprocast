<?php
require '../database/db_conn.php';


$received_data = json_decode(file_get_contents("php://input"));
$username = $received_data->username;
$password = $received_data->password;



// SQL query to fetch orders
$sql = "SELECT * FROM void  WHERE user_name = '$username' AND password = '$password'" ;
$stmt = $conn->prepare($sql);
$stmt->execute();


// Fetching orders
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

if($orders){
    $data = array(
        "status" => "success",
        "message" => "Orders fetched successfully",
    );
}else{
    $data = array(
        "status" => "error",
        "message" => "No orders found",
    );
}
// Close the connection
$conn = null;

// Convert the aggregated data to JSON
$jsonData = json_encode($data);

echo $jsonData;
