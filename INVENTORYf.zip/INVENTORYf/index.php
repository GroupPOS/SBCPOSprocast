<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" type="image/x-icon" href="../assets/sbc_icon.gif">
  <title>Login & Registration Form</title>
  <link rel="stylesheet" href="./css/login.css">
</head>
<style>
  .modal {
    display: none; 
    position: fixed; 
    z-index: 1; 
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.5); /* Dark background with a bit more transparency */
  }

  .modal-content {
    background-color: #fff;
    margin:0 auto;
    margin-top:100px; 
    padding: 30px;
    border-radius: 10px;
    width: 80%; 
    max-width: 600px;
    height: 80%;
    overflow-y: auto; 
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1); /* Adds a subtle shadow */
    font-family: 'Arial', sans-serif;
  }

  .close {
    color: #333;
    float: right;
    font-size: 24px;
    font-weight: bold;
    cursor: pointer;
  }

  .close:hover,
  .close:focus {
    color: #1167b1;
    text-decoration: none;
  }

  h2 {
    text-align: center;
    color: #1167b1;
    font-size: 24px;
    margin-bottom: 20px;
  }

  p, ul {
    font-size: 16px;
    color: #444;
    line-height: 1.6;
  }

  ul {
    margin-left: 20px;
  }

  ul li {
    margin-bottom: 10px;
  }

  ul li::marker {
    color: #1167b1;
  }
  
  /* Button Style */
  button {
    background-color: #1167b1;
    color: white;
    border: none;
    padding: 10px 20px;
    font-size: 16px;
    border-radius: 5px;
    cursor: pointer;
    display: block;
    margin: 0 auto;
  }

  button:hover {
    background-color: #0d4d7a;
  }
</style>

<body>
  <div id="app">
    <!-- Policy Modal -->
    <div id="policyModal" class="modal">
     <div class="modal-content">
       <span class="close">&times;</span>
       <h2>Policy Statement</h2>
       <p>At <b>Edu Hub, a division of St. Bridget Colleges</b>, we are dedicated to ensuring the security and protection of all educational and administrative information assets. We are committed to safeguarding our digital and physical resources from unauthorized access, disclosure, alteration, or destruction to maintain a safe and trustworthy environment for students, faculty, and staff.</p>
       <br>
       <p><strong>Our security objectives are:</strong></p>
       <ul>
         <li>Protect sensitive academic and institutional information from unauthorized access.</li>
         <li>Ensure that data remains accurate, reliable, and untampered.</li>
         <li>Guarantee that information and systems are accessible to authorized users when required.</li>
         <li>Adhere to relevant legal, regulatory, and institutional security obligations.</li>
         <li>Regularly evaluate and enhance our security practices to respond to emerging risks and challenges.</li>
       </ul>
       <br>
       <p><strong>To achieve these objectives, Edu Hub will:</strong></p>
       <ul>
         <li>Provide continuous security training and awareness programs for all faculty, staff, and students.</li>
         <li>Implement robust access control measures, ensuring that only authorized personnel can access sensitive information.</li>
         <li>Regularly update systems and apply security patches to protect against vulnerabilities.</li>
         <li>Conduct regular security audits, risk assessments, and vulnerability checks.</li>
         <li>Respond promptly to any security incidents to minimize impact and restore services effectively.</li>
       </ul>
       <br>
       <button id="closeBtn">Close</button> <!-- Added button for better UI/UX -->
     </div>
   </div>
    <div class="container">
      <input type="checkbox" id="check">
      <div class="login form">
        <header>Login</header>
        <form @submit.prevent="login">
          <input required type="text" v-model="id" placeholder="Enter your user ID">
          <div>
            <input required :type="showPassword ? 'text' : 'password'" v-model="password" placeholder="Enter your password">
            <label>
              <input type="checkbox" v-model="showPassword"> Show Password
            </label>
          </div>
          <input type="submit" class="button" value="Login">
        </form>
        <div class="signup">
          <span class="signup">Don't have an account?
            <label for="check">Sign Up</label>
          </span>
        </div>
      </div>
      <div class="registration form">
        <header>Signup Form</header>
        <form @submit.prevent="signup">
          <!-- <input required type="text" v-model="id2" placeholder="Enter your user ID (00-0000-000)"> -->
          <input
            required
            type="text"
            v-model="id2"
            placeholder="Enter your user ID (00-0000-000)"
            @input="formatUserId"
            maxlength="11" 
          >
          <p v-if="userIdError" style="color:red;">{{ userIdError }}</p>
          <input required type="text" v-model="fname" placeholder="Enter your first name">
          <input required type="text" v-model="lname" placeholder="Enter your last name">
          <div>
            <input required :type="showSignupPassword ? 'text' : 'password'" v-model="pass2" placeholder="Create a password" @input="validatePassword">
          </div>
          <p v-if="passwordError" style="color:red;">{{ passwordError }}</p>
          <div>
            <input required :type="showSignupPassword ? 'text' : 'password'" v-model="repass2" placeholder="Confirm your password" @input="checkMatch">
            <label>
              <input type="checkbox" v-model="showSignupPassword"> Show Password
            </label>
          </div>
          <p v-if="mismatch" style="color:red;">Passwords do not match!</p>

          <!-- Policy Statement -->
          <div>
            <input type="checkbox" id="policyCheck" v-model="policyAgreed" required>
            <label for="policyCheck">I agree to the <a href="#" @click.prevent="openModal">Policy Statement</a></label>
          </div>
          <input v-if="isSignupDisabled || !policyAgreed" type="button" class="button" value="Submit Request" style="background:#9999; cursor:not-allowed;" disabled>
          <input v-if="!isSignupDisabled && policyAgreed" type="submit" class="button" value="Submit">
        </form>
        <div class="signup">
          <span class="signup">Already have an account?
            <label for="check">Login</label>
          </span>
        </div>
      </div>
    </div>
  </div>

  <!-- Vue -->
  <script src="./js/vue.js"></script>
  <!-- Resources Script -->
  <script src="https://unpkg.com/axios/dist/axios.min.js"></script>

  <!-- Icons Script -->
  <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

  
    <!-- Email JS -->
    <script type="text/javascript"
            src="https://cdn.jsdelivr.net/npm/@emailjs/browser@4/dist/email.min.js">
    </script>
    <script type="text/javascript">
      (function(){
          emailjs.init({
            publicKey: "M-G9JzJGgX6s74wyi",
          });
      })();
    </script>
    <!-- Email JS -->

  <script>
      var app = new Vue({
      el: '#app', 
      data: {
        email:'',
        id: '',
        id2: '',
        password: '',
        pass2: '',
        repass2: '',
        lname: '',
        fname: '',
        mismatch: false,
        passwordError: null,
        showPassword: false,
        showSignupPassword: false,
        policyAgreed: false, // Track policy agreement
      },
      computed: {
        isSignupDisabled() {
          return this.mismatch || this.passwordError !== null || !this.policyAgreed; // Disable if policy is not agreed
        }
      },
      methods: {
        fetchEmail(){
          axios.post('./php/admin/fetchEmail.php')
              .then(response => {
                this.email = response.data[0].email;
                // console.log(this.email);
              })
              .catch(error => {
                  console.error('Error:', error);
              });
        },
        sendEmailAlert(toEmail, user_id, firstName, lastName) {
          
            const templateParams = {
                to_email: toEmail,
                user_id: user_id,
                firstName: firstName,
                lastName: lastName,
                accept_link: 'https://sbc-inventory.online/php/user/accept.php/?user_id=' + encodeURIComponent(user_id),
                decline_link: 'https://sbc-inventory.online/php/user/decline.php/?user_id=' + encodeURIComponent(user_id),
            };
            
            emailjs.send('service_j9h891q', 'template_wd4o4qi', templateParams)
            .then(response => {
                console.log('SUCCESS!', response.status, response.text);
                this.id2 = "";
                this.pass2 = "";
                this.repass2 = "";
                this.fname = "";
                this.lname = "";
                this.policyAgreed = false;
            }, error => {
                console.log('FAILED...', error);
            });
        },
        formatUserId() {
          // Remove non-numeric characters
          let rawId = this.id2.replace(/\D/g, '');

          // Insert hyphens automatically for the format 00-0000-000
          if (rawId.length > 2 && rawId.length <= 6) {
            rawId = rawId.slice(0, 2) + '-' + rawId.slice(2);
          } else if (rawId.length > 6) {
            rawId = rawId.slice(0, 2) + '-' + rawId.slice(2, 6) + '-' + rawId.slice(6, 9);
          }

          this.id2 = rawId;

          // Validate after formatting
          const userIdPattern = /^\d{2}-\d{4}-\d{3}$/;
          if (!userIdPattern.test(this.id2)) {
            this.userIdError = 'User ID must be in the format 00-0000-000';
          } else {
            this.userIdError = null; // Clear error when valid
          }
        },
        login() {
          axios.post('./php/user/login.php', {
            id: this.id,
            password: this.password,
          }).then(response => {
            console.log(response.data);
            this.id = '';
            this.password = '';
            if (response.data.login === 'yes') {
              switch (response.data.role) {
                case 'user':
                  window.location.href = './user/userDash';
                  break;
                case 'admin':
                  window.location.href = './admin/adminDash';
                  break;
                case 'staff':
                  window.location.href = './staff/staffPos';
                  break;
              }
            } else {
              alert(response.data.message);
            }
          });
        },
        signup() {
          if (!this.mismatch && !this.passwordError && this.policyAgreed) {
            axios.post('./php/user/signup.php', {
              id: this.id2,
              password: this.pass2,
              fname: this.fname,
              lname: this.lname,
            }).then(response => {
              if (response.data.signup === 'yes') {
                this.sendEmailAlert(this.email, this.id2, this.fname, this.lname);
                alert(response.data.message);
              }else{
                // console.log(response.data);
                alert(response.data.message);
                this.id2 = "";
                this.pass2 = "";
                this.repass2 = "";
                this.fname = "";
                this.lname = "";
                this.policyAgreed = false;
              }

            });
          }
        },
        checkMatch() {
          this.mismatch = this.pass2 !== this.repass2;
        },
        validatePassword() {
          this.passwordError = this.getPasswordError();
        },
        getPasswordError() {
          if (this.pass2.length < 6) {
            return 'Password must be at least 6 characters long';
          }
          if (!/[A-Z]/.test(this.pass2)) {
            return 'Password must contain at least one uppercase letter';
          }
          if (!/[a-z]/.test(this.pass2)) {
            return 'Password must contain at least one lowercase letter';
          }
          if (!/[0-9]/.test(this.pass2)) {
            return 'Password must contain at least one number';
          }
          if (!/[!@#$%^&*(),.?":{}|<>]/.test(this.pass2)) {
            return 'Password must contain at least one special character';
          }
          return null;
        },
        openModal() {
          const modal = document.getElementById("policyModal");
          const span = document.getElementsByClassName("close")[0];
          modal.style.display = "block";

          span.onclick = function() {
            modal.style.display = "none";
          }

          window.onclick = function(event) {
            if (event.target === modal) {
              modal.style.display = "none";
            }
          }
        }
      },
      created(){
        this.fetchEmail();
      }
  });
  </script>
</body>
</html>
