<?php
require '../database/db_conn.php';


$status = 'paid';

$sql = "SELECT * FROM orders  
        WHERE status = '$status'
        GROUP BY order_id
        ORDER BY ordered_at DESC
        " ;
$stmt = $conn->prepare($sql);
$stmt->execute();

// Fetching orders
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Close the connection
$conn = null;

// Convert the aggregated data to JSON
$jsonData = json_encode($orders);

echo $jsonData;
