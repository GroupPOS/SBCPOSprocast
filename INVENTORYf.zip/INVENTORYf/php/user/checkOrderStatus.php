<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

require '../database/db_conn.php';


$received_data = json_decode(file_get_contents("php://input"), true);
$order_id = $received_data['order_id'] ?? null;

if (!$order_id) {
    echo json_encode(['error' => 'Order ID required']);
    exit();
}

$query = "SELECT status FROM orders WHERE order_id = ?";
$stmt = $conn->prepare($query);

try {
    $stmt->execute([$order_id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($order) {
        echo json_encode(['status' => $order['status']]);
    } else {
        echo json_encode(['error' => 'Order not found']);
    }
} catch (PDOException $e) {
    echo json_encode(['error' => 'Query failed: ' . $e->getMessage()]);
}
