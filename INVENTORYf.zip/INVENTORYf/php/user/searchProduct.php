<?php
require '../database/db_conn.php';


// Get the search query from the request
$searchQuery = isset($_POST['query']) ? $_POST['query'] : '';

// Prepare the SQL query with a search condition
$sql = "SELECT * FROM products WHERE status = 'live' AND prod_qty > 0 AND prod_name LIKE :searchQuery ORDER BY prod_name";
$stmt = $conn->prepare($sql);

// Bind the search query parameter with wildcards for partial matching
$stmt->bindValue(':searchQuery', "%$searchQuery%", PDO::PARAM_STR);

$stmt->execute();

// Fetch the results
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Close the connection
$conn = null;

// Convert the results to JSON and output it
echo json_encode($products);
