<?php

session_start();
$received_data = json_decode(file_get_contents("php://input"));

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$errors = array();

if(isset($_FILES['image'])){
    $file_name = $_FILES['image']['name'];
    $file_size = $_FILES['image']['size'];
    $file_tmp = $_FILES['image']['tmp_name'];
    $file_type = $_FILES['image']['type'];
    $file_ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));

    // Check file size (limit to 2MB)
    if($file_size > 2097152){
        $errors[] = 'File size must be less than 2 MB';
    }

    // Proceed if no errors
    if(empty($errors)){
        // Generate a unique file name
        $unique_file_name = time().'.'. $file_ext;

        // Attempt to move the uploaded file
        if (rename($file_tmp, "../assets/images/" . $unique_file_name)) {
            // Set file permissions to make it readable by the public (0644)
            chmod("../assets/images/" . $unique_file_name, 0644);
            echo json_encode($unique_file_name);
        } else {
            $errors[] = "Failed to rename or move the file.";
        }
    } else {
        // Output any validation errors
        echo json_encode($errors);
    }
} else {
    $errors[] = "No file uploaded.";
    echo json_encode($errors);
}
// session_start();
// $received_data = json_decode(file_get_contents("php://input"));


// $errors = array();
// if(isset($_FILES['image'])){
//     $file_name = $_FILES['image']['name'];
//     $file_size =$_FILES['image']['size'];
//     $file_tmp =$_FILES['image']['tmp_name'];
//     $file_type=$_FILES['image']['type'];
//     $file_ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));

//     if($file_size > 2097152){
//         $errors[]='File size must be less than 2 MB';
//     }

//     if(empty($errors)==true){
//         $unique_file_name = time().'.'. $file_ext;
        
//         if (rename($file_tmp, "../assets/images/". $unique_file_name)) {
//             echo json_encode($unique_file_name);
//         } else {
//             $errors[] = "Failed to rename the file.";
//         }
//     }else{
//         print_r($errors);
//     }
// }
// echo json_encode( $unique_file_name );
