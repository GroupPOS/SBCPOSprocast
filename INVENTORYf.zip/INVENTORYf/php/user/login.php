<?php
session_start(); // Ensure session is started before usage
require '../database/db_conn.php';

// Receive data from the request body
$received_data = json_decode(file_get_contents("php://input"));

$data = array();
$id = $received_data->id;

if ($id && !empty($received_data->password)) {
    // Query to check if the user exists
    $query = "SELECT * FROM users WHERE user_id = :id";
    $statement = $conn->prepare($query);
    $statement->bindParam(':id', $id);
    $statement->execute();

    if ($statement->rowCount() > 0) {
        $user = $statement->fetch(PDO::FETCH_ASSOC);

        // Check if the user status is 'approved'
        if ($user['status'] !== 'approved') {
            $data = array(
                'login' => 'no',
                'message' => 'User account is not approved.',
            );
        } else {
            // Verify the password using password_verify()
            if (password_verify($received_data->password, $user['password'])) {
                // Prepare log data
                $log_type = 'login';
                $log_info = $user['firstName'] . ' ' . $user['lastName'] . ' logged in successfully.';

                // Handle user roles
                if ($user['role'] === 'user') {
                    // User login logic
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_role'] = $user['role'];
                    $_SESSION['user_name'] = $user['firstName'] . ' ' . $user['lastName'];

                    // Log login for user
                    $user_type = 'user';
                    insertLoginLog($conn, $user_type, $user['firstName'] . ' ' . $user['lastName'], $user['id'], $log_type, $log_info);

                    $data = array(
                        'login' => 'yes',
                        'message' => 'Login Success',
                        'role' => 'user'
                    );
                } else if ($user['role'] === 'admin') {
                    // Admin login logic
                    $_SESSION['admin_role'] = $user['role'];
                    $_SESSION['admin_id'] = $user['id'];
                    $_SESSION['admin_name'] = $user['firstName'] . ' ' . $user['lastName'];

                    // Log login for admin
                    $user_type = 'admin';
                    insertLoginLog($conn, $user_type, $user['firstName'] . ' ' . $user['lastName'], $user['id'], $log_type, $log_info);

                    $data = array(
                        'login' => 'yes',
                        'message' => 'Login Success',
                        'role' => 'admin'
                    );
                } else if ($user['role'] === 'staff') {
                    // Staff login logic
                    $_SESSION['staff_role'] = $user['role'];
                    $_SESSION['staff_id'] = $user['id'];
                    $_SESSION['staff_name'] = $user['firstName'] . ' ' . $user['lastName'];

                    // Log login for staff
                    $user_type = 'staff';
                    insertLoginLog($conn, $user_type, $user['firstName'] . ' ' . $user['lastName'], $user['id'], $log_type, $log_info);

                    $data = array(
                        'login' => 'yes',
                        'message' => 'Login Success',
                        'role' => 'staff'
                    );
                }
            } else {
                $data = array(
                    'login' => 'no',
                    'message' => 'Invalid company ID or Password',
                );
            }
        }
    } else {
        $data = array(
            'login' => 'no',
            'message' => 'Invalid company ID or Password',
        );
    }
} else {
    $data = array(
        'login' => 'no',
        'message' => 'Company ID and Password are required',
    );
}

echo json_encode($data);

// Function to insert login log into the logs table
function insertLoginLog($conn, $user_type, $user_name, $user_id, $log_type, $log_info) {
    try {
        $logStmt = $conn->prepare("INSERT INTO logs (user_type, user_name, user_id, log_type, log_info) VALUES (?, ?, ?, ?, ?)");
        $logStmt->execute([$user_type, $user_name, $user_id, $log_type, $log_info]);
    } catch (PDOException $e) {
        // Handle error if logging fails
        error_log('Error logging login action: ' . $e->getMessage());
    }
}
