<?php
session_start();

// Check if the session variable 'user_id' is set
if (!isset($_SESSION['user_id'])) {
  // If not set, redirect to the home page or any other page
  header("Location: ../");
  exit();
}
?>
<!DOCTYPE html>
<html class="h-100" lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="../assets/sbc_icon.gif">
  <title>Inventory | Cart</title>

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
    crossorigin="anonymous"></script>
  <!-- Bootstrap 5 -->

  <!-- CSS -->
  <link href="../css/sidebar.css" rel="stylesheet">

</head>
<style>
  .btn-square {
    width: 170px;
    height: 150px;
    text-align: center;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .rating ion-icon {
    font-size: 24px;
    cursor: pointer;
    color: #666;
    /* Default star color */
  }
  
  /* Sidebar styles */
  #sidebar {
    background-color: #1167b1;
    transition: transform 0.3s ease;
  }

  /* Initially hide the sidebar on small screens */
  @media (max-width: 768px) {
    #sidebar {
      transform: translateX(-100%);
      position: fixed;
      z-index: 999;
    }

    .sidebar-visible #sidebar {
      width: 20%;
      transform: translateX(0);
    }
    #content{
      padding:0;
      width: 100%;

    }
    .sidebar-visible #content{
      transition: transform 0.3s ease;
      margin-left: 20%;
    }
  }

  /* Hamburger icon styles */
  .hamburger {
    display: none;
  }

  @media (max-width: 400px) {
    #username{
      display: none;
    }
  }
  @media (max-width: 768px) {
    .hamburger {
      display: block;
      font-size: 1.5rem;
      cursor: pointer;
      margin-left: 5px;
      margin-right: 10px;
    }
  }

  /* Ensure content adjusts when sidebar is hidden */
  @media (max-width: 768px) {
    .content {
      padding-left: 0;
    }
  }
</style>

<body class="h-100">

  <div class="container-fluid h-100" id="app">
    <div class="row h-100">

      <!-- SIDEBAR -->
      <div class="col-md-2 col-sm-1 col-12 d-flex flex-column flex-shrink-0 h-100 p-3 text-white  position-fixed"
        style="background:#1167b1;" id="sidebar">
        <div class="d-flex justify-content-between align-items-center">
          <a href="" class="d-flex align-items-center text-white text-decoration-none">
            <ion-icon size="large" class="bi me-3 ms-2" width="40" height="32" name="happy-outline"></ion-icon>
            <span class="d-none d-md-inline fs-4">User Profile</span>
          </a>
        </div>
        <hr>
        <ul class="nav nav-pills flex-column mb-auto">
          <li class="nav-item mb-2">
            <a href="./userDash" class="nav-link text-white" aria-current="page" data-bs-toggle="tooltip"
              data-bs-placement="right" title="Home">
              <ion-icon class="bi me-2" name="home">
                <use xlink:href="#home"></use>
              </ion-icon>
              <span class="d-none d-md-inline">Home</span>
            </a>
          </li>
          <li class="mb-2">
            <a href="./userCart" class="nav-link text-white" data-bs-toggle="tooltip" data-bs-placement="right"
              title="Cart">
              <ion-icon class="bi me-2" name="cart">
                <use xlink:href="#cart"></use>
              </ion-icon>
              <span class="d-none d-md-inline">Cart</span>
            </a>
          </li>
          <li class="mb-2">
            <a href="#" class="nav-link active " data-bs-toggle="tooltip" data-bs-placement="right" title="Cart">
              <ion-icon class="bi me-2" name="newspaper">
                <use xlink:href="#cart"></use>
              </ion-icon>
              <span class="d-none d-md-inline">Transaction</span>
            </a>
          </li>
          <li class="mb-2">
            <a href="./userSettings" class="nav-link text-white" data-bs-toggle="tooltip" data-bs-placement="right"
              title="Settings">
              <ion-icon class="bi me-2" name="settings">
                <use xlink:href="#settings"></use>
              </ion-icon>
              <span class="d-none d-md-inline">Settings</span>
            </a>
          </li>
        </ul>
        <div class="mt-auto">
          <hr>
          <ul class="nav nav-pills flex-column">
            <li>
              <a href="#" @click="logout" class="nav-link text-white" data-bs-toggle="tooltip" data-bs-placement="right"
                title="Log Out">
                <ion-icon class="bi me-2" name="log-out">
                  <use xlink:href="#log-out"></use>
                </ion-icon>
                <span class="d-none d-md-inline">Log Out</span>
              </a>
            </li>
          </ul>
        </div>
      </div>
      <!-- SIDEBAR -->


      <!-- CONTENT -->
      <div class="col-md-10 col-sm-11 offset-md-2 offset-sm-1" id="content">
        <!-- Header -->
        <!-- Hamburger icon for small screens -->
        <div class="d-flex align-items-center justify-content-between p-3 bg-light">
          <div style="display:flex; width: fit-content; align-items:center;">
            <div class="hamburger"  @click="toggleSidebar">
              <ion-icon name="menu-outline"></ion-icon>
            </div>
            <div>
              <span class="fs-4 text-primary"><strong>POSProcast</strong></span>
            </div>
          </div>
          
          <div class="d-flex align-items-center">
            <span class="fs-6" id="username"><?php echo $_SESSION['user_name']; ?></span>
            <ion-icon class="ms-3" size="large" name="person-circle"></ion-icon>
          </div>
        </div>
        <!-- Header -->
        <!-- Confirmation Modal -->
        <div class="modal fade" id="confirmationModal" tabindex="-1" aria-labelledby="confirmationModalLabel"
          aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="confirmationModalLabel">Confirm Cancellation</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                Are you sure you want to cancel this order?
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal" @click="confirmCancelOrder">Yes,
                  Cancel Order</button>
              </div>
            </div>
          </div>
        </div>
        <!-- Confirmation Modal -->
        <!-- QR Code Modal -->
        <div class="modal fade" id="qrCodeModal" tabindex="-1" aria-labelledby="qrCodeModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="qrCodeModalLabel">Counter Payment QR Code</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <center>
                  <div id="qrcode"></div> <!-- QR Code will be generated here -->
                  <p class="mt-3">Present this QR code for counter payment. {{orderId}}</p>
                </center>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>
        <!-- Rating Modal -->
        <div class="modal fade" id="ratingModal" tabindex="-1" aria-labelledby="ratingModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="ratingModalLabel">Rate Products</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <div v-for="(product, index) in allDetails" :key="product.prod_id">
                  <h5>{{ product.prod_name }}</h5>
                  <div class="rating">
                    <!-- Loop through the stars -->
                    <ion-icon v-for="n in 5" :key="n" :name="n <= rating[product.prod_id] ? 'star' : 'star-outline'"
                      @click="setRating(product.prod_id, n)"
                      :style="{ color: n <= rating[product.prod_id] ? '#ffc500' : 'inherit' }">
                    </ion-icon>
                  </div>
                  <!-- Display the current rating value -->
                  <p>{{ rating[product.prod_id] }} out of 5</p>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" @click="submitRatings">Submit Ratings</button>
              </div>
            </div>
          </div>
        </div>
        <!-- Rating Modal -->
        <!-- Modal -->
        <div class="modal fade " id="detailsModal" tabindex="-1" aria-labelledby="detailsModalLabel" aria-hidden="true">
          <div class="modal-dialog  modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <h1 class="modal-title fs-5" id="detailsModalLabel">Order Details</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body px-4">
                <div class="row">
                  <div class="" style="max-height:200px; overflow-y:auto;">
                    <table class="table table-bordered  text-center">
                      <thead class="bg-secondary text-white" style="top:0; position:sticky;">
                        <tr>
                          <th class="col-3" scope="col">Order ID</th>
                          <th class="col-3" scope="col">Ordered at</th>
                          <th class="col-6" scope="col">Total Price</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>{{ orderId}}</td>
                          <td>{{ formatDate(ordered_at)}}</td>
                          <td>
                            <h2><b>₱ {{total_price}}</b></h2>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>

                </div>
                <div class="" style="max-height:400px; overflow-y:auto;">
                  <table class="table table-striped table-bordered text-center">
                    <thead class="bg-primary text-white" style="top:0; position:sticky;">
                      <tr>
                        <th class="col-2" scope="col">Image</th>
                        <th class="col-4" scope="col">Name</th>
                        <th class="col-2" scope="col">Price</th>
                        <th class="col-2" scope="col">Qty</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-for="transaction in allDetails" :key="transaction.order_id">
                        <td><img :src="'../assets/images/' + transaction.prod_image"
                            onerror="this.src='../assets/images/default.webp';" class="img-fluid"
                            style="max-width: 100px;"></td>

                        <td>{{ transaction.prod_name}}</td>
                        <td>₱{{ transaction.prod_price }}</td>
                        <td>{{ transaction.prod_qty }}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
              <div class="modal-footer">
                <!-- <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button> -->
                <button type="button" class="btn btn-danger" v-if="activeFilter === 'pending'" data-bs-dismiss="modal"
                  data-bs-toggle="modal" data-bs-target="#confirmationModal">
                  Cancel Order
                </button>
                <button type="button" class="btn btn-warning" v-if="activeFilter === 'pending'" data-bs-dismiss="modal"
                  data-bs-toggle="modal" data-bs-target="#qrCodeModal" :disabled="!storeStatus" @click="generateQRCode(orderId); startPolling();">
                  Counter Payment
                </button>
                <button type="button" class="btn btn-success" v-if="activeFilter === 'pending'" :disabled="!storeStatus" 
                  @click="handleEPayment">E-Payment</button>
                <button type="button" class="btn btn-success" data-bs-dismiss="modal" data-bs-toggle="modal"
                  data-bs-target="#ratingModal" v-if="activeFilter === 'completed'">Rate Orders</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"
                  v-if="activeFilter != 'pending' ">Close Details</button>


              </div>
            </div>
          </div>
        </div>
        <!-- Modal -->

        <div class="px-4 pt-4 pb-4 mt-5">
          <!-- Store status alert -->
          <div v-if="!storeStatus" class="alert alert-warning d-flex align-items-center gap-2" role="alert">
            <ion-icon name="warning-outline" style="font-size:20px; font-weight:bold;"></ion-icon>
            <div>
              The store is currently <strong>closed</strong>. Transactions are unavailable at this moment.
            </div>
          </div>
          <!-- Store status alert -->
          <!-- Search Input Field -->
          <div class="row g-0 align-items-center">
            <div class="col-md-6 d-flex align-items-center justify-content-start">
              <!-- <div class="input-group">
                <input type="text" class="form-control" placeholder="Search Product..." aria-label="Search" aria-describedby="button-addon2">
                <button class="btn btn-primary" type="button" id="button-addon2"><ion-icon name="search"></ion-icon></button>
            </div> -->
              <h2 class="text-primary">My Transactions</h2>
            </div>
            <!-- Search Input Field -->

            <div class="col-md-6 d-flex justify-content-end align-items-center gap-2">
              <button class="btn" :class="activeFilter === 'pending' ? 'btn-primary' : 'btn-secondary'"
                @click="filterTransactions('pending')">To_Pay</button>
              <button class="btn" :class="activeFilter === 'paid' ? 'btn-primary' : 'btn-secondary'"
                @click="filterTransactions('paid')">Paid</button>
              <button class="btn" :class="activeFilter === 'completed' ? 'btn-primary' : 'btn-secondary'"
                @click="filterTransactions('completed')">Completed</button>
              <button class="btn" :class="activeFilter === 'cancelled' ? 'btn-primary' : 'btn-secondary'"
                @click="filterTransactions('cancelled')">Cancelled</button>
            </div>
          </div>
        </div>
        <!-- Table -->
        <div class="px-4" style="overflow-y:auto; max-height:450px;">
          <table class="table table-striped text-center">
            <thead class="bg-primary text-white" style="top:0; position:sticky;">
              <tr>
                <th class="col-2" scope="col">Order ID</th>
                <th class="col-4" scope="col">Date Ordered</th>
                <th class="col-2" scope="col">Overall Price</th>
                <th class="col-2" scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="transaction in filteredTransactions" :key="transaction.ordered_id">
                <td>{{ transaction.order_id }}</td>
                <td>{{ formatDate(transaction.ordered_at) }}</td>
                <td>₱{{ transaction.overall_total }}</td>
                <td><button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#detailsModal"
                    @click="viewOrderDetails(transaction)"> Details</button></td>
              </tr>
            </tbody>
          </table>

          <!-- No Items Found Message -->
          <div v-if="filteredTransactions.length === 0" class="text-center py-5">
            <h4>No Items Found</h4>
          </div>
        </div>
        <!-- Table -->
      </div>
      <!-- CONTENT -->

    </div>
  </div>

  <!-- Resources Script -->
  <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/vue@2.7.16/dist/vue.js"></script>
  <!-- QR Code Library -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>

  <!-- Resources Script -->

  <!-- Ionicons -->
  <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
  <!-- Ionicons -->
  <script>
    new Vue({
      el: '#app',
      data: {
        user: <?php echo $_SESSION['user_id']; ?>,
        name: <?php echo json_encode($_SESSION['user_name']); ?>,
        allTransactions: [],
        activeFilter: 'pending',
        allDetails: [],
        orderId: '',
        ordered_at: '',
        total_price: '',
        paymentId: '',
        storeStatus:false,
        pollInterval: null,
        sidebarVisible: false,
        rating: {} // Stores ratings for each product
      },
      computed: {
        filteredTransactions() {
          return this.allTransactions.filter(transaction => transaction.status === this.activeFilter);
        }
      },
      methods: {
        fetchStoreStatus(){
          axios.post('../php/admin/fetchStoreStatus.php')
          .then(response => {
            // console.log(response.data.status);
            this.storeStatus = response.data.status;
          });
        },
        toggleSidebar() {
          this.sidebarVisible = !this.sidebarVisible;
          document.body.classList.toggle('sidebar-visible', this.sidebarVisible);
        },
        getTransactions() {
          axios.post('../php/user/getTransactions.php', { user_id: this.user })
            .then(response => {
              this.allTransactions = response.data;
            });
        },
        formatDate(dateString) {
              const date = new Date(dateString);

              // Extract the year, month, and day
              const year = date.getFullYear();
              const month = String(date.getMonth() + 1).padStart(2, '0'); // Month is 0-based
              const day = String(date.getDate()).padStart(2, '0');

              // Extract the hours and minutes
              let hours = date.getHours();
              const minutes = String(date.getMinutes()).padStart(2, '0');
              const ampm = hours >= 12 ? 'pm' : 'am';
              hours = hours % 12 || 12; // Convert 24-hour format to 12-hour format

              return `${year}-${month}-${day} ${hours}:${minutes}${ampm}`;
            },
        filterTransactions(status) {
          this.activeFilter = status;
        },
        viewOrderDetails(orderId) {
          this.orderId = orderId.order_id;
          this.ordered_at = orderId.ordered_at;
          this.total_price = orderId.overall_total;
          axios.post('../php/user/getOrderDetails.php', { order_id: this.orderId })
            .then(response => {
              this.allDetails = response.data;
              this.allDetails.forEach(product => {
                // Initialize rating for each product if not already set
                if (!this.rating[product.prod_id]) {
                  this.rating[product.prod_id] = 0;
                }
              });
            });

          this.generateQRCode(orderId.order_id);
          // this.startPolling();
        },
        startPolling() {
        // Poll every 5 seconds
        this.pollInterval = setInterval(() => {
          axios.post('../php/user/checkOrderStatus.php', { order_id: this.orderId })
            .then(response => {
              console.log(response.data);
              if (response.data.status === 'completed') {
                clearInterval(this.pollInterval);
                this.pollInterval = null;
                location.reload();
              }
            });
        }, 1000); // 5000 ms = 5 seconds
      },
      stopPolling() {
        if (this.pollInterval) {
          clearInterval(this.pollInterval);
          this.pollInterval = null;
        }
      },
        confirmCancelOrder() {
          axios.post('../php/user/cancelOrder.php', { order_id: this.orderId })
            .then(response => {
              if (response.data.success) {
                this.getTransactions();
                alert("Order has been cancelled successfully.");
              } else {
                alert("Failed to cancel the order. Please try again.");
              }
              var confirmationModal = new bootstrap.Modal(document.getElementById('confirmationModal'));
              confirmationModal.hide();
            });
        },
        logout() {
          if (confirm('Are you sure you want to log out?')) {
            axios.post('../php/user/logout.php')
              .then(response => {
                if (response.status === 200) {
                  window.location.href = '../';
                } else {
                  console.error('Logout failed:', response);
                }
              })
              .catch(error => {
                console.error('Logout error:', error);
              });
          } else {
            console.log('Logout cancelled by user.');
          }
        },
        generateQRCode(orderId) {
          const qrCodeContainer = document.getElementById('qrcode');
          qrCodeContainer.innerHTML = "";
          const orderIdStr = String(this.orderId);
          new QRCode(qrCodeContainer, { text: orderIdStr, width: 200, height: 200 });
        },
        handleEPayment() {
          axios.post('../php/user/Epayment.php', {
            orders: this.allDetails
          }).then(response => {
            // console.log(response.data);
            this.paymentId = response.data.data.id;
            window.open(response.data.data.attributes.checkout_url);
            // Start polling
            this.pollInterval = setInterval(() => {
              this.handleStatus();
            }, 1000);
          });
        },
        handleStatus() {
          axios.post('../php/user/handleStatus.php', {
            payment_id: this.paymentId
          }).then(response => {
            const status = response.data.data.attributes.payment_intent.attributes.status;
            // console.log( response.data.data.attributes.payment_intent.attributes.status);

            if (status === "succeeded") {
              clearInterval(this.pollInterval); 
              this.paidOrder();
              alert("Payment succeeded!");
            }
          });
        }, 
        paidOrder() {
          // Send a request to update the order status to 'cancelled'
          axios.post('../php/user/paidOrder.php', {
            order_id: this.orderId
          }).then(response => {
            if (response.data.success) {
              // Update the list of transactions or refresh
              this.getTransactions();
              // alert("Order has been cancelled successfully.");
            } else {
              alert("Failed to cancel the order. Please try again.");
            }
          });
        },
    
        setRating(prod_id, rating) {
          console.log(`Product ID: ${prod_id}, Rating: ${rating}`);
          this.rating = {
            ...this.rating,
            [prod_id]: rating
          };
        },
        submitRatings() {
          // Transform `this.rating` into an array of objects
          const ratingsArray = Object.keys(this.rating).map(key => ({
            prod_id: parseInt(key), // Convert the key to an integer
            prod_rate: this.rating[key] // Use the rating value
          }));

          console.log(ratingsArray);
          // Send the formatted data to the server
          axios.post('../php/user/submitRatings.php', { ratings: ratingsArray })
            .then(response => {
              console.log(response.data);

              if (response.data.success) {
                alert('Ratings submitted successfully!');
                var ratingModal = new bootstrap.Modal(document.getElementById('ratingModal'));
                ratingModal.hide();
              } else {
                alert('Failed to submit ratings. Please try again.');
              }
            })
            .catch(error => {
              console.error('Error submitting ratings:', error);
              alert('An error occurred while submitting ratings.');
            });
        }
      },
      mounted() {
        this.getTransactions();
        this.fetchStoreStatus();
      }
    });

  </script>

</body>

</html>