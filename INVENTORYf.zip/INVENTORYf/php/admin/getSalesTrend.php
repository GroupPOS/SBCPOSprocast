<?php
require '../database/db_conn.php';


$received_data = json_decode(file_get_contents("php://input"), true);

$prod_id = $received_data['prod_id'] ?? null;

$months = [
    1 => 'January',
    2 => 'February',
    3 => 'March',
    4 => 'April',
    5 => 'May',
    6 => 'June',
    7 => 'July',
    8 => 'August',
    9 => 'September',
    10 => 'October',
    11 => 'November',
    12 => 'December'
];

$sales_data = array_fill_keys(array_keys($months), ['month' => null, 'sales' => 0]); // Initialize sales data

// Populate months names in sales data
foreach ($months as $month_num => $month_name) {
    $sales_data[$month_num]['month'] = $month_name;
}

if ($prod_id) {
    $sql = "SELECT MONTH(ordered_at) AS month, SUM(total_price) AS sales
            FROM orders
            WHERE prod_id = :prod_id AND YEAR(ordered_at) = YEAR(CURDATE())
            GROUP BY MONTH(ordered_at)
            ORDER BY MONTH(ordered_at)";

    $stmt = $conn->prepare($sql);
    $stmt->bindValue(':prod_id', $prod_id, PDO::PARAM_STR);
    $stmt->execute();
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Update sales data with actual values
    foreach ($results as $row) {
        $month = (int)$row['month'];
        $sales_data[$month]['sales'] = (float)$row['sales'];
    }
}

// Output sales data as JSON
echo json_encode(array_values($sales_data));
?>
