<?php
session_start();

// Check if the session variable 'user_id' is set
if (!isset($_SESSION['admin_id'])) {
  // If not set, redirect to the home page or any other page
  header("Location: ../");
  exit();
}
?>
<!DOCTYPE html>
<html class="h-100" lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="../assets/sbc_icon.gif">

  <title>Inventory | Admin Dashboard</title>

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
    crossorigin="anonymous"></script>
  <!-- Bootstrap 5 -->

  <!-- CSS -->
  <link href="../css/sidebar.css" rel="stylesheet">

</head>

<body class="h-100">

  <div class="container-fluid h-100" id="app">
    <div class="row h-100">

      <!-- SIDEBAR -->
      <div class="col-md-2 col-sm-1 col-12 d-flex flex-column flex-shrink-0 h-100 p-3 text-white  position-fixed"
        style="background:#1167b1;" id="sidebar">
        <div class="d-flex justify-content-between align-items-center">
          <a href="/" class="d-flex align-items-center text-white text-decoration-none">
            <ion-icon size="large" class="bi me-3 ms-2" width="40" height="32" name="happy-outline"></ion-icon>
            <span class="d-none d-md-inline fs-4">Admin Profile</span>
          </a>
        </div>
        <hr>
        <ul class="nav nav-pills flex-column mb-auto">
          <li class="nav-item mb-2">
            <a href="" class="nav-link active" aria-current="page" data-bs-toggle="tooltip" data-bs-placement="right"
              title="Dashboard">
              <ion-icon class="bi me-2" name="home">
                <use xlink:href="#home"></use>
              </ion-icon>
              <span class="d-none d-md-inline">Dashboard</span>
            </a>
          </li>
          <li class="mb-2">
            <a href="./adminProducts.php" class="nav-link text-white" data-bs-toggle="tooltip" data-bs-placement="right"
              title="Products">
              <ion-icon class="bi me-2" name="pricetag">
                <use xlink:href="#products"></use>
              </ion-icon>
              <span class="d-none d-md-inline">Products</span>
            </a>
          </li>
          <li class="mb-2">
            <a href="./adminAccounts.php" class="nav-link text-white" data-bs-toggle="tooltip" data-bs-placement="right"
              title="Accounts">
              <ion-icon class="bi me-2" name="cart">
                <use xlink:href="#accounts"></use>
              </ion-icon>
              <span class="d-none d-md-inline">Accounts</span>
            </a>
          </li>
          <li class="mb-2">
            <a href="./adminReports.php" class="nav-link text-white" data-bs-toggle="tooltip" data-bs-placement="right"
              title="Reports">
              <ion-icon class="bi me-2" name="document">
                <use xlink:href="#reports"></use>
              </ion-icon>
              <span class="d-none d-md-inline">Reports</span>
            </a>
          </li>
          <li class="mb-2">
            <a href="./adminLogs.php" class="nav-link text-white" data-bs-toggle="tooltip" data-bs-placement="right"
              title="Logs">
              <ion-icon class="bi me-2" name="document">
                <use xlink:href="#logs"></use>
              </ion-icon>
              <span class="d-none d-md-inline">Logs</span>
            </a>
          </li>
          <li class="mb-2">
            <a href="./adminSettings.php" class="nav-link text-white" data-bs-toggle="tooltip" data-bs-placement="right"
              title="Settings">
              <ion-icon class="bi me-2" name="settings">
                <use xlink:href="#settings"></use>
              </ion-icon>
              <span class="d-none d-md-inline">Settings</span>
            </a>
          </li>
        </ul>
        <div class="mt-auto">
          <hr>
          <ul class="nav nav-pills flex-column">
            <li>
              <a href="#"  @click="logout" class="nav-link text-white" data-bs-toggle="tooltip" data-bs-placement="right"
                title="Log Out">
                <ion-icon class="bi me-2" name="log-out">
                  <use xlink:href="#log-out"></use>
                </ion-icon>
                <span class="d-none d-md-inline">Log Out</span>
              </a>
            </li>
          </ul>
        </div>
      </div>
      <!-- SIDEBAR -->


      <!-- CONTENT -->
      <!-- Modal -->
        <div class="modal fade" id="salesTrendModal" tabindex="-1" aria-labelledby="salesTrendModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="salesTrendModalLabel">Sales Trend</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <canvas id="salesTrendChart"></canvas>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>
      <!-- Modal -->
      <div class="col-md-10 col-sm-11 offset-md-2 offset-sm-1">
        <!-- Header -->
        <div class="p-3 d-flex align-items-center justify-content-between position-fixed bg-light"
          style="width: 82%; z-index: 100">
          <div>
            <span class="fw-bold fs-4 text-primary">POSProcast</span>
          </div>
          <div class="d-flex align-items-center">
            <span class="fs-6">Admin</span>
            <ion-icon class="ms-3" size="large" name="person-circle"></ion-icon>
          </div>
        </div>
        <!-- Header -->
        <div class="px-4 pt-5 pb-1 mt-5">
          <div class="row g-0 align-items-center">
            <div class="col-md-6 d-flex align-items-center justify-content-start">
              <h4>Dashboard Analytics</h4>
            </div>
            <!-- Search Input Field -->
            <div class="col-md-6 d-flex justify-content-end align-items-center gap-2">
              <a href="./adminReports" class="btn btn-outline-primary btn-sm">
                <div class="d-flex justify-content-center align-items-center gap-2">
                  <ion-icon name="share-outline"></ion-icon>
                  Generate Report
                </div>
              </a>

            </div>
          </div>
          <div class="row mt-4">
            <div class="col-md-3">
              <div class="card bg-light">
                <div class="row g-0">
                  <div
                    class="col-md-4 d-flex align-items-center justify-content-center border-start border-primary border-5">
                    <ion-icon size="large" name="file-tray-full-outline"></ion-icon>
                  </div>
                  <div class="col-md-8">
                    <div class="card-body">
                      <p class="card-title fs-5 fw-bold text-end mb-0">Total Products</p>
                      <p class="card-text fs-2 fw-bold text-end text-primary">{{totalProd}}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-md-3">
              <div class="card bg-light">
                <div class="row g-0">
                  <div
                    class="col-md-4 d-flex align-items-center justify-content-center border-start border-success border-5">
                    <ion-icon size="large" name="cart-outline"></ion-icon>
                  </div>
                  <div class="col-md-8">
                    <div class="card-body">
                      <p class="card-title fs-5 fw-bold text-end mb-0">Today's Orders</p>
                      <p class="card-text fs-2 fw-bold text-end text-success">{{todayOrders}}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-md-3">
              <div class="card bg-light">
                <div class="row g-0">
                  <div
                    class="col-md-4 d-flex align-items-center justify-content-center border-start border-danger border-5">
                    <ion-icon size="large" name="cash-outline"></ion-icon>
                  </div>
                  <div class="col-md-8">
                    <div class="card-body">
                      <p class="card-title fs-5 fw-bold text-end mb-0">Today's Sales</p>
                      <p class="card-text fs-2 fw-bold text-end text-danger">{{todaySales}}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- <button class="btn btn-sm btn-warning" @click="fetchLowStocks">Send Email Notif</button> -->
            <div class="col-md-3">
              <div class="card bg-light">
                <div class="row g-0">
                  <div
                    class="col-md-4 d-flex align-items-center justify-content-center border-start border-warning border-5">
                    <ion-icon size="large" name="cellular-outline"></ion-icon>
                  </div>
                  <div class="col-md-8">
                    <div class="card-body">
                      <p class="card-title fs-5 fw-bold text-end mb-0">Monthly Sales</p>
                      <p class="card-text fs-2 fw-bold text-end text-warning">{{monthlySales}}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="row mt-5">
            <!-- CHARTS  -->
            <div class="col-md-8">
              <div class="card">
                <div class="card-body">
                  <h6 class="card-title text-primary">Earnings Overview</h6>
                  <canvas id="earningsChart" width="400" height="185"></canvas>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="card">
                <div class="card-body">
                  <h6 class="card-title text-primary">Revenue Sources</h6>
                  <canvas id="revenueChart" width="400" height="400"></canvas>
                </div>
              </div>
            </div>
            <!-- CHARTS  -->
          </div>

        </div>
        <div class="px-4 pt-0 pb-4 mt-5">
          <div class="row g-0 align-items-center">
            <div class="col-md-6 d-flex align-items-center justify-content-start">
              <h4>MONTHLY FORECASTING DATA</h4>
            </div>
          </div>
          <div class="row mt-4">
            <div class="container table-responsive ">
              <table class="table table-bordered table-hover">
                <thead class="thead-dark bg-secondary text-white">
                  <tr>
                    <!-- <th scope="col">#</th> -->
                    <th scope="col">Product ID</th>
                    <th scope="col">Product Name</th>
                    <th scope="col">Forecasted Sales</th>
                    <th class="col-1" scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="(data, index) in forecastData" :key="data.prod_id">
                    <!-- <th scope="row">{{ index + 1 }}</th> -->
                    <td scope="row">{{ data.prod_id }}</td>
                    <td scope="row">{{ data.prod_name }}</td>
                    <td><b>{{ data.average_forecast_value }}</b></td>
                    <td>
                    <button class="btn btn-sm btn-warning" @click="showSalesTrend(data.prod_id)">Details</button>
                      <!-- <button class="btn btn-primary btn-sm">View</button> -->
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

          </div>


        </div>

      </div>
    </div>
    <!-- CONTENT -->
  </div>
  </div>

  <!-- Resources Script -->
  <script src="https://cdn.jsdelivr.net/npm/vue@2.6.14/dist/vue.js"></script>
  <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
  <!-- Resources Script -->

  <!-- Ionicons -->
  <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
  <!-- Ionicons -->

  <!-- Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.2/dist/chart.umd.min.js"></script>
  <!-- Chart.js -->
  <script>
    var app = new Vue({
    el: '#app',
    data: {
      totalProd: 0,
      todayOrders: 0,
      todaySales: 0,
      monthlySales: 0,
      topProducts: [],
      forecastData:[],
      salesTrendChart: null,
    },
    methods: {
      fetchForecastedData(){
        axios.post('../php/admin/fetchForecastedData.php')
        .then(response => {
          console.log(response.data.average_forecast_data);
          this.forecastData = response.data.average_forecast_data;
        });
      },
      calculatePercentage(data) {
        return (data).toFixed(2) + ' %';
      },
      getTopProducts() {
        axios.post('../php/admin/fetchTopProducts.php')
          .then(response => {
            this.topProducts = response.data;
          });
      },
      getTotalProd() {
        axios.post('../php/admin/getTotalProd.php')
          .then(response => {
            this.totalProd = response.data.prod_count;
          });
      },
      getTodayOrders() {
        axios.post('../php/admin/getTotalOrders.php')
          .then(response => {
            this.todayOrders = response.data.order_count;
          });
      },
      getTodaySales() {
        axios.post('../php/admin/getTodaySales.php')
          .then(response => {
            this.todaySales = response.data.total_sales;
          });
      },
      getMonthlySales() {
        axios.post('../php/admin/getMonthlySales.php')
          .then(response => {
            this.monthlySales = response.data.total_sales;
          });
      },
      getMonthlySalesData() {
        axios.post('../php/admin/getMonthlySalesData.php')
          .then(response => {
            const salesData = response.data;
            earningsChart.data.datasets[0].data = salesData;
            earningsChart.update();
          });
      },
      getSalesPerProduct() {
        axios.post('../php/admin/getSalesPerProduct.php')
          .then(response => {
            console.log(response.data.sales_data);
            const salesData = response.data.sales_data;
            const labels = salesData.map(s => s.prod_name);
            const data = salesData.map(s => s.total_sales);

            revenueChart.data.labels = labels;
            revenueChart.data.datasets[0].data = data;
            revenueChart.update();
          });
      },
      showSalesTrend(prodId) {
        axios.post('../php/admin/getSalesTrend.php', { prod_id: prodId })
          .then(response => {
            console.log(response.data);
            const trendData = response.data;

            // Prepare data for the chart
            const labels = trendData.map(item => item.month);
            const data = trendData.map(item => item.sales);

            // Create or update the sales trend chart
            if (this.salesTrendChart) {
              this.salesTrendChart.destroy();
            }
            
            const ctx = document.getElementById('salesTrendChart').getContext('2d');
            this.salesTrendChart = new Chart(ctx, {
              type: 'line',
              data: {
                labels: labels,
                datasets: [{
                  label: 'Sales Trend',
                  data: data,
                  borderColor: 'rgb(13,110,253)',
                  borderWidth: 2,
                  pointBackgroundColor: 'rgb(13,110,253)',
                  pointRadius: 3,
                  pointHoverRadius: 8,
                  fill: false
                }]
              },
              options: {
                responsive: true,
                scales: {
                  y: {
                    beginAtZero: true
                  }
                }
              }
            });

            // Show the modal
            const salesTrendModal = new bootstrap.Modal(document.getElementById('salesTrendModal'));
            salesTrendModal.show();
          });
      },
      logout() {
        if (confirm('Are you sure you want to log out?')) {
          axios.post('../php/admin/logout.php')
            .then(response => {
              if (response.status === 200) {
                window.location.href = '../';
              } else {
                console.error('Logout failed:', response);
              }
            })
            .catch(error => {
              console.error('Logout error:', error);
            });
        } else {
          console.log('Logout cancelled by user.');
        }
      },
      fetchLowStocks() {
          // Axios call to fetch low stock products from the backend
          axios.post('../php/admin/fetchLowStocks.php')
              .then(response => {
                  const lowStockProducts = response.data.map(product => ({
                      prod_name: product.prod_name,
                      prod_qty: product.prod_qty
                  }));

                  // Check if there are low stock products
                  if (lowStockProducts.length > 0) {
                      // Send email alert with recipient email
                      this.sendLowStockAlert('emjhay.celstino20@gmail.com', lowStockProducts);
                  } else {
                      console.log('No low stock products to alert.');
                  }
              })
              .catch(error => {
                  console.error('Error fetching low stock products:', error);
              });
      },

      sendLowStockAlert(toEmail, lowStockProducts) {
          const templateParams = {
              to_email: toEmail, // Recipient email address
              to_name: 'Admin', // Recipient name
              from_name: 'SBC Inventory System', // Sender name
              low_stock_products: lowStockProducts // Data for products with low stock
          };
          
          emailjs.send('service_j9h891q', 'template_8n2kasz', templateParams)
          .then(response => {
              console.log('SUCCESS!', response.status, response.text);
          }, error => {
              console.log('FAILED...', error);
          });
      }

  
    },
    created() {
      this.fetchForecastedData();
      this.getTotalProd();
      this.getTodayOrders();
      this.getTodaySales();
      this.getMonthlySales();
      this.getMonthlySalesData();
      this.getSalesPerProduct();
      this.getTopProducts();
    },
  });
  </script>
  <script>
    // Chart Data and Options


    const revenueData = {
      labels: ['Direct', 'Social', 'Referral'],
      datasets: [{
        label: 'Revenue',
        data: [3000, 2000, 1500],
        backgroundColor: [
          'rgb(255, 99, 132)',
          'rgb(54, 162, 235)',
          'rgb(255, 205, 86)'
        ]
      }]
    };

    const earningsOptions = {
      scales: {
        y: {
          beginAtZero: true
        }
      }
    };

    const revenueOptions = {};

    const ctx = document.getElementById('earningsChart').getContext('2d');
    const earningsChart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
        datasets: [{
          label: 'Earnings',
          data: [], // Initial empty array
          borderColor: 'rgb(13,110,253)',
          borderWidth: 2,
          pointBackgroundColor: 'rgb(13,110,253)',
          pointRadius: 3,
          pointHoverRadius: 8,
          fill: false
        }]
      },
      options: {
        responsive: true,
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });

    var revenueChart = new Chart(document.getElementById('revenueChart').getContext('2d'), {
      type: 'pie',
      data: revenueData,
      options: revenueOptions
    });


  </script>


</body>

</html>