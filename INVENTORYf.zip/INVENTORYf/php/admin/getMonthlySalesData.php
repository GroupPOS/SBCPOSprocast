<?php
require '../database/db_conn.php';


// Array to store the monthly sales
$monthlySales = array_fill(0, 12, 0); // Initialize an array with 12 months (0 for each month)

// Query to get sales grouped by month
$query = "SELECT sale_month, SUM(total_sales_per_order) AS total_sales 
            FROM ( SELECT MONTH(ordered_at) AS sale_month, SUM(overall_total) AS total_sales_per_order 
                    FROM sales WHERE YEAR(ordered_at) = YEAR(CURDATE()) GROUP BY order_id, MONTH(ordered_at) ) AS order_sales 
            GROUP BY sale_month LIMIT 0, 25;";

$stmt = $conn->prepare($query);
$stmt->execute();

while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    // Store the sales in the respective month index (subtract 1 to match array index 0-11)
    $monthlySales[$row['sale_month'] - 1] = $row['total_sales'];
}

// Return the data as JSON
echo json_encode($monthlySales);
