<?php
session_start();

// Check if the session variable 'user_id' is set
if (!isset($_SESSION['admin_id'])) {
    // If not set, redirect to the home page or any other page
    header("Location: ../");
    exit();
}
?>
<!DOCTYPE html>
<html class="h-100" lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="icon" type="image/x-icon" href="../assets/sbc_icon.gif">
    <title>Inventory | Admin Logs </title>

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
        integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"
        integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF"
        crossorigin="anonymous"></script>
    <!-- Bootstrap 5 -->

    <!-- CSS -->
    <link href="../css/sidebar.css" rel="stylesheet">

</head>

<body class="h-100">

    <div class="container-fluid h-100" id="app">
        <div class="row h-100">

            <!-- SIDEBAR -->
            <div class="col-md-2 col-sm-1 col-12 d-flex flex-column flex-shrink-0 h-100 p-3 text-white  position-fixed"
                style="background:#1167b1;" id="sidebar">
                <div class="d-flex justify-content-between align-items-center">
                    <a href="/" class="d-flex align-items-center text-white text-decoration-none">
                        <ion-icon size="large" class="bi me-3 ms-2" width="40" height="32"
                            name="happy-outline"></ion-icon>
                        <span class="d-none d-md-inline fs-4">Admin Profile</span>
                    </a>
                </div>
                <hr>
                <ul class="nav nav-pills flex-column mb-auto">
                    <li class="nav-item mb-2">
                        <a href="./adminDash.php" class="nav-link text-white" aria-current="page"
                            data-bs-toggle="tooltip" data-bs-placement="right" title="Dashboard">
                            <ion-icon class="bi me-2" name="home">
                                <use xlink:href="#home"></use>
                            </ion-icon>
                            <span class="d-none d-md-inline">Dashboard</span>
                        </a>
                    </li>
                    <li class="mb-2">
                        <a href="./adminProducts.php" class="nav-link text-white" data-bs-toggle="tooltip"
                            data-bs-placement="right" title="Products">
                            <ion-icon class="bi me-2" name="pricetag">
                                <use xlink:href="#products"></use>
                            </ion-icon>
                            <span class="d-none d-md-inline">Products</span>
                        </a>
                    </li>
                    <li class="mb-2">
                        <a href="./adminAccounts.php" class="nav-link text-white" data-bs-toggle="tooltip"
                            data-bs-placement="right" title="Accounts">
                            <ion-icon class="bi me-2" name="cart">
                                <use xlink:href="#accounts"></use>
                            </ion-icon>
                            <span class="d-none d-md-inline">Accounts</span>
                        </a>
                    </li>
                    <li class="mb-2">
                        <a href="./adminReports.php" class="nav-link text-white" data-bs-toggle="tooltip"
                            data-bs-placement="right" title="Reports">
                            <ion-icon class="bi me-2" name="document">
                                <use xlink:href="#reports"></use>
                            </ion-icon>
                            <span class="d-none d-md-inline">Reports</span>
                        </a>
                    </li>
                    <li class="mb-2">
                        <a href="./adminLogs.php" class="nav-link active" data-bs-toggle="tooltip"
                            data-bs-placement="right" title="Logs">
                            <ion-icon class="bi me-2" name="document">
                                <use xlink:href="#logs"></use>
                            </ion-icon>
                            <span class="d-none d-md-inline">Logs</span>
                        </a>
                    </li>
                    <li class="mb-2">
                        <a href="./adminSettings.php" class="nav-link text-white" data-bs-toggle="tooltip"
                            data-bs-placement="right" title="Settings">
                            <ion-icon class="bi me-2" name="settings">
                                <use xlink:href="#settings"></use>
                            </ion-icon>
                            <span class="d-none d-md-inline">Settings</span>
                        </a>
                    </li>
                </ul>
                <div class="mt-auto">
                    <hr>
                    <ul class="nav nav-pills flex-column">
                        <li>
                            <a href="#"  @click="logout"  class="nav-link text-white" data-bs-toggle="tooltip" data-bs-placement="right"
                                title="Log Out">
                                <ion-icon class="bi me-2" name="log-out">
                                    <use xlink:href="#log-out"></use>
                                </ion-icon>
                                <span class="d-none d-md-inline">Log Out</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- SIDEBAR -->


            <!-- CONTENT -->
            <div class="col-md-10 col-sm-11 offset-md-2 offset-sm-1">
                <!-- Header -->
                <div class="p-3 d-flex align-items-center justify-content-between position-fixed bg-light"
                    style="width: 82%; z-index: 100">
                    <div>
                        <span class="fw-bold fs-4 text-primary">POSProcast</span>
                    </div>
                    <div class="d-flex align-items-center">
                        <span class="fs-6">Admin</span>
                        <ion-icon class="ms-3" size="large" name="person-circle"></ion-icon>
                    </div>
                </div>
                <!-- Header -->

                <div class="px-4 pt-5 pb-4 mt-5">
                    <div class="row g-0 align-items-center">
                        <div class="col-md-6 d-flex align-items-center justify-content-start">
                            <h4>User Logs Management</h4>
                        </div>
                        <!-- Search Input Field -->
                        <div class="col-md-6 d-flex justify-content-end align-items-center gap-2">


                        </div>
                    </div>
                    <!-- Search Input Field -->
                    <div class="row g-0 align-items-center pt-4">
                        <div class="col-md-6 d-flex align-items-center justify-content-start">
                            <div class="input-group">
                                <input type="text" v-model="searchLogs" class="form-control"
                                    placeholder="Search Logs..." aria-label="Search" aria-describedby="button-addon2">
                                <button class="btn btn-primary" type="button" id="button-addon2"
                                    @click="applyFilters"><ion-icon name="search"></ion-icon></button>
                            </div>
                        </div>
                        <!-- Button Trigger Modal -->
                        <div class="col-md-6 d-flex justify-content-end align-items-center gap-2">
                            <button class="btn btn-secondary" type="button" data-bs-toggle="modal"
                                data-bs-target="#filterModal">Filter Options</button>
                            <button class="btn btn-secondary" type="button" @click="refresh"><ion-icon name="refresh"
                                    style="font-size:20px;"></ion-icon></button>
                        </div>


                        <!-- Filter Modal -->
                        <div class="modal fade" id="filterModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                            aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title text-primary" id="exampleModalLabel">Filter Options</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form @submit.prevent="applyFilters">
                                            <div class="mb-3">
                                                <label for="logId" class="form-label">Log ID</label>
                                                <input type="text" v-model="filterLogId" class="form-control" id="logId"
                                                    placeholder="Enter Log ID">
                                            </div>
                                            <div class="mb-3">
                                                <label for="userType" class="form-label">User Type</label>
                                                <select v-model="filterUserType" class="form-select" id="userType">
                                                    <option value="">All</option>
                                                    <option v-for="userType in uniqueUserTypes" :key="userType"
                                                        :value="userType">
                                                        {{ userType }}
                                                    </option>
                                                </select>
                                            </div>
                                            <div class="mb-3">
                                                <label for="logType" class="form-label">Log Type</label>
                                                <select v-model="filterLogType" class="form-select" id="logType">
                                                    <option value="">All</option>
                                                    <option v-for="logType in uniqueLogTypes" :key="logType"
                                                        :value="logType">
                                                        {{ logType }}
                                                    </option>
                                                </select>
                                            </div>
                                            <div class="mb-3">
                                                <label for="dateRange" class="form-label">Date Range</label>
                                                <div class="input-group">
                                                    <span class="input-group-text">Min</span>
                                                    <input type="date" v-model="filterMinDate" class="form-control"
                                                        id="minDate">
                                                    <span class="input-group-text">Max</span>
                                                    <input type="date" v-model="filterMaxDate" class="form-control"
                                                        id="maxDate">
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal"
                                            aria-label="Close">Close</button>
                                        <button type="button" class="btn btn-primary" data-bs-dismiss="modal"
                                            @click="applyFilters">Apply Filters</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Filter Modal -->
                    </div>
                </div>


                <!-- Table -->
                <div class="px-4 overflow-auto style" style="max-height: 500px;">
                    <table class="table table-striped text-center">
                        <thead class="bg-primary text-white" style="position:sticky; top:0;">
                            <tr>
                                <th class="col-1" scope="col">Log ID</th>
                                <th class="col-1" scope="col">User Type</th>
                                <th class="col-2" scope="col">Name</th>
                                <th class="col-1" scope="col">Log Type</th>
                                <th class="col-4" scope="col">Info</th>
                                <th class="col-4" scope="col">Created at</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="align-middle" v-for="data in filteredLogs" :key="data.log_id">
                                <td>
                                    {{data.log_id}}
                                </td>
                                <td>
                                    {{data.user_type}}
                                </td>
                                <td>{{data.user_name}}</td>
                                <td>{{data.log_type}}</td>
                                <td>{{data.log_info}}</td>
                                <td>{{formatDate(data.created_at)}}</td>
                            </tr>

                        </tbody>
                    </table>
                </div>
                <!-- Table -->
            </div>
            <!-- CONTENT -->

        </div>
    </div>
    <!-- Resources Script -->
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/vue@2.7.16/dist/vue.js"></script>
    <!-- Resources Script -->

    <!-- Ionicons -->
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    <!-- Ionicons -->

    <script>
        var app = new Vue({
            el: '#app',
            data: {
                allLogs: [],
                uniqueLogTypes: [],
                uniqueUserTypes: [],
                filterLogId: '',
                filterUserType: '',
                filterLogType: '',
                filterMinDate: '',
                searchLogs: '',
                filterMaxDate: ''
            },
            computed: {
                filteredLogs: function () {
                    // Start with all logs
                    let filtered = [...this.allLogs];

                    // Apply filters
                    if (this.filterLogId && this.filterLogId.trim() !== '') {
                        filtered = filtered.filter(log =>
                            log.log_id.toString().includes(this.filterLogId)
                        );
                    }

                    if (this.filterUserType) {
                        filtered = filtered.filter(log =>
                            log.user_type.toLowerCase().includes(this.filterUserType.toLowerCase())
                        );
                    }

                    if (this.filterLogType) {
                        filtered = filtered.filter(log =>
                            log.log_type.toLowerCase().includes(this.filterLogType.toLowerCase())
                        );
                    }

                    // Apply search filter
                    if (this.searchLogs) {
                        filtered = filtered.filter(log =>
                            log.user_name.toLowerCase().includes(this.searchLogs.toLowerCase()) ||
                            log.log_type.toLowerCase().includes(this.searchLogs.toLowerCase()) ||
                            log.log_info.toLowerCase().includes(this.searchLogs.toLowerCase())
                        );
                    }

                    if (this.filterMinDate) {
                        filtered = filtered.filter(log =>
                            new Date(log.created_at) >= new Date(this.filterMinDate)
                        );
                    }

                    if (this.filterMaxDate) {
                        filtered = filtered.filter(log =>
                            new Date(log.created_at) <= new Date(this.filterMaxDate)
                        );
                    }

                    return filtered;
                }
            },
            methods: {
                formatDate(dateString) {
                const date = new Date(dateString);

                // Extract the year, month, and day
                const year = date.getFullYear();
                const month = String(date.getMonth() + 1).padStart(2, '0'); // Month is 0-based
                const day = String(date.getDate()).padStart(2, '0');

                // Extract the hours and minutes
                let hours = date.getHours();
                const minutes = String(date.getMinutes()).padStart(2, '0');
                const ampm = hours >= 12 ? 'pm' : 'am';
                hours = hours % 12 || 12; // Convert 24-hour format to 12-hour format

                return `${year}-${month}-${day} ${hours}:${minutes}${ampm}`;
                },
                applyFilters() {
                    this.fetchLogs();
                },
                refresh() {
                    this.filterLogId = '';
                    this.filterUserType = '';
                    this.filterLogType = '';
                    this.filterMinDate = '';
                    this.searchLogs = '';
                    this.filterMaxDate = '';
                    this.fetchLogs();
                },
                fetchLogs() {
                    axios.post('../php/admin/fetchLogs.php')
                        .then((response) => {
                            this.allLogs = response.data;
                            this.uniqueLogTypes = [...new Set(this.allLogs.map(log => log.log_type))];
                            this.uniqueUserTypes = [...new Set(this.allLogs.map(log => log.user_type))];
                        });
                },
                logout() {
                    // Ask user for confirmation
                    if (confirm('Are you sure you want to log out?')) {
                        // If user confirms, proceed with logout
                        axios.post('../php/admin/logout.php')
                            .then(response => {
                                // Check if the response indicates success or handle according to your needs
                                if (response.status === 200) {
                                    // Redirect to home page or refresh the current page
                                    window.location.href = '../'; // Redirect to the home page
                                    // or use the following line to simply refresh the page
                                    // window.location.reload();
                                } else {
                                    // Handle errors or unsuccessful logout if needed
                                    console.error('Logout failed:', response);
                                }
                            })
                            .catch(error => {
                                // Handle network or other errors
                                console.error('Logout error:', error);
                            });
                    } else {
                        // If the user cancels, do nothing
                        console.log('Logout cancelled by user.');
                    }
                }

            },
            created() {
                this.fetchLogs();
            }
        });
    </script>
</body>

</html>