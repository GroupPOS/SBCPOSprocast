<?php

session_start(); // Start the session

require '../database/db_conn.php';

// Decode the received JSON data
$received_data = json_decode(file_get_contents("php://input"), true);

// Check if the required data is provided
if (isset($received_data['status'])) {
    // Prepare the query to update the store status
    $stmt = $conn->prepare("UPDATE store_status SET status = :status WHERE id = 1");
    
    // Bind the parameters
    $stmt->bindParam(':status', $received_data['status'], PDO::PARAM_INT);

    // Execute the query
    if ($stmt->execute()) {
        // Prepare log entry details
        $log_type = $received_data['status'] == 1 ? 'store_open' : 'store_close';
        $log_info = $received_data['status'] == 1 ? 'Store opened by Admin' : 'Store closed by Admin';

        // Check if user is authenticated
        if (!isset($_SESSION['admin_id'], $_SESSION['admin_name'])) {
            echo json_encode(['success' => false, 'message' => 'User not authenticated']);
            exit;
        }

        $user_id = $_SESSION['admin_id'];
        $user_name = $_SESSION['admin_name'];
        $user_type = 'admin'; // or whatever is appropriate

        // Insert log entry into logs table
        $log_stmt = $conn->prepare("INSERT INTO logs (user_type, user_name, user_id, log_type, log_info) 
                                     VALUES (:user_type, :user_name, :user_id, :log_type, :log_info)");

        // Bind log parameters
        $log_stmt->bindParam(':user_type', $user_type);
        $log_stmt->bindParam(':user_name', $user_name);
        $log_stmt->bindParam(':user_id', $user_id); // Fixed this line
        $log_stmt->bindParam(':log_type', $log_type);
        $log_stmt->bindParam(':log_info', $log_info);

        // Execute the log insert
        if ($log_stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Store status updated and log recorded successfully']);
        } else {
            echo json_encode(['success' => true, 'message' => 'Store status updated but failed to log the action']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update store status']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Missing parameters']);
}

?>
