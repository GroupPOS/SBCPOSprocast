<?php
require '../database/db_conn.php';

// SQL query to fetch the top 4 products according to updated_at
$sql = "SELECT p.*, 
            COALESCE(AVG(r.prod_rate), 0) AS average_rating, 
            COUNT(r.id) AS rating_count
        FROM products p
        LEFT JOIN ratings r ON p.prod_id = r.prod_id
        WHERE p.status = 'live' AND p.prod_qty > 0
        GROUP BY p.prod_id
        ORDER BY p.updated_at DESC 
        LIMIT 4;";
$stmt = $conn->prepare($sql);
$stmt->execute();

// Fetching the products
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Close the connection
$conn = null;

// Convert the fetched data to JSON
$jsonData = json_encode($products);

echo $jsonData;