<?php
require '../database/db_conn.php';

// Receive data from the request body
$received_data = json_decode(file_get_contents("php://input"));

if (isset($received_data->id)) {
    $id = $received_data->id;

    // Check if the user exists before attempting deletion
    $queryCheck = "SELECT * FROM users WHERE user_id = :id";
    $stmtCheck = $conn->prepare($queryCheck);
    $stmtCheck->bindParam(':id', $id);
    $stmtCheck->execute();

    if ($stmtCheck->rowCount() > 0) {
        // SQL query to delete a user by its ID
        $sql = "DELETE FROM users WHERE user_id = :id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT); // Bind the parameter to prevent SQL injection

        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Account deleted successfully']);

            // Log the admin's action
            try {
                session_start();
                $admin_id = $_SESSION['admin_id'];
                $admin_name = $_SESSION['admin_name'];
                $log_type = 'account_removal';
                $log_info = "Admin \"$admin_name\" removed user with ID: $id";

                $logStmt = $conn->prepare("
                    INSERT INTO logs (user_type, user_name, user_id, log_type, log_info) 
                    VALUES ('admin', :admin_name, :admin_id, :log_type, :log_info)
                ");
                $logStmt->bindParam(':admin_name', $admin_name);
                $logStmt->bindParam(':admin_id', $admin_id);
                $logStmt->bindParam(':log_type', $log_type);
                $logStmt->bindParam(':log_info', $log_info);

                if (!$logStmt->execute()) {
                    throw new PDOException("Failed to insert log entry");
                }
            } catch (PDOException $e) {
                echo json_encode(['success' => false, 'message' => "Logging error: " . $e->getMessage()]);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to delete account']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'User ID does not exist']);
    }
} else {
    echo json_encode(['error' => 'ID is missing in the request']);
}

// Close the connection
$conn = null;