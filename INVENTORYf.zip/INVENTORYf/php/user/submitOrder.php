<?php
require '../database/db_conn.php';

session_start();
$received_data = json_decode(file_get_contents("php://input"), true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($received_data['orders']) && is_array($received_data['orders'])) {
        $orders = $received_data['orders'];
        $insufficient_stock_products = [];

        try {
            // Pre-check stock for all products
            foreach ($orders as $order) {
                // Check if the product has sufficient quantity
                $checkStockStmt = $conn->prepare("
                    SELECT prod_name, prod_qty 
                    FROM products 
                    WHERE prod_id = :prod_id
                ");
                $checkStockStmt->bindParam(':prod_id', $order['prod_id']);
                $checkStockStmt->execute();
                $product = $checkStockStmt->fetch(PDO::FETCH_ASSOC);

                if ($product['prod_qty'] < $order['prod_qty']) {
                    // Add product to insufficient stock list
                    $insufficient_stock_products[] = $product['prod_name'];
                }
            }

            // If there are insufficient stock products, abort the process and return a message
            if (!empty($insufficient_stock_products)) {
                $message = "Insufficient stocks for the following product(s): " . implode(", ", $insufficient_stock_products);
                echo json_encode(['success' => false, 'message' => $message]);
                exit;
            }

            // Begin transaction for orders
            $conn->beginTransaction();

            // Prepare insert statement for orders
            $stmt = $conn->prepare("
                INSERT INTO orders (order_id, user_id, user_name, prod_id, prod_qty, prod_name, prod_price, prod_image, total_price, ordered_at, overall_total, status) 
                VALUES (:order_id, :user_id, :user_name, :prod_id, :prod_qty, :prod_name, :prod_price, :prod_image, :total_price, :ordered_at, :overall_total, :status)
            ");

            foreach ($orders as $order) {
                $stmt->bindParam(':order_id', $order['order_id']);
                $stmt->bindParam(':user_id', $order['user_id']);
                $stmt->bindParam(':user_name', $order['user_name']);
                $stmt->bindParam(':prod_id', $order['prod_id']);
                $stmt->bindParam(':prod_qty', $order['prod_qty']);
                $stmt->bindParam(':prod_name', $order['prod_name']);
                $stmt->bindParam(':prod_price', $order['prod_price']);
                $stmt->bindParam(':prod_image', $order['prod_image']);
                $stmt->bindParam(':total_price', $order['total_price']);
                $stmt->bindParam(':ordered_at', $order['ordered_at']);
                $stmt->bindParam(':overall_total', $order['overall_total']);
                $stmt->bindParam(':status', $order['status']);

                if (!$stmt->execute()) {
                    $conn->rollBack();
                    echo json_encode(['success' => false, 'message' => 'Error inserting order']);
                    exit;
                }
            }

            // Commit the transaction for orders
            $conn->commit();

            // Insert log entry for order submission
            $logStmt = $conn->prepare("
                INSERT INTO logs (user_type, user_name, user_id, log_type, log_info) 
                VALUES (:user_type, :user_name, :user_id, :log_type, :log_info)
            ");

            $user_id = $_SESSION['user_id'];
            $user_name = $_SESSION['user_name'];
            $user_type = 'user';
            $log_type = 'order_submission';
            $log_info = $user_name . " submitted an order with order ID " . $orders[0]['order_id'];

            $logStmt->bindParam(':user_type', $user_type);
            $logStmt->bindParam(':user_name', $user_name);
            $logStmt->bindParam(':user_id', $user_id);
            $logStmt->bindParam(':log_type', $log_type);
            $logStmt->bindParam(':log_info', $log_info);
            
            if ($logStmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'Order submitted and log created']);
            } else {
                echo json_encode(['success' => true, 'message' => 'Order submitted but log creation failed']);
            }
        } catch (PDOException $e) {
            $conn->rollBack();
            echo json_encode(['success' => false, 'message' => "Error: " . $e->getMessage()]);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid data']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
