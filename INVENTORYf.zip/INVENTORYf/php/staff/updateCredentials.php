<?php
require '../database/db_conn.php';

// Start session and check if user_id is set
session_start();
if (!isset($_SESSION['staff_id']) || !isset($_SESSION['staff_name'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit;
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['oldPassword']) || !isset($input['newPassword'])) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields: oldPassword or newPassword']);
    exit;
}

$oldPassword = $input['oldPassword'];
$newPassword = $input['newPassword'];
$userId = $_SESSION['staff_id'];
$userName = $_SESSION['staff_name'];

// Check if new password meets criteria (e.g., minimum length)
if (strlen($newPassword) < 6) {
    echo json_encode(['success' => false, 'message' => 'New password must be at least 6 characters long']);
    exit;
}

// Fetch current password hash from the database
try {
    $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$result) {
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit;
    }

    $currentPasswordHash = $result['password'];

    // Verify old password using password_verify()
    if (!password_verify($oldPassword, $currentPasswordHash)) {
        echo json_encode(['success' => false, 'message' => 'Old password is incorrect']);
        exit;
    }

    // Hash the new password
    $newPasswordHash = password_hash($newPassword, PASSWORD_DEFAULT);

    // Update password in the database
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
    $stmt->execute([$newPasswordHash, $userId]);

    // Log the successful update
    $logType = 'update credentials';
    $logInfo = 'Password updated successfully';

    $stmt = $conn->prepare("INSERT INTO logs (user_type, user_name, user_id, log_type, log_info) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute(['staff', $userName, $userId, $logType, $logInfo]);

    echo json_encode(['success' => true, 'message' => 'Credentials updated successfully and log recorded']);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Failed to update credentials or record log: ' . $e->getMessage()]);
}
?>
