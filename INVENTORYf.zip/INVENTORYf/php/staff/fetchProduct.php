<?php
// Connect to the database
require '../database/db_conn.php';


// Get the received JSON data and decode it
$received_data = json_decode(file_get_contents("php://input"));

// Check if the barcode is provided in the received data
if (isset($received_data->barcode)) {
    $barcode = $received_data->barcode;

    // SQL query to fetch the product by barcode
    $sql = "SELECT * FROM products WHERE barcode = :barcode AND status = 'live' AND prod_qty > 0 LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':barcode', $barcode, PDO::PARAM_STR);
    $stmt->execute();

    // Fetch the product
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($product) {
        // Convert the product data to JSON
        echo json_encode($product);
    } else {
        // If no product found, return an empty response
        echo json_encode([]);
    }
} else {
    // If barcode is not provided, return an error
    echo json_encode(["error" => "No barcode provided."]);
}

// Close the connection
$conn = null;
