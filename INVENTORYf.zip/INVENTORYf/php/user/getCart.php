<?php
require '../database/db_conn.php';


$received_data = json_decode(file_get_contents("php://input"));

$user_id = $received_data->user_id;

// SQL query to fetch the top 4 products according to updated_at
$sql = "SELECT *,p.barcode 
        FROM cart as c
        INNER JOIN products as p ON c.prod_id = p.prod_id
        WHERE c.user_id = '$user_id' 
        ORDER BY c.created_at DESC ";
$stmt = $conn->prepare($sql);
$stmt->execute();

// Fetching the products
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Close the connection
$conn = null;

// Convert the fetched data to JSON
$jsonData = json_encode($products);

echo $jsonData;