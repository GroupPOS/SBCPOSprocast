<?php
require '../database/db_conn.php';


$received_data = json_decode(file_get_contents("php://input"), true);

// Validate input data
if (isset($received_data['id'], $received_data['fname'], $received_data['lname'], $received_data['role'])) {
    // Extract the necessary data from the decoded JSON
    $user_id = $received_data['id'];
    $fname = trim($received_data['fname']);
    $lname = trim($received_data['lname']);
    $role = trim($received_data['role']);

    // Split first name and last name into words
    $fnameWords = explode(' ', $fname);
    $lnameWords = explode(' ', $lname);

    // Apply title case to each word
    $fname = implode(' ', array_map('ucfirst', array_map('strtolower', $fnameWords)));
    $lname = implode(' ', array_map('ucfirst', array_map('strtolower', $lnameWords)));

    // Prepare the SQL statement for updating a user
    $updateQuery = "UPDATE users SET firstName = :fname, lastName = :lname, role = :role WHERE user_id = :id";

    $stmt = $conn->prepare($updateQuery);
    $stmt->bindParam(':id', $user_id);
    $stmt->bindParam(':fname', $fname);
    $stmt->bindParam(':lname', $lname);
    $stmt->bindParam(':role', $role);

    // Execute the statement and handle the result
    if ($stmt->execute()) {
        // Log the update
        try {
            session_start();
            $admin_id = $_SESSION['admin_id'];
            $admin_name = $_SESSION['admin_name'];
            $log_type = 'update_user';
            $log_info = "Admin \"$admin_name\" updated user (ID: $user_id)";

            $logStmt = $conn->prepare("
                INSERT INTO logs (user_type, user_name, user_id, log_type, log_info) 
                VALUES ('admin', :admin_name, :admin_id, :log_type, :log_info)
            ");
            $logStmt->bindParam(':admin_name', $admin_name);
            $logStmt->bindParam(':admin_id', $admin_id);
            $logStmt->bindParam(':log_type', $log_type);
            $logStmt->bindParam(':log_info', $log_info);
            $logStmt->execute();
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => "Logging error: " . $e->getMessage()]);
            exit;
        }

        // Return success message
        echo json_encode(['success' => true, 'message' => 'User updated successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update user']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Required fields are missing']);
}

// Close the connection
$conn = null;
