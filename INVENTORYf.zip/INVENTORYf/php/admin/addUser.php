<?php
require '../database/db_conn.php';

$received_data = json_decode(file_get_contents("php://input"), true);

// Extract the necessary data from the decoded JSON
$id = $received_data['id'];
$fname = $received_data['fname'];
$lname = $received_data['lname'];
$role = $received_data['role'];
$password = $received_data['password'];

// Split the firstName and lastName into words
$fnameWords = explode(' ', $fname);
$lnameWords = explode(' ', $lname);

// Apply title case to each word in firstName and lastName
foreach ($fnameWords as &$word) {
    $word = ucfirst(strtolower($word));
}
unset($word);

foreach ($lnameWords as &$word) {
    $word = ucfirst(strtolower($word));
}
unset($word);

// Reconstruct the firstName and lastName strings
$fname = implode(' ', $fnameWords);
$lname = implode(' ', $lnameWords);

// Check if the user_id already exists
$queryCheck = "SELECT * FROM users WHERE user_id = :id";
$stmtCheck = $conn->prepare($queryCheck);
$stmtCheck->bindParam(':id', $id);
$stmtCheck->execute();

if ($stmtCheck->rowCount() > 0) {
    echo json_encode(['success' => false, 'message' => 'User ID already taken.']);
    exit;
}

// Hash the password before storing it
$hashedPassword = password_hash($password, PASSWORD_BCRYPT);

// Prepare the SQL statement for inserting a new user
$insertQuery = "INSERT INTO users (user_id, firstName, lastName, role, password) VALUES (:id, :fname, :lname, :role, :password)";
$stmt = $conn->prepare($insertQuery);

// Bind the parameters to prevent SQL injection
$stmt->bindParam(':id', $id);
$stmt->bindParam(':fname', $fname);
$stmt->bindParam(':lname', $lname);
$stmt->bindParam(':role', $role);
$stmt->bindParam(':password', $hashedPassword); // Use the hashed password

if ($stmt->execute()) {
    // If the insertion was successful, return a success message
    echo json_encode(['success' => true, 'message' => 'User inserted successfully']);

    // Log the admin's action
    try {
        session_start();
        $admin_id = $_SESSION['admin_id'];
        $admin_name = $_SESSION['admin_name'];
        $log_type = 'user_addition';
        $log_info = "Admin \"$admin_name\" added a new user with ID: $id";

        $logStmt = $conn->prepare("
            INSERT INTO logs (user_type, user_name, user_id, log_type, log_info) 
            VALUES ('admin', :admin_name, :admin_id, :log_type, :log_info)
        ");
        $logStmt->bindParam(':admin_name', $admin_name);
        $logStmt->bindParam(':admin_id', $admin_id);
        $logStmt->bindParam(':log_type', $log_type);
        $logStmt->bindParam(':log_info', $log_info);

        if (!$logStmt->execute()) {
            throw new PDOException("Failed to insert log entry");
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => "Logging error: " . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to add user']);
}

// Close the connection
$conn = null;
