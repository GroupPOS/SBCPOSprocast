<?php
require '../database/db_conn.php';

// Function to update admin credentials
function updateAdminCredentials($conn, $data) {
    // Extract data from the passed array
    $password = $data['password'];
    $id = $data['id']; // Assuming 'id' is used to identify the admin record

    // Hash the password for security
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    // Prepare the SQL statement for updating credentials
    $sql = "UPDATE users SET password = :password WHERE id = :id"; // Update the users table
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':password', $hashedPassword); // Bind the hashed password
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);

    if ($stmt->execute()) {
        return ['success' => true, 'message' => 'Admin credentials updated successfully'];
    } else {
        return ['success' => false, 'message' => 'Failed to update admin credentials'];
    }
}

// Example usage
$received_data = json_decode(file_get_contents("php://input"), true); // Parse JSON request body

if (!empty($received_data['password']) && !empty($received_data['id'])) {
    $result = updateAdminCredentials($conn, $received_data);

    // Log the update action
    try {
        session_start();
        $admin_id = $_SESSION['admin_id'];
        $admin_name = $_SESSION['admin_name'];
        $log_type = 'update_credentials';
        $log_info = "Admin \"$admin_name\" updated the credentials.";

        $logStmt = $conn->prepare("
            INSERT INTO logs (user_type, user_name, user_id, log_type, log_info) 
            VALUES ('admin', :admin_name, :admin_id, :log_type, :log_info)
        ");
        $logStmt->bindParam(':admin_name', $admin_name);
        $logStmt->bindParam(':admin_id', $admin_id);
        $logStmt->bindParam(':log_type', $log_type);
        $logStmt->bindParam(':log_info', $log_info);

        if (!$logStmt->execute()) {
            throw new PDOException("Failed to insert log entry");
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => "Logging error: " . $e->getMessage()]);
    }

    echo json_encode($result);
} else {
    echo json_encode(['error' => 'Required fields are missing in the request']);
}

// Close the connection
$conn = null;
?>
