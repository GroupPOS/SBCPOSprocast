<?php
require '../database/db_conn.php';


// Start session to get user details
session_start();
if (!isset($_SESSION['staff_id']) || !isset($_SESSION['staff_name'])) {
    echo json_encode(['status' => 'error', 'message' => 'User not logged in']);
    exit;
}

// Receive data from the request body
$received_data = json_decode(file_get_contents("php://input"), true);

// Extract common data
$order_id = $received_data['order_id'];
$user_id = $_SESSION['staff_id'];   // Get user_id from session
$user_name = $_SESSION['staff_name']; // Get user_name from session
$status = 'completed';
$overall_total = $received_data['overall_total']; // Overall total for the order

// Loop through each product and insert a record
try {
    $conn->beginTransaction(); // Start a transaction

    foreach ($received_data['prod_id'] as $index => $prod_id) {
        $prod_qty = $received_data['prod_qty'][$index];
        $prod_name = $received_data['prod_name'][$index];
        $prod_price = $received_data['prod_price'][$index];
        $prod_image = $received_data['prod_image'][$index] ?? ''; // Default to empty if not provided
        $total_price = $received_data['total_price'][$index];

        // Prepare and execute the SQL query for the sales table
        $stmt = $conn->prepare("INSERT INTO sales (order_id, user_id, user_name, prod_id, prod_qty, prod_name, prod_price, prod_image, total_price, overall_total, status) 
                                VALUES (:order_id, :user_id, :user_name, :prod_id, :prod_qty, :prod_name, :prod_price, :prod_image, :total_price, :overall_total, :status)");

        $stmt->bindParam(':order_id', $order_id);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':user_name', $user_name);
        $stmt->bindParam(':prod_id', $prod_id);
        $stmt->bindParam(':prod_qty', $prod_qty);
        $stmt->bindParam(':prod_name', $prod_name);
        $stmt->bindParam(':prod_price', $prod_price);
        $stmt->bindParam(':prod_image', $prod_image);
        $stmt->bindParam(':total_price', $total_price);
        $stmt->bindParam(':overall_total', $overall_total);
        $stmt->bindParam(':status', $status);

        $stmt->execute();

        $updateProductStmt = $conn->prepare("UPDATE products SET prod_qty = prod_qty - :prod_qty WHERE prod_id = :prod_id");
        $updateProductStmt->bindParam(':prod_qty', $prod_qty);
        $updateProductStmt->bindParam(':prod_id', $prod_id);
        $updateProductStmt->execute();
    }

    // After inserting sales, insert the log record
    $log_type = 'over the counter payment';
    $log_info = "Order ID: $order_id, Total: $overall_total";

    $log_stmt = $conn->prepare("INSERT INTO logs (user_type, user_name, user_id, log_type, log_info) VALUES (?, ?, ?, ?, ?)");
    $log_stmt->execute(['staff', $user_name, $user_id, $log_type, $log_info]);

    $conn->commit(); // Commit the transaction

    echo json_encode(['status' => 'success', 'message' => 'Payment confirmed, records inserted, and stock updated successfully.']);
} catch(PDOException $e) {
    $conn->rollBack(); // Roll back the transaction on error
    echo json_encode(['status' => 'error', 'message' => 'Failed to insert records: ' . $e->getMessage()]);
}
?>
