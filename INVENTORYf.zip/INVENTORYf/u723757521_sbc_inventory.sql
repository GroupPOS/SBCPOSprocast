-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 16, 2024 at 02:21 PM
-- Server version: 10.11.9-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u723757521_sbc_inventory`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(20) NOT NULL,
  `prod_id` varchar(200) NOT NULL,
  `prod_name` varchar(200) NOT NULL,
  `prod_image` varchar(200) NOT NULL,
  `prod_price` float(200,2) NOT NULL,
  `prod_qty` varchar(200) NOT NULL DEFAULT '1',
  `user_id` varchar(200) NOT NULL,
  `user_name` varchar(200) NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `email`
--

CREATE TABLE `email` (
  `id` int(20) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `email`
--

INSERT INTO `email` (`id`, `email`) VALUES
(1, 'sbcinventory0@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `log_id` int(11) NOT NULL,
  `user_type` varchar(200) NOT NULL,
  `user_name` varchar(200) NOT NULL,
  `user_id` varchar(200) NOT NULL,
  `log_type` varchar(200) NOT NULL,
  `log_info` varchar(200) NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`log_id`, `user_type`, `user_name`, `user_id`, `log_type`, `log_info`, `created_at`) VALUES
(3, 'staff', 'Pedro Cruz', '3', 'update credentials', 'Password updated successfully', '2024-09-16 13:43:13.892710'),
(4, 'staff', 'Pedro Cruz', '3', 'over the counter payment', 'Order ID: 829493Pedro Cruz, Total: 120.00', '2024-09-16 13:56:21.307879'),
(5, 'staff', 'Pedro Cruz', '3', 'qr checkout', 'Order ID: 2877006, Total: 200', '2024-09-16 14:03:13.698886'),
(6, 'admin', 'Juan  Dela Cruz', '1', 'logout', 'Admin Juan  Dela Cruz (ID: 1) logged out.', '2024-09-16 14:19:42.837441'),
(7, 'admin', 'Juan  Dela Cruz', '1', 'login', 'Juan  Dela Cruz logged in successfully.', '2024-09-16 14:21:10.584530'),
(8, 'user', 'Allyzandra Smith', '6', 'login', 'Allyzandra Smith logged in successfully.', '2024-09-16 14:21:32.371597'),
(9, 'staff', 'Pedro Cruz', '3', 'login', 'Pedro Cruz logged in successfully.', '2024-09-16 14:22:02.551140'),
(10, 'admin', 'Juan  Dela Cruz', '1', 'login', 'Juan  Dela Cruz logged in successfully.', '2024-09-16 14:22:19.247504'),
(11, 'user', 'Allyzandra Smith', '6', 'order_submission', 'Allyzandra Smith submitted an order with order ID 3565486', '2024-09-16 14:26:49.193962'),
(12, 'user', 'Allyzandra Smith', '6', 'rating_submission', 'Allyzandra Smith submitted ratings for product IDs: 10', '2024-09-16 14:31:35.668770'),
(13, 'user', 'Allyzandra Smith', '6', 'online_payment', 'Allyzandra Smith made a payment for Order ID: 3565486', '2024-09-16 14:39:25.175672'),
(14, 'user', 'Allyzandra Smith', '6', 'order_submission', 'Allyzandra Smith submitted an order with order ID 7117006', '2024-09-16 14:51:35.286119'),
(15, 'user', 'Allyzandra Smith', '6', 'order_cancellation', 'Allyzandra Smith cancelled Order ID: 7117006', '2024-09-16 14:51:40.352251'),
(16, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin Juan  Dela Cruz (ID: 1) added a product with Barcode: ty-16', '2024-09-16 15:09:31.817066'),
(17, 'admin', 'Juan  Dela Cruz', '1', 'update_email', 'Admin Juan  Dela Cruz (ID: 1) updated the email for User ID: 1', '2024-09-16 19:18:24.783782'),
(18, 'admin', 'Juan  Dela Cruz', '1', 'login', 'Juan  Dela Cruz logged in successfully.', '2024-09-17 12:09:15.076921'),
(19, 'staff', 'Pedro Cruz', '3', 'login', 'Pedro Cruz logged in successfully.', '2024-09-17 12:14:25.128431'),
(20, 'user', 'Allyzandra Smith', '6', 'login', 'Allyzandra Smith logged in successfully.', '2024-09-17 12:32:17.412658'),
(21, 'staff', 'Pedro Cruz', '3', 'E-payment Claim', 'Order ID: 3565486, Total: 200', '2024-09-17 14:03:45.365726'),
(22, 'admin', 'Juan  Dela Cruz', '1', 'login', 'Juan  Dela Cruz logged in successfully.', '2024-09-18 10:15:12.048804'),
(23, 'staff', 'Pedro Cruz', '3', 'login', 'Pedro Cruz logged in successfully.', '2024-09-18 11:06:01.617119'),
(24, 'staff', 'Pedro Cruz', '3', 'logout', 'User Pedro Cruz (ID: 3) logged out.', '2024-09-18 11:36:20.007171'),
(25, 'admin', 'Juan  Dela Cruz', '1', 'login', 'Juan  Dela Cruz logged in successfully.', '2024-09-18 11:36:25.633572'),
(26, 'user', 'Allyzandra Smith', '6', 'login', 'Allyzandra Smith logged in successfully.', '2024-09-19 12:21:04.995217'),
(27, 'staff', 'Pedro Cruz', '3', 'login', 'Pedro Cruz logged in successfully.', '2024-09-19 15:16:17.350416'),
(28, 'staff', 'Pedro Cruz', '3', 'update credentials', 'Password updated successfully', '2024-09-19 15:20:21.914927'),
(29, 'admin', 'Juan  Dela Cruz', '1', 'login', 'Juan  Dela Cruz logged in successfully.', '2024-09-21 11:14:17.647328'),
(30, 'admin', 'Juan  Dela Cruz', '1', 'update_user', 'Admin \"Juan  Dela Cruz\" updated user (ID: 369)', '2024-09-21 11:15:53.626061'),
(31, 'user', 'Allyzandra Smith', '6', 'login', 'Allyzandra Smith logged in successfully.', '2024-09-25 19:11:13.608912'),
(32, 'user', 'Allyzandra Smith', '6', 'logout', 'User Allyzandra Smith (ID: 6) logged out.', '2024-09-25 19:20:21.094088'),
(33, 'admin', 'Juan  Dela Cruz', '1', 'login', 'Juan  Dela Cruz logged in successfully.', '2024-09-25 19:20:26.623763'),
(34, 'admin', 'Juan  Dela Cruz', '1', 'update_void_credentials', 'Admin \"Juan  Dela Cruz\" updated void credentials for user ID: ', '2024-09-25 19:21:03.407271'),
(35, 'admin', 'Juan  Dela Cruz', '1', 'update_void_credentials', 'Admin \"Juan  Dela Cruz\" updated void credentials for user ID: ', '2024-09-25 19:21:12.643500'),
(36, 'admin', 'Juan  Dela Cruz', '1', 'update_void_credentials', 'Admin \"Juan  Dela Cruz\" updated void credentials for user ID: ', '2024-09-25 19:23:14.443158'),
(37, 'admin', 'Juan  Dela Cruz', '1', 'update_void_credentials', 'Admin \"Juan  Dela Cruz\" updated void credentials for user ID: ', '2024-09-25 19:23:32.498687'),
(38, 'admin', 'Juan  Dela Cruz', '1', 'update_credentials', 'Admin \"Juan  Dela Cruz\" updated the credentials.', '2024-09-25 19:23:49.972359'),
(39, 'admin', 'Juan  Dela Cruz', '1', 'update_credentials', 'Admin \"Juan  Dela Cruz\" updated the credentials.', '2024-09-25 19:24:32.221924'),
(40, 'admin', 'Juan  Dela Cruz', '1', 'update_credentials', 'Admin \"Juan  Dela Cruz\" updated the credentials.', '2024-09-25 19:24:57.471822'),
(41, 'admin', 'Juan  Dela Cruz', '1', 'logout', 'Admin \"Juan  Dela Cruz\" logged out.', '2024-09-25 21:07:52.591907'),
(42, 'admin', 'Juan  Dela Cruz', '1', 'login', 'Juan  Dela Cruz logged in successfully.', '2024-09-26 12:58:56.482380'),
(43, 'admin', 'Juan  Dela Cruz', '1', 'logout', 'Admin \"Juan  Dela Cruz\" logged out.', '2024-09-26 13:10:13.474211'),
(44, 'user', 'Allyzandra Smith', '6', 'login', 'Allyzandra Smith logged in successfully.', '2024-09-26 13:10:30.087071'),
(45, 'user', 'Allyzandra Smith', '6', 'logout', 'User Allyzandra Smith (ID: 6) logged out.', '2024-09-26 13:43:06.253736'),
(46, 'staff', 'Pedro Cruz', '3', 'login', 'Pedro Cruz logged in successfully.', '2024-09-26 13:43:13.162221'),
(47, 'staff', 'Pedro Cruz', '3', 'update credentials', 'Password updated successfully', '2024-09-26 13:53:23.232564'),
(48, 'staff', 'Pedro Cruz', '3', 'logout', 'User Pedro Cruz (ID: 3) logged out.', '2024-09-26 13:53:30.972170'),
(49, 'staff', 'Pedro Cruz', '3', 'login', 'Pedro Cruz logged in successfully.', '2024-09-26 13:53:49.623122'),
(50, 'staff', 'Pedro Cruz', '3', 'logout', 'User Pedro Cruz (ID: 3) logged out.', '2024-09-26 13:53:52.821876'),
(51, 'user', 'Allyzandra Smith', '6', 'login', 'Allyzandra Smith logged in successfully.', '2024-09-26 14:45:04.990685'),
(52, 'user', 'Allyzandra Smith', '6', 'logout', 'User Allyzandra Smith (ID: 6) logged out.', '2024-09-26 19:15:24.976499'),
(53, 'admin', 'Juan  Dela Cruz', '1', 'login', 'Juan  Dela Cruz logged in successfully.', '2024-09-26 19:43:58.801683'),
(54, 'admin', 'Juan  Dela Cruz', '1', 'login', 'Juan  Dela Cruz logged in successfully.', '2024-09-28 10:15:33.337409'),
(55, 'admin', 'Juan  Dela Cruz', '1', 'logout', 'Admin \"Juan  Dela Cruz\" logged out.', '2024-09-28 11:04:44.067463'),
(56, 'staff', 'Pedro Cruz', '3', 'login', 'Pedro Cruz logged in successfully.', '2024-09-28 11:05:09.075531'),
(57, 'staff', 'Pedro Cruz', '3', 'logout', 'User Pedro Cruz (ID: 3) logged out.', '2024-09-28 13:19:04.206480'),
(58, 'user', 'Allyzandra Smith', '6', 'login', 'Allyzandra Smith logged in successfully.', '2024-09-28 13:19:14.129384'),
(59, 'user', 'Allyzandra Smith', '6', 'logout', 'User Allyzandra Smith (ID: 6) logged out.', '2024-09-28 13:19:52.135626'),
(60, 'staff', 'Pedro Cruz', '3', 'login', 'Pedro Cruz logged in successfully.', '2024-09-28 13:20:04.505669'),
(61, 'staff', 'Pedro Cruz', '3', 'logout', 'User Pedro Cruz (ID: 3) logged out.', '2024-09-28 13:25:20.288301'),
(62, 'admin', 'Juan  Dela Cruz', '1', 'login', 'Juan  Dela Cruz logged in successfully.', '2024-09-28 13:47:54.031033'),
(63, 'admin', 'Juan  Dela Cruz', '1', 'logout', 'Admin \"Juan  Dela Cruz\" logged out.', '2024-09-28 20:17:17.096438'),
(64, 'admin', 'Juan  Dela Cruz', '1', 'login', 'Juan  Dela Cruz logged in successfully.', '2024-09-28 20:17:31.675739'),
(65, 'admin', 'Juan  Dela Cruz', '1', 'logout', 'Admin \"Juan  Dela Cruz\" logged out.', '2024-09-28 20:19:00.909211'),
(66, 'admin', 'Juan  Dela Cruz', '1', 'login', 'Juan  Dela Cruz logged in successfully.', '2024-09-28 20:21:09.379626'),
(67, 'admin', 'Juan  Dela Cruz', '1', 'logout', 'Admin \"Juan  Dela Cruz\" logged out.', '2024-09-28 20:29:38.092890'),
(68, 'staff', 'Pedro Cruz', '3', 'login', 'Pedro Cruz logged in successfully.', '2024-09-28 20:30:04.061502'),
(69, 'staff', 'Pedro Cruz', '3', 'logout', 'User Pedro Cruz (ID: 3) logged out.', '2024-09-28 20:32:06.722490'),
(70, 'admin', 'Juan  Dela Cruz', '1', 'login', 'Juan  Dela Cruz logged in successfully.', '2024-09-28 20:32:11.420582'),
(71, 'admin', 'Juan  Dela Cruz', '1', 'logout', 'Admin \"Juan  Dela Cruz\" logged out.', '2024-09-28 20:37:15.979619'),
(72, 'user', 'Allyzandra Smith', '6', 'login', 'Allyzandra Smith logged in successfully.', '2024-09-28 20:37:39.192356'),
(73, 'user', 'Allyzandra Smith', '6', 'login', 'Allyzandra Smith logged in successfully.', '2024-09-29 10:04:16.134669'),
(74, 'user', 'Allyzandra Smith', '6', 'order_submission', 'Allyzandra Smith submitted an order with order ID 1707236', '2024-09-29 10:09:16.929081'),
(75, 'admin', 'Juan  Dela Cruz', '1', 'login', 'Juan  Dela Cruz logged in successfully.', '2024-10-01 07:11:00.641560'),
(76, 'admin', 'Juan  Dela Cruz', '1', 'store_open', 'Store opened', '2024-10-01 08:39:56.296954'),
(77, 'staff', 'Pedro Cruz', '3', 'login', 'Pedro Cruz logged in successfully.', '2024-10-01 09:30:13.870278'),
(78, 'staff', 'Pedro Cruz', '3', 'refund', 'Product Code: 1111, Product Name: RIBBONS, Amount: 120, Reason: DEFECTIVE ITEM', '2024-10-01 14:22:01.820010'),
(79, 'staff', 'Pedro Cruz', '3', 'refund', 'Product Code: 3424234, Product Name: Ballpoint, Amount: 090239, Reason: Not working properly', '2024-10-01 18:38:06.677719'),
(80, 'staff', 'Pedro Cruz', '3', 'logout', 'User Pedro Cruz (ID: 3) logged out.', '2024-10-01 18:48:44.123531'),
(81, 'admin', 'Juan  Dela Cruz', '1', 'login', 'Juan  Dela Cruz logged in successfully.', '2024-10-01 18:48:49.378635'),
(82, 'admin', 'Juan  Dela Cruz', '1', 'logout', 'Admin \"Juan  Dela Cruz\" logged out.', '2024-10-01 18:53:52.397652'),
(83, 'staff', 'Pedro Cruz', '3', 'login', 'Pedro Cruz logged in successfully.', '2024-10-01 18:54:02.591608'),
(84, 'staff', 'Pedro Cruz', '3', 'logout', 'User Pedro Cruz (ID: 3) logged out.', '2024-10-01 18:56:35.352723'),
(85, 'admin', 'Juan  Dela Cruz', '1', 'login', 'Juan  Dela Cruz logged in successfully.', '2024-10-01 18:56:49.812981'),
(86, 'admin', 'Juan  Dela Cruz', '1', 'store_close', 'Store closed by Admin', '2024-10-01 19:01:35.044124'),
(87, 'admin', 'Juan  Dela Cruz', '1', 'store_open', 'Store opened by Admin', '2024-10-01 19:01:41.925857'),
(88, 'user', 'Anonymous', ' ', 'Signup', 'successful', '2024-10-02 12:11:32.793367'),
(89, 'user', 'Anonymous', ' ', 'Signup', 'failed - user ID exists', '2024-10-02 12:15:26.936756'),
(90, 'user', 'Anonymous', ' ', 'Signup', 'failed - user ID exists', '2024-10-02 12:16:36.384491'),
(91, 'user', 'Anonymous', ' ', 'Signup', 'successful', '2024-10-02 12:16:59.823193'),
(92, 'user', 'Anonymous', ' ', 'Signup', 'successful', '2024-10-02 12:18:41.824720'),
(93, 'user', 'Anonymous', ' ', 'Signup', 'successful', '2024-10-02 12:39:02.192386'),
(94, 'user', 'Anonymous', ' ', 'Signup', 'successful', '2024-10-02 12:40:30.771531'),
(95, 'user', 'Anonymous', ' ', 'Signup', 'successful', '2024-10-02 12:43:55.096186'),
(96, 'user', 'Anonymous', ' ', 'Signup', 'successful', '2024-10-02 12:56:54.685684'),
(97, 'admin', 'Anonymous', '18-5391-378', 'Account Approval', 'User ID 18-5391-378 was approved.', '2024-10-02 12:57:09.188173'),
(98, 'admin', 'Anonymous', '18-5391-378', 'Account Decline', 'User ID 18-5391-378 was declined.', '2024-10-02 12:57:26.899264'),
(99, 'admin', 'Juan  Dela Cruz', '1', 'login', 'Juan  Dela Cruz logged in successfully.', '2024-10-02 12:59:15.548669'),
(100, 'admin', 'Juan  Dela Cruz', '1', 'update_email', 'Admin \"Juan  Dela Cruz\" updated the email for User ID: ', '2024-10-02 05:21:09.759708'),
(101, 'admin', 'Juan  Dela Cruz', '1', 'store_close', 'Store closed by Admin', '2024-10-02 05:55:05.561365'),
(102, 'user', 'Allyzandra Smith', '6', 'login', 'Allyzandra Smith logged in successfully.', '2024-10-02 05:56:18.004570'),
(103, 'admin', 'Juan  Dela Cruz', '1', 'store_open', 'Store opened by Admin', '2024-10-02 05:56:47.218613'),
(104, 'admin', 'Juan  Dela Cruz', '1', 'store_close', 'Store closed by Admin', '2024-10-02 05:59:31.355170'),
(105, 'admin', 'Juan  Dela Cruz', '1', 'store_open', 'Store opened by Admin', '2024-10-02 05:59:43.501279'),
(106, 'staff', 'Pedro Cruz', '3', 'login', 'Pedro Cruz logged in successfully.', '2024-10-02 09:41:23.933279'),
(107, 'staff', 'Pedro Cruz', '3', 'login', 'Pedro Cruz logged in successfully.', '2024-10-02 09:43:42.139978'),
(108, 'staff', 'Pedro Cruz', '3', 'logout', 'User Pedro Cruz (ID: 3) logged out.', '2024-10-02 09:44:21.410739'),
(109, 'user', 'Allyzandra Smith', '6', 'login', 'Allyzandra Smith logged in successfully.', '2024-10-02 09:44:49.669109'),
(110, 'admin', 'Anonymous', '', 'Account Approval', 'User ID  was approved.', '2024-10-03 21:36:32.729429'),
(111, 'user', 'Allyzandra Smith', '6', 'login', 'Allyzandra Smith logged in successfully.', '2024-10-06 19:46:59.266566'),
(112, 'user', 'Allyzandra Smith', '6', 'login', 'Allyzandra Smith logged in successfully.', '2024-10-06 19:47:54.238457'),
(113, 'user', 'Allyzandra Smith', '6', 'login', 'Allyzandra Smith logged in successfully.', '2024-10-06 19:50:19.267224'),
(114, 'admin', 'Juan  Dela Cruz', '1', 'login', 'Juan  Dela Cruz logged in successfully.', '2024-10-09 14:07:00.820536'),
(115, 'admin', 'Juan  Dela Cruz', '1', 'store_close', 'Store closed by Admin', '2024-10-09 14:07:21.857245'),
(116, 'admin', 'Juan  Dela Cruz', '1', 'store_open', 'Store opened by Admin', '2024-10-09 14:07:25.391287'),
(117, 'admin', 'Juan  Dela Cruz', '1', 'login', 'Juan  Dela Cruz logged in successfully.', '2024-10-09 14:08:22.931976'),
(118, 'admin', 'Juan  Dela Cruz', '1', 'store_close', 'Store closed by Admin', '2024-10-09 14:10:14.475159'),
(119, 'admin', 'Juan  Dela Cruz', '1', 'store_open', 'Store opened by Admin', '2024-10-09 14:10:17.727068'),
(120, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 19373', '2024-10-09 14:12:00.263352'),
(121, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 8172', '2024-10-09 14:17:42.990626'),
(122, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 8172', '2024-10-09 14:22:28.707883'),
(123, 'admin', 'Juan  Dela Cruz', '1', 'product_removal', 'Admin \"Juan  Dela Cruz\" removed product with ID: 19', '2024-10-09 14:22:33.608285'),
(124, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 2834', '2024-10-09 14:22:55.836118'),
(125, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 6459', '2024-10-09 14:27:29.238030'),
(126, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 0498', '2024-10-09 14:37:02.826754'),
(127, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 0182', '2024-10-09 14:49:27.746598'),
(128, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 9394', '2024-10-09 14:53:15.105546'),
(129, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 9283', '2024-10-09 14:55:38.668656'),
(130, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 1823', '2024-10-09 14:58:07.910391'),
(131, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 1827', '2024-10-09 14:58:43.687059'),
(132, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 1203', '2024-10-09 15:03:21.087925'),
(133, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 0374', '2024-10-09 15:05:56.133445'),
(134, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 1623', '2024-10-09 15:08:30.274241'),
(135, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 9586', '2024-10-09 15:09:02.594499'),
(136, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 8574', '2024-10-09 15:11:13.859990'),
(137, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 8574', '2024-10-09 15:15:32.498495'),
(138, 'admin', 'Juan  Dela Cruz', '1', 'product_removal', 'Admin \"Juan  Dela Cruz\" removed product with ID: 33', '2024-10-09 15:15:40.251436'),
(139, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 0795', '2024-10-09 15:16:01.400551'),
(140, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 4322', '2024-10-09 15:16:27.718346'),
(141, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 5555', '2024-10-09 15:46:01.690463'),
(142, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 5555', '2024-10-09 15:50:26.933322'),
(143, 'admin', 'Juan  Dela Cruz', '1', 'product_removal', 'Admin \"Juan  Dela Cruz\" removed product with ID: 38', '2024-10-09 15:52:21.042506'),
(144, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 9785', '2024-10-09 15:52:50.178313'),
(145, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 0997', '2024-10-09 15:53:22.197785'),
(146, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 9999', '2024-10-09 15:55:13.999939'),
(147, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 1002', '2024-10-09 15:55:33.704650'),
(148, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 7777', '2024-10-09 15:55:55.915778'),
(149, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 9475', '2024-10-09 15:56:17.727399'),
(150, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 1672', '2024-10-09 15:56:54.194294'),
(151, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 7658', '2024-10-09 16:00:02.122439'),
(152, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 2222', '2024-10-09 16:00:30.892363'),
(153, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 8484', '2024-10-09 16:08:08.205875'),
(154, 'admin', 'Juan  Dela Cruz', '1', 'product_addition', 'Admin \"\" added a product with Barcode: 3942', '2024-10-09 16:08:36.209597'),
(155, 'admin', 'Juan  Dela Cruz', '1', 'logout', 'Admin \"Juan  Dela Cruz\" logged out.', '2024-10-09 16:16:33.874161'),
(156, 'staff', 'Sandro Cruz', '7', 'login', 'Sandro Cruz logged in successfully.', '2024-10-09 16:16:56.847831'),
(157, 'staff', 'Sandro Cruz', '7', 'logout', 'User Sandro Cruz (ID: 7) logged out.', '2024-10-09 16:17:02.776244'),
(158, 'admin', 'Juan  Dela Cruz', '1', 'login', 'Juan  Dela Cruz logged in successfully.', '2024-10-09 16:20:27.822563'),
(159, 'admin', 'Juan  Dela Cruz', '1', 'user_addition', 'Admin \"Juan  Dela Cruz\" added a new user with ID: 12-3845-184', '2024-10-09 16:21:06.612234'),
(160, 'admin', 'Juan  Dela Cruz', '1', 'logout', 'Admin \"Juan  Dela Cruz\" logged out.', '2024-10-09 16:21:11.651126'),
(161, 'user', 'Kian Muyco', '19', 'login', 'Kian Muyco logged in successfully.', '2024-10-09 16:21:21.604753'),
(162, 'user', 'Kian Muyco', '19', 'order_submission', 'Kian Muyco submitted an order with order ID 43463919', '2024-10-09 16:23:49.424334'),
(163, 'user', 'Kian Muyco', '19', 'online_payment', 'Kian Muyco made a payment for Order ID: 43463919', '2024-10-09 16:24:20.395755'),
(164, 'user', 'Allyzandra Smith', '6', 'login', 'Allyzandra Smith logged in successfully.', '2024-10-10 00:27:00.307958'),
(165, 'user', 'Allyzandra Smith', '6', 'order_submission', 'Allyzandra Smith submitted an order with order ID 2977706', '2024-10-10 00:27:42.600442'),
(166, 'user', 'Allyzandra Smith', '6', 'online_payment', 'Allyzandra Smith made a payment for Order ID: 2977706', '2024-10-10 00:28:49.302685'),
(167, 'user', 'Allyzandra Smith', '6', 'order_submission', 'Allyzandra Smith submitted an order with order ID 8835746', '2024-10-10 00:29:19.374525'),
(168, 'user', 'Allyzandra Smith', '6', 'online_payment', 'Allyzandra Smith made a payment for Order ID: 8835746', '2024-10-10 00:29:40.306840'),
(169, 'user', 'Allyzandra Smith', '6', 'order_submission', 'Allyzandra Smith submitted an order with order ID 1147116', '2024-10-10 00:30:20.680462'),
(170, 'user', 'Allyzandra Smith', '6', 'order_submission', 'Allyzandra Smith submitted an order with order ID 5239526', '2024-10-10 00:30:24.798549'),
(171, 'user', 'Allyzandra Smith', '6', 'order_submission', 'Allyzandra Smith submitted an order with order ID 3020476', '2024-10-10 00:30:30.872844'),
(172, 'user', 'Allyzandra Smith', '6', 'online_payment', 'Allyzandra Smith made a payment for Order ID: 3020476', '2024-10-10 00:30:56.322817'),
(173, 'user', 'Allyzandra Smith', '6', 'online_payment', 'Allyzandra Smith made a payment for Order ID: 1147116', '2024-10-10 00:31:29.345562'),
(174, 'user', 'Allyzandra Smith', '6', 'logout', 'User Allyzandra Smith (ID: 6) logged out.', '2024-10-10 00:32:06.136427'),
(175, 'user', 'Allyzandra Smith', '6', 'login', 'Allyzandra Smith logged in successfully.', '2024-10-11 02:48:50.855294'),
(176, 'user', 'Allyzandra Smith', '6', 'order_submission', 'Allyzandra Smith submitted an order with order ID 5696376', '2024-10-11 02:54:48.650544'),
(177, 'user', 'Allyzandra Smith', '6', 'order_cancellation', 'Allyzandra Smith cancelled Order ID: 5696376', '2024-10-11 02:54:59.264863'),
(178, 'user', 'Allyzandra Smith', '6', 'login', 'Allyzandra Smith logged in successfully.', '2024-10-11 02:55:41.568825'),
(179, 'user', 'Allyzandra Smith', '6', 'online_payment', 'Allyzandra Smith made a payment for Order ID: 5239526', '2024-10-11 03:27:59.391747'),
(180, 'user', 'Allyzandra Smith', '6', 'online_payment', 'Allyzandra Smith made a payment for Order ID: 5239526', '2024-10-11 03:27:59.453288'),
(181, 'user', 'Allyzandra Smith', '6', 'online_payment', 'Allyzandra Smith made a payment for Order ID: 5239526', '2024-10-11 03:27:59.749887'),
(182, 'user', 'Allyzandra Smith', '6', 'online_payment', 'Allyzandra Smith made a payment for Order ID: 5239526', '2024-10-11 03:28:01.296046'),
(183, 'user', 'Allyzandra Smith', '6', 'online_payment', 'Allyzandra Smith made a payment for Order ID: 5239526', '2024-10-11 03:28:03.054878'),
(184, 'user', 'Allyzandra Smith', '6', 'online_payment', 'Allyzandra Smith made a payment for Order ID: 5239526', '2024-10-11 03:28:05.044036'),
(185, 'user', 'Allyzandra Smith', '6', 'online_payment', 'Allyzandra Smith made a payment for Order ID: 5239526', '2024-10-11 03:28:06.490427'),
(186, 'user', 'Allyzandra Smith', '6', 'online_payment', 'Allyzandra Smith made a payment for Order ID: 5239526', '2024-10-11 03:28:07.423299'),
(187, 'user', 'Allyzandra Smith', '6', 'online_payment', 'Allyzandra Smith made a payment for Order ID: 5239526', '2024-10-11 03:28:08.959604'),
(188, 'user', 'Allyzandra Smith', '6', 'online_payment', 'Allyzandra Smith made a payment for Order ID: 5239526', '2024-10-11 03:28:14.100202'),
(189, 'user', 'Allyzandra Smith', '6', 'online_payment', 'Allyzandra Smith made a payment for Order ID: 5239526', '2024-10-11 03:28:17.545897'),
(190, 'user', 'Allyzandra Smith', '6', 'online_payment', 'Allyzandra Smith made a payment for Order ID: 5239526', '2024-10-11 03:28:19.829997'),
(191, 'user', 'Allyzandra Smith', '6', 'online_payment', 'Allyzandra Smith made a payment for Order ID: 5239526', '2024-10-11 03:28:25.659290'),
(192, 'user', 'Allyzandra Smith', '6', 'online_payment', 'Allyzandra Smith made a payment for Order ID: 5239526', '2024-10-11 03:28:27.565419'),
(193, 'user', 'Allyzandra Smith', '6', 'online_payment', 'Allyzandra Smith made a payment for Order ID: 5239526', '2024-10-11 03:28:29.337956'),
(194, 'user', 'Allyzandra Smith', '6', 'online_payment', 'Allyzandra Smith made a payment for Order ID: 1707236', '2024-10-11 03:28:45.233575'),
(195, 'user', 'Allyzandra Smith', '6', 'order_submission', 'Allyzandra Smith submitted an order with order ID 9279236', '2024-10-11 03:29:10.805107'),
(196, 'user', 'Allyzandra Smith', '6', 'order_submission', 'Allyzandra Smith submitted an order with order ID 5532786', '2024-10-11 03:29:14.707245'),
(197, 'user', 'Allyzandra Smith', '6', 'online_payment', 'Allyzandra Smith made a payment for Order ID: 5532786', '2024-10-11 03:29:30.237085'),
(198, 'user', 'Allyzandra Smith', '6', 'online_payment', 'Allyzandra Smith made a payment for Order ID: 9279236', '2024-10-11 03:29:49.258275'),
(199, 'user', 'Allyzandra Smith', '6', 'logout', 'User Allyzandra Smith (ID: 6) logged out.', '2024-10-11 03:31:20.038949'),
(200, 'user', 'Allyzandra Smith', '6', 'login', 'Allyzandra Smith logged in successfully.', '2024-10-12 14:07:59.557184'),
(201, 'user', 'Allyzandra Smith', '6', 'login', 'Allyzandra Smith logged in successfully.', '2024-10-12 17:05:48.021079'),
(202, 'admin', 'Anonymous', '', 'Account Approval', 'User ID  was approved.', '2024-10-13 01:41:06.624515'),
(203, 'admin', 'Anonymous', '', 'Account Decline', 'User ID  was declined.', '2024-10-13 01:41:07.738195'),
(204, 'admin', 'Juan  Dela Cruz', '1', 'login', 'Juan  Dela Cruz logged in successfully.', '2024-10-16 14:14:26.984837'),
(205, 'admin', 'Juan  Dela Cruz', '1', 'logout', 'Admin \"Juan  Dela Cruz\" logged out.', '2024-10-16 14:16:34.031760'),
(206, 'user', 'Allyzandra Smith', '6', 'login', 'Allyzandra Smith logged in successfully.', '2024-10-16 14:16:41.339939'),
(207, 'user', 'Allyzandra Smith', '6', 'order_submission', 'Allyzandra Smith submitted an order with order ID 8560066', '2024-10-16 14:17:08.658385'),
(208, 'user', 'Allyzandra Smith', '6', 'online_payment', 'Allyzandra Smith made a payment for Order ID: 8560066', '2024-10-16 14:17:36.758109'),
(209, 'user', 'Allyzandra Smith', '6', 'order_submission', 'Allyzandra Smith submitted an order with order ID 6749156', '2024-10-16 14:19:14.362660'),
(210, 'user', 'Allyzandra Smith', '6', 'online_payment', 'Allyzandra Smith made a payment for Order ID: 6749156', '2024-10-16 14:19:33.785226'),
(211, 'user', 'Allyzandra Smith', '6', 'logout', 'User Allyzandra Smith (ID: 6) logged out.', '2024-10-16 14:19:50.530629'),
(212, 'admin', 'Juan  Dela Cruz', '1', 'login', 'Juan  Dela Cruz logged in successfully.', '2024-10-16 14:19:59.425611'),
(213, 'admin', 'Juan  Dela Cruz', '1', 'logout', 'Admin \"Juan  Dela Cruz\" logged out.', '2024-10-16 14:20:35.336389');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `order_id` int(50) NOT NULL,
  `user_id` int(50) NOT NULL,
  `user_name` varchar(250) NOT NULL,
  `prod_id` int(50) NOT NULL,
  `prod_qty` int(50) NOT NULL,
  `prod_name` varchar(250) NOT NULL,
  `prod_price` int(50) NOT NULL,
  `prod_image` varchar(250) NOT NULL,
  `total_price` int(50) NOT NULL,
  `ordered_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `overall_total` int(50) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `order_id`, `user_id`, `user_name`, `prod_id`, `prod_qty`, `prod_name`, `prod_price`, `prod_image`, `total_price`, `ordered_at`, `overall_total`, `status`) VALUES
(1, 2147483647, 6, 'Allyzandra Smith', 11, 1, 'WHITE POLO SHIRT FOR MEN', 120, '1717295270.png', 120, '2024-06-19 14:53:27.000000', 120, 'completed'),
(2, 2147483647, 6, 'Allyzandra Smith', 14, 1, 'White Long Sleeves Uniform', 180, '1718713520.jpg', 180, '2024-06-19 14:55:03.000000', 840, 'completed'),
(24, 64672384, 6, 'Allyzandra Smith', 13, 1, 'School Skirt for Women Version 1 ', 220, '1718713149.jpg', 120, '2024-06-20 13:54:56.000000', 220, 'paid'),
(25, 68324739, 6, 'Allyzandra Smith', 10, 2, 'Id lace for all genders', 120, '1717284906.png', 120, '2024-06-20 14:02:49.000000', 460, 'completed'),
(26, 68324739, 6, 'Allyzandra Smith', 13, 1, 'School Skirt for Women Version 1 ', 220, '1718713149.jpg', 240, '2024-06-20 14:02:49.000000', 460, 'completed'),
(27, 2147483647, 6, 'Allyzandra Smith', 15, 1, 'Medal Of Honor - Bronze', 200, '1724561367.jpg', 200, '2024-09-01 08:12:23.000000', 200, 'completed'),
(28, 2147483647, 6, 'Allyzandra Smith', 10, 1, 'Id lace for all genders', 120, '1717284906.png', 120, '2024-09-05 04:10:12.000000', 520, 'completed'),
(29, 2147483647, 6, 'Allyzandra Smith', 15, 2, 'Medal Of Honor - Bronze', 200, '1724561367.jpg', 400, '2024-09-05 04:10:12.000000', 520, 'completed'),
(30, 2147483647, 6, 'Allyzandra Smith', 10, 6, 'Id lace for all genders', 120, '1717284906.png', 720, '2024-09-05 04:22:14.000000', 920, 'completed'),
(31, 2147483647, 6, 'Allyzandra Smith', 15, 1, 'Medal Of Honor - Bronze', 200, '1724561367.jpg', 200, '2024-09-05 04:22:14.000000', 920, 'completed'),
(32, 48736, 6, 'Allyzandra Smith', 10, 1, 'Id lace for all genders', 120, '1717284906.png', 120, '2024-09-05 04:23:44.000000', 1720, 'completed'),
(33, 48736, 6, 'Allyzandra Smith', 15, 8, 'Medal Of Honor - Bronze', 200, '1724561367.jpg', 1600, '2024-09-05 04:23:44.000000', 1720, 'completed'),
(34, 4482536, 6, 'Allyzandra Smith', 10, 1, 'Id lace for all genders', 120, '1717284906.png', 120, '2024-09-05 04:24:24.000000', 120, 'paid'),
(35, 9159696, 6, 'Allyzandra Smith', 10, 4, 'Id lace for all genders', 120, '1717284906.png', 480, '2024-09-05 04:27:51.000000', 480, 'completed'),
(36, 6000756, 6, 'Allyzandra Smith', 10, 1, 'Id lace for all genders', 120, '1717284906.png', 120, '2024-09-05 04:28:11.000000', 320, 'cancelled'),
(37, 6000756, 6, 'Allyzandra Smith', 15, 1, 'Medal Of Honor - Bronze', 200, '1724561367.jpg', 200, '2024-09-05 04:28:11.000000', 320, 'cancelled'),
(38, 5618666, 6, 'Allyzandra Smith', 10, 1, 'Id lace for all genders', 120, '1717284906.png', 120, '2024-09-05 04:29:15.000000', 520, 'cancelled'),
(39, 5618666, 6, 'Allyzandra Smith', 15, 2, 'Medal Of Honor - Bronze', 200, '1724561367.jpg', 400, '2024-09-05 04:29:15.000000', 520, 'cancelled'),
(40, 2184626, 6, 'Allyzandra Smith', 10, 4, 'Id lace for all genders', 120, '1717284906.png', 480, '2024-09-05 13:09:43.000000', 680, 'completed'),
(41, 2184626, 6, 'Allyzandra Smith', 15, 1, 'Medal Of Honor - Bronze', 200, '1724561367.jpg', 200, '2024-09-05 13:09:43.000000', 680, 'completed'),
(42, 5361276, 6, 'Allyzandra Smith', 10, 1, 'Id lace for all genders', 120, '1717284906.png', 120, '2024-09-16 02:44:59.000000', 120, 'completed'),
(43, 1817096, 6, 'Allyzandra Smith', 16, 1, 'Black and White 6x4 - Sticker', 200, '1726197430.png', 200, '2024-09-16 02:49:38.000000', 400, 'completed'),
(44, 1817096, 6, 'Allyzandra Smith', 15, 1, 'Medal Of Honor - Bronze', 200, '1724561367.jpg', 200, '2024-09-16 02:49:38.000000', 400, 'completed'),
(45, 4652546, 6, 'Allyzandra Smith', 16, 1, 'Black and White 6x4 - Sticker', 200, '1726197430.png', 200, '2024-09-16 05:20:56.000000', 400, 'completed'),
(46, 4652546, 6, 'Allyzandra Smith', 15, 1, 'Medal Of Honor - Bronze', 200, '1724561367.jpg', 200, '2024-09-16 05:20:56.000000', 400, 'completed'),
(47, 1574756, 6, 'Allyzandra Smith', 10, 2, 'Id lace for all genders', 120, '1717284906.png', 240, '2024-09-16 05:21:58.000000', 240, 'completed'),
(48, 2877006, 6, 'Allyzandra Smith', 16, 1, 'Black and White 6x4 - Sticker', 200, '1726197430.png', 200, '2024-09-16 06:01:16.000000', 200, 'completed'),
(49, 3565486, 6, 'Allyzandra Smith', 15, 1, 'Medal Of Honor - Bronze', 200, '1724561367.jpg', 200, '2024-09-16 06:26:49.000000', 200, 'completed'),
(50, 7117006, 6, 'Allyzandra Smith', 16, 1, 'Black and White 6x4 - Sticker', 200, '1726197430.png', 200, '2024-09-16 06:51:35.000000', 200, 'cancelled'),
(51, 1707236, 6, 'Allyzandra Smith', 10, 1, 'Id lace for all genders', 120, '1717284906.png', 0, '2024-09-29 02:09:16.000000', 200, 'paid'),
(52, 1707236, 6, 'Allyzandra Smith', 16, 1, 'Black and White 6x4 - Sticker', 200, '1726197430.png', 200, '2024-09-29 02:09:16.000000', 200, 'paid'),
(53, 43463919, 19, 'Kian Muyco', 49, 1, 'SBC Jackets ', 1000, '1728490095.jpg', 1000, '2024-10-09 16:23:48.000000', 1000, 'paid'),
(54, 2977706, 6, 'Allyzandra Smith', 46, 1, 'P.E for College', 300, '1728489523.jpg', 300, '2024-10-10 00:27:42.000000', 300, 'paid'),
(55, 8835746, 6, 'Allyzandra Smith', 15, 1, 'Medal Of Honor - Bronze', 200, '1724561367.jpg', 200, '2024-10-10 00:29:19.000000', 225, 'paid'),
(56, 8835746, 6, 'Allyzandra Smith', 17, 1, 'Ball for Kids', 25, '1726470515.jpg', 25, '2024-10-10 00:29:19.000000', 225, 'paid'),
(57, 1147116, 6, 'Allyzandra Smith', 26, 1, 'SBC umbrella set', 120, '1728485724.jfif', 120, '2024-10-10 00:30:20.000000', 120, 'paid'),
(58, 5239526, 6, 'Allyzandra Smith', 31, 1, 'SBC Cap Blue', 200, '1728486364.jfif', 200, '2024-10-10 00:30:24.000000', 200, 'paid'),
(59, 3020476, 6, 'Allyzandra Smith', 22, 1, 'SBC badge for Uniforms\n', 70, '1728484028.jfif', 70, '2024-10-10 00:30:30.000000', 70, 'paid'),
(60, 5696376, 6, 'Allyzandra Smith', 40, 1, 'P.E for Jhs', 150, '1728489183.jpg', 150, '2024-10-11 02:54:48.000000', 1890, 'cancelled'),
(61, 5696376, 6, 'Allyzandra Smith', 30, 1, 'Neck tie for Girls and Boys', 60, '1728486333.jfif', 60, '2024-10-11 02:54:48.000000', 1890, 'cancelled'),
(62, 5696376, 6, 'Allyzandra Smith', 15, 1, 'Medal Of Honor - Bronze', 200, '1724561367.jpg', 200, '2024-10-11 02:54:48.000000', 1890, 'cancelled'),
(63, 5696376, 6, 'Allyzandra Smith', 27, 1, 'Id lace ', 80, '1728485749.jfif', 80, '2024-10-11 02:54:48.000000', 1890, 'cancelled'),
(64, 5696376, 6, 'Allyzandra Smith', 47, 1, 'Key Chain', 50, '1728489614.jpg', 50, '2024-10-11 02:54:48.000000', 1890, 'cancelled'),
(65, 5696376, 6, 'Allyzandra Smith', 18, 1, 'Composition Notebook ', 50, '1728483101.jfif', 50, '2024-10-11 02:54:48.000000', 1890, 'cancelled'),
(66, 5696376, 6, 'Allyzandra Smith', 20, 1, 'Compass(circle meaasure)', 30, '1728483437.jfif', 30, '2024-10-11 02:54:48.000000', 1890, 'cancelled'),
(67, 5696376, 6, 'Allyzandra Smith', 32, 1, 'Color Pencil for sketch', 140, '1728486520.jfif', 140, '2024-10-11 02:54:48.000000', 1890, 'cancelled'),
(68, 5696376, 6, 'Allyzandra Smith', 24, 1, 'Paint Six Colors', 30, '1728485340.jfif', 30, '2024-10-11 02:54:48.000000', 1890, 'cancelled'),
(69, 5696376, 6, 'Allyzandra Smith', 35, 1, 'Painting Set', 100, '1728486947.jfif', 100, '2024-10-11 02:54:48.000000', 1890, 'cancelled'),
(70, 5696376, 6, 'Allyzandra Smith', 49, 1, 'SBC Jackets ', 1000, '1728490095.jpg', 1000, '2024-10-11 02:54:48.000000', 1890, 'cancelled'),
(71, 9279236, 6, 'Allyzandra Smith', 47, 1, 'Key Chain', 50, '1728489614.jpg', 50, '2024-10-11 03:29:10.000000', 50, 'paid'),
(72, 5532786, 6, 'Allyzandra Smith', 48, 1, 'SBC Tshirts', 250, '1728490068.jpg', 250, '2024-10-11 03:29:14.000000', 250, 'paid'),
(73, 8560066, 6, 'Allyzandra Smith', 36, 1, 'Story Book for Children', 70, '1728486970.jfif', 70, '2024-10-16 14:17:08.000000', 1070, 'paid'),
(74, 8560066, 6, 'Allyzandra Smith', 49, 1, 'SBC Jackets ', 1000, '1728490095.jpg', 1000, '2024-10-16 14:17:08.000000', 1070, 'paid'),
(75, 6749156, 6, 'Allyzandra Smith', 49, 1, 'SBC Jackets ', 1000, '1728490095.jpg', 1000, '2024-10-16 14:19:14.000000', 1000, 'paid');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `prod_id` int(11) NOT NULL,
  `barcode` varchar(150) NOT NULL,
  `prod_name` varchar(250) NOT NULL,
  `prod_price` float(50,2) NOT NULL,
  `prod_image` varchar(250) NOT NULL,
  `prod_qty` int(250) NOT NULL DEFAULT 1,
  `status` varchar(250) NOT NULL DEFAULT 'live',
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_at` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`prod_id`, `barcode`, `prod_name`, `prod_price`, `prod_image`, `prod_qty`, `status`, `created_at`, `updated_at`) VALUES
(10, '1234', 'Id lace for all genders', 120.00, '1717284906.png', 1, 'live', '2024-06-02 07:35:22.455961', '2024-08-25 12:42:45.518982'),
(15, '23456', 'Medal Of Honor - Bronze', 200.00, '1724561367.jpg', 19, 'live', '2024-08-25 12:49:41.634445', '2024-08-25 12:49:41.634445'),
(16, '00000', 'Black and White 6x4 - Sticker', 200.00, '1726197430.png', 19, 'live', '2024-09-13 11:17:25.903767', '2024-09-13 11:17:25.903767'),
(17, 'ty-16', 'Ball for Kids', 25.00, '1726470515.jpg', 39, 'live', '2024-09-16 15:09:31.814607', '2024-09-16 15:09:31.814607'),
(18, '19373', 'Composition Notebook ', 50.00, '1728483101.jfif', 100, 'live', '2024-10-09 14:12:00.262993', '2024-10-09 14:12:00.262993'),
(20, '8172', 'Compass(circle meaasure)', 30.00, '1728483437.jfif', 100, 'live', '2024-10-09 14:22:28.707581', '2024-10-09 14:22:28.707581'),
(21, '2834', 'Clear Folder', 15.00, '1728483761.jfif', 100, 'live', '2024-10-09 14:22:55.835801', '2024-10-09 14:22:55.835801'),
(22, '6459', 'SBC badge for Uniforms\n', 70.00, '1728484028.jfif', 99, 'live', '2024-10-09 14:27:29.237718', '2024-10-09 14:27:29.237718'),
(23, '0498', 'Custom Designed Notebook', 50.00, '1728484060.jfif', 100, 'live', '2024-10-09 14:37:02.826475', '2024-10-09 14:37:02.826475'),
(24, '0182', 'Paint Six Colors', 30.00, '1728485340.jfif', 100, 'live', '2024-10-09 14:49:27.746281', '2024-10-09 14:49:27.746281'),
(25, '9394', 'White Folder', 10.00, '1728485582.jfif', 100, 'live', '2024-10-09 14:53:15.105158', '2024-10-09 14:53:15.105158'),
(26, '9283', 'SBC umbrella set', 120.00, '1728485724.jfif', 99, 'live', '2024-10-09 14:55:38.668296', '2024-10-09 14:55:38.668296'),
(27, '1823', 'Id lace ', 80.00, '1728485749.jfif', 100, 'live', '2024-10-09 14:58:07.910021', '2024-10-09 14:58:07.910021'),
(28, '1827', 'Big O crayons', 60.00, '1728485905.jfif', 100, 'live', '2024-10-09 14:58:43.686753', '2024-10-09 14:58:43.686753'),
(29, '1203', 'Scissors', 40.00, '1728486187.jfif', 100, 'live', '2024-10-09 15:03:21.087610', '2024-10-09 15:03:21.087610'),
(30, '0374', 'Neck tie for Girls and Boys', 60.00, '1728486333.jfif', 100, 'live', '2024-10-09 15:05:56.133186', '2024-10-09 15:05:56.133186'),
(31, '1623', 'SBC Cap Blue', 200.00, '1728486364.jfif', 85, 'live', '2024-10-09 15:08:30.273938', '2024-10-09 15:08:30.273938'),
(32, '9586', 'Color Pencil for sketch', 140.00, '1728486520.jfif', 100, 'live', '2024-10-09 15:09:02.594250', '2024-10-09 15:09:02.594250'),
(34, '8574', 'SBC edition notebook', 80.00, '1728486557.jfif', 100, 'live', '2024-10-09 15:15:32.498200', '2024-10-09 15:15:32.498200'),
(35, '0795', 'Painting Set', 100.00, '1728486947.jfif', 100, 'live', '2024-10-09 15:16:01.400209', '2024-10-09 15:16:01.400209'),
(36, '4322', 'Story Book for Children', 70.00, '1728486970.jfif', 99, 'live', '2024-10-09 15:16:27.718024', '2024-10-09 15:16:27.718024'),
(37, '5555', 'Type c Dress for girls', 150.00, '1728488724.jpg', 100, 'live', '2024-10-09 15:46:01.690141', '2024-10-09 15:46:01.690141'),
(39, '9785', 'Type c Uniform For Jhs', 150.00, '1728489162.jpg', 100, 'live', '2024-10-09 15:52:50.178064', '2024-10-09 15:52:50.178064'),
(40, '0997', 'P.E for Jhs', 150.00, '1728489183.jpg', 100, 'live', '2024-10-09 15:53:22.197515', '2024-10-09 15:53:22.197515'),
(41, '9999', 'Uniform for Jhs type C', 150.00, '1728489298.jpg', 100, 'live', '2024-10-09 15:55:13.999691', '2024-10-09 15:55:13.999691'),
(42, '1002', 'Uniform for Elementary type C', 150.00, '1728489321.jpg', 100, 'live', '2024-10-09 15:55:33.704319', '2024-10-09 15:55:33.704319'),
(43, '7777', 'Uniform for Elementary type C Female', 150.00, '1728489343.jpg', 100, 'live', '2024-10-09 15:55:55.915544', '2024-10-09 15:55:55.915544'),
(44, '9475', 'String Bag', 200.00, '1728489364.jpg', 100, 'live', '2024-10-09 15:56:17.727037', '2024-10-09 15:56:17.727037'),
(45, '1672', 'Lunch Bag', 300.00, '1728489402.jpg', 100, 'live', '2024-10-09 15:56:54.194007', '2024-10-09 15:56:54.194007'),
(46, '7658', 'P.E for College', 300.00, '1728489523.jpg', 99, 'live', '2024-10-09 16:00:02.122117', '2024-10-09 16:00:02.122117'),
(47, '2222', 'Key Chain', 50.00, '1728489614.jpg', 99, 'live', '2024-10-09 16:00:30.892081', '2024-10-09 16:00:30.892081'),
(48, '8484', 'SBC Tshirts', 250.00, '1728490068.jpg', 99, 'live', '2024-10-09 16:08:08.205543', '2024-10-09 16:08:08.205543'),
(49, '3942', 'SBC Jackets ', 1000.00, '1728490095.jpg', 97, 'live', '2024-10-09 16:08:36.209331', '2024-10-09 16:08:36.209331');

-- --------------------------------------------------------

--
-- Table structure for table `product_forecast`
--

CREATE TABLE `product_forecast` (
  `id` int(11) NOT NULL,
  `prod_id` int(100) NOT NULL,
  `forecast_date` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `forecast_value` varchar(200) NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_forecast`
--

INSERT INTO `product_forecast` (`id`, `prod_id`, `forecast_date`, `forecast_value`, `created_at`) VALUES
(727, 13, '2024-10-02 00:00:00.000000', '340', '2024-10-01 07:56:39.113864'),
(728, 13, '2024-10-03 00:00:00.000000', '340', '2024-10-01 07:56:39.115501'),
(729, 13, '2024-10-04 00:00:00.000000', '340', '2024-10-01 07:56:39.116608'),
(730, 13, '2024-10-05 00:00:00.000000', '340', '2024-10-01 07:56:39.117588'),
(731, 13, '2024-10-06 00:00:00.000000', '340', '2024-10-01 07:56:39.118448'),
(732, 13, '2024-10-07 00:00:00.000000', '340', '2024-10-01 07:56:39.119306'),
(733, 13, '2024-10-08 00:00:00.000000', '340', '2024-10-01 07:56:39.120211'),
(734, 13, '2024-10-09 00:00:00.000000', '340', '2024-10-01 07:56:39.121100'),
(735, 13, '2024-10-10 00:00:00.000000', '340', '2024-10-01 07:56:39.121951'),
(736, 13, '2024-10-11 00:00:00.000000', '340', '2024-10-01 07:56:39.122876'),
(737, 13, '2024-10-12 00:00:00.000000', '340', '2024-10-01 07:56:39.123873'),
(738, 13, '2024-10-13 00:00:00.000000', '340', '2024-10-01 07:56:39.124931'),
(739, 13, '2024-10-14 00:00:00.000000', '340', '2024-10-01 07:56:39.125879'),
(740, 13, '2024-10-15 00:00:00.000000', '340', '2024-10-01 07:56:39.126804'),
(741, 13, '2024-10-16 00:00:00.000000', '340', '2024-10-01 07:56:39.127746'),
(742, 13, '2024-10-17 00:00:00.000000', '340', '2024-10-01 07:56:39.128709'),
(743, 13, '2024-10-18 00:00:00.000000', '340', '2024-10-01 07:56:39.129691'),
(744, 13, '2024-10-19 00:00:00.000000', '340', '2024-10-01 07:56:39.130793'),
(745, 13, '2024-10-20 00:00:00.000000', '340', '2024-10-01 07:56:39.132110'),
(746, 13, '2024-10-21 00:00:00.000000', '340', '2024-10-01 07:56:39.133055'),
(747, 13, '2024-10-22 00:00:00.000000', '340', '2024-10-01 07:56:39.133755'),
(748, 13, '2024-10-23 00:00:00.000000', '340', '2024-10-01 07:56:39.134442'),
(749, 13, '2024-10-24 00:00:00.000000', '340', '2024-10-01 07:56:39.135192'),
(750, 13, '2024-10-25 00:00:00.000000', '340', '2024-10-01 07:56:39.135965'),
(751, 13, '2024-10-26 00:00:00.000000', '340', '2024-10-01 07:56:39.136695'),
(752, 13, '2024-10-27 00:00:00.000000', '340', '2024-10-01 07:56:39.137599'),
(753, 13, '2024-10-28 00:00:00.000000', '340', '2024-10-01 07:56:39.138327'),
(754, 13, '2024-10-29 00:00:00.000000', '340', '2024-10-01 07:56:39.139093'),
(755, 13, '2024-10-30 00:00:00.000000', '340', '2024-10-01 07:56:39.139930'),
(756, 13, '2024-10-31 00:00:00.000000', '340', '2024-10-01 07:56:39.140818'),
(757, 10, '2024-10-02 00:00:00.000000', '452', '2024-10-01 07:56:39.141714'),
(758, 10, '2024-10-03 00:00:00.000000', '452', '2024-10-01 07:56:39.142574'),
(759, 10, '2024-10-04 00:00:00.000000', '452', '2024-10-01 07:56:39.143615'),
(760, 10, '2024-10-05 00:00:00.000000', '452', '2024-10-01 07:56:39.144524'),
(761, 10, '2024-10-06 00:00:00.000000', '452', '2024-10-01 07:56:39.145364'),
(762, 10, '2024-10-07 00:00:00.000000', '452', '2024-10-01 07:56:39.146330'),
(763, 10, '2024-10-08 00:00:00.000000', '452', '2024-10-01 07:56:39.147469'),
(764, 10, '2024-10-09 00:00:00.000000', '452', '2024-10-01 07:56:39.148891'),
(765, 10, '2024-10-10 00:00:00.000000', '452', '2024-10-01 07:56:39.150033'),
(766, 10, '2024-10-11 00:00:00.000000', '452', '2024-10-01 07:56:39.151040'),
(767, 10, '2024-10-12 00:00:00.000000', '452', '2024-10-01 07:56:39.151995'),
(768, 10, '2024-10-13 00:00:00.000000', '452', '2024-10-01 07:56:39.152904'),
(769, 10, '2024-10-14 00:00:00.000000', '452', '2024-10-01 07:56:39.153792'),
(770, 10, '2024-10-15 00:00:00.000000', '452', '2024-10-01 07:56:39.154680'),
(771, 10, '2024-10-16 00:00:00.000000', '452', '2024-10-01 07:56:39.155516'),
(772, 10, '2024-10-17 00:00:00.000000', '452', '2024-10-01 07:56:39.156327'),
(773, 10, '2024-10-18 00:00:00.000000', '452', '2024-10-01 07:56:39.157110'),
(774, 10, '2024-10-19 00:00:00.000000', '452', '2024-10-01 07:56:39.157855'),
(775, 10, '2024-10-20 00:00:00.000000', '452', '2024-10-01 07:56:39.158599'),
(776, 10, '2024-10-21 00:00:00.000000', '452', '2024-10-01 07:56:39.159339'),
(777, 10, '2024-10-22 00:00:00.000000', '452', '2024-10-01 07:56:39.160170'),
(778, 10, '2024-10-23 00:00:00.000000', '452', '2024-10-01 07:56:39.160923'),
(779, 10, '2024-10-24 00:00:00.000000', '452', '2024-10-01 07:56:39.161655'),
(780, 10, '2024-10-25 00:00:00.000000', '452', '2024-10-01 07:56:39.162422'),
(781, 10, '2024-10-26 00:00:00.000000', '452', '2024-10-01 07:56:39.163311'),
(782, 10, '2024-10-27 00:00:00.000000', '452', '2024-10-01 07:56:39.164573'),
(783, 10, '2024-10-28 00:00:00.000000', '452', '2024-10-01 07:56:39.165715'),
(784, 10, '2024-10-29 00:00:00.000000', '452', '2024-10-01 07:56:39.166712'),
(785, 10, '2024-10-30 00:00:00.000000', '452', '2024-10-01 07:56:39.167665'),
(786, 10, '2024-10-31 00:00:00.000000', '452', '2024-10-01 07:56:39.169160'),
(787, 15, '2024-10-02 00:00:00.000000', '448', '2024-10-01 07:56:39.170233'),
(788, 15, '2024-10-03 00:00:00.000000', '448', '2024-10-01 07:56:39.171129'),
(789, 15, '2024-10-04 00:00:00.000000', '448', '2024-10-01 07:56:39.171955'),
(790, 15, '2024-10-05 00:00:00.000000', '448', '2024-10-01 07:56:39.172729'),
(791, 15, '2024-10-06 00:00:00.000000', '448', '2024-10-01 07:56:39.173422'),
(792, 15, '2024-10-07 00:00:00.000000', '448', '2024-10-01 07:56:39.174105'),
(793, 15, '2024-10-08 00:00:00.000000', '448', '2024-10-01 07:56:39.174859'),
(794, 15, '2024-10-09 00:00:00.000000', '448', '2024-10-01 07:56:39.175643'),
(795, 15, '2024-10-10 00:00:00.000000', '448', '2024-10-01 07:56:39.176386'),
(796, 15, '2024-10-11 00:00:00.000000', '448', '2024-10-01 07:56:39.177129'),
(797, 15, '2024-10-12 00:00:00.000000', '448', '2024-10-01 07:56:39.177878'),
(798, 15, '2024-10-13 00:00:00.000000', '448', '2024-10-01 07:56:39.178674'),
(799, 15, '2024-10-14 00:00:00.000000', '448', '2024-10-01 07:56:39.179504'),
(800, 15, '2024-10-15 00:00:00.000000', '448', '2024-10-01 07:56:39.180658'),
(801, 15, '2024-10-16 00:00:00.000000', '448', '2024-10-01 07:56:39.181946'),
(802, 15, '2024-10-17 00:00:00.000000', '448', '2024-10-01 07:56:39.183069'),
(803, 15, '2024-10-18 00:00:00.000000', '448', '2024-10-01 07:56:39.184047'),
(804, 15, '2024-10-19 00:00:00.000000', '448', '2024-10-01 07:56:39.184868'),
(805, 15, '2024-10-20 00:00:00.000000', '448', '2024-10-01 07:56:39.185599'),
(806, 15, '2024-10-21 00:00:00.000000', '448', '2024-10-01 07:56:39.186642'),
(807, 15, '2024-10-22 00:00:00.000000', '448', '2024-10-01 07:56:39.187422'),
(808, 15, '2024-10-23 00:00:00.000000', '448', '2024-10-01 07:56:39.188217'),
(809, 15, '2024-10-24 00:00:00.000000', '448', '2024-10-01 07:56:39.188962'),
(810, 15, '2024-10-25 00:00:00.000000', '448', '2024-10-01 07:56:39.189745'),
(811, 15, '2024-10-26 00:00:00.000000', '448', '2024-10-01 07:56:39.190609'),
(812, 15, '2024-10-27 00:00:00.000000', '448', '2024-10-01 07:56:39.191502'),
(813, 15, '2024-10-28 00:00:00.000000', '448', '2024-10-01 07:56:39.192340'),
(814, 15, '2024-10-29 00:00:00.000000', '448', '2024-10-01 07:56:39.193157'),
(815, 15, '2024-10-30 00:00:00.000000', '448', '2024-10-01 07:56:39.194010'),
(816, 15, '2024-10-31 00:00:00.000000', '448', '2024-10-01 07:56:39.194918'),
(817, 16, '2024-10-02 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.195790'),
(818, 16, '2024-10-03 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.196826'),
(819, 16, '2024-10-04 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.198426'),
(820, 16, '2024-10-05 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.199565'),
(821, 16, '2024-10-06 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.200626'),
(822, 16, '2024-10-07 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.201473'),
(823, 16, '2024-10-08 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.202427'),
(824, 16, '2024-10-09 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.203218'),
(825, 16, '2024-10-10 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.203967'),
(826, 16, '2024-10-11 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.204687'),
(827, 16, '2024-10-12 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.205401'),
(828, 16, '2024-10-13 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.206185'),
(829, 16, '2024-10-14 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.206969'),
(830, 16, '2024-10-15 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.207713'),
(831, 16, '2024-10-16 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.208457'),
(832, 16, '2024-10-17 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.209154'),
(833, 16, '2024-10-18 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.209873'),
(834, 16, '2024-10-19 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.210619'),
(835, 16, '2024-10-20 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.211301'),
(836, 16, '2024-10-21 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.211973'),
(837, 16, '2024-10-22 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.212796'),
(838, 16, '2024-10-23 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.213777'),
(839, 16, '2024-10-24 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.214883'),
(840, 16, '2024-10-25 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.216012'),
(841, 16, '2024-10-26 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.217014'),
(842, 16, '2024-10-27 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.217929'),
(843, 16, '2024-10-28 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.218903'),
(844, 16, '2024-10-29 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.219759'),
(845, 16, '2024-10-30 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.220515'),
(846, 16, '2024-10-31 00:00:00.000000', '333.33333333333', '2024-10-01 07:56:39.221280'),
(847, 11, '2024-10-02 00:00:00.000000', '120', '2024-10-01 07:56:39.222059'),
(848, 11, '2024-10-03 00:00:00.000000', '120', '2024-10-01 07:56:39.222815'),
(849, 11, '2024-10-04 00:00:00.000000', '120', '2024-10-01 07:56:39.223557'),
(850, 11, '2024-10-05 00:00:00.000000', '120', '2024-10-01 07:56:39.224217'),
(851, 11, '2024-10-06 00:00:00.000000', '120', '2024-10-01 07:56:39.224919'),
(852, 11, '2024-10-07 00:00:00.000000', '120', '2024-10-01 07:56:39.225630'),
(853, 11, '2024-10-08 00:00:00.000000', '120', '2024-10-01 07:56:39.226331'),
(854, 11, '2024-10-09 00:00:00.000000', '120', '2024-10-01 07:56:39.227065'),
(855, 11, '2024-10-10 00:00:00.000000', '120', '2024-10-01 07:56:39.227817'),
(856, 11, '2024-10-11 00:00:00.000000', '120', '2024-10-01 07:56:39.228550'),
(857, 11, '2024-10-12 00:00:00.000000', '120', '2024-10-01 07:56:39.229305'),
(858, 11, '2024-10-13 00:00:00.000000', '120', '2024-10-01 07:56:39.230558'),
(859, 11, '2024-10-14 00:00:00.000000', '120', '2024-10-01 07:56:39.231893'),
(860, 11, '2024-10-15 00:00:00.000000', '120', '2024-10-01 07:56:39.233387'),
(861, 11, '2024-10-16 00:00:00.000000', '120', '2024-10-01 07:56:39.234323'),
(862, 11, '2024-10-17 00:00:00.000000', '120', '2024-10-01 07:56:39.235171'),
(863, 11, '2024-10-18 00:00:00.000000', '120', '2024-10-01 07:56:39.235932'),
(864, 11, '2024-10-19 00:00:00.000000', '120', '2024-10-01 07:56:39.236706'),
(865, 11, '2024-10-20 00:00:00.000000', '120', '2024-10-01 07:56:39.237432'),
(866, 11, '2024-10-21 00:00:00.000000', '120', '2024-10-01 07:56:39.238098'),
(867, 11, '2024-10-22 00:00:00.000000', '120', '2024-10-01 07:56:39.238767'),
(868, 11, '2024-10-23 00:00:00.000000', '120', '2024-10-01 07:56:39.239510'),
(869, 11, '2024-10-24 00:00:00.000000', '120', '2024-10-01 07:56:39.240221'),
(870, 11, '2024-10-25 00:00:00.000000', '120', '2024-10-01 07:56:39.240971'),
(871, 11, '2024-10-26 00:00:00.000000', '120', '2024-10-01 07:56:39.241723'),
(872, 11, '2024-10-27 00:00:00.000000', '120', '2024-10-01 07:56:39.242502'),
(873, 11, '2024-10-28 00:00:00.000000', '120', '2024-10-01 07:56:39.243266'),
(874, 11, '2024-10-29 00:00:00.000000', '120', '2024-10-01 07:56:39.243988'),
(875, 11, '2024-10-30 00:00:00.000000', '120', '2024-10-01 07:56:39.244646'),
(876, 11, '2024-10-31 00:00:00.000000', '120', '2024-10-01 07:56:39.245329'),
(877, 14, '2024-10-02 00:00:00.000000', '840', '2024-10-01 07:56:39.246091'),
(878, 14, '2024-10-03 00:00:00.000000', '840', '2024-10-01 07:56:39.247053'),
(879, 14, '2024-10-04 00:00:00.000000', '840', '2024-10-01 07:56:39.248166'),
(880, 14, '2024-10-05 00:00:00.000000', '840', '2024-10-01 07:56:39.249145'),
(881, 14, '2024-10-06 00:00:00.000000', '840', '2024-10-01 07:56:39.250292'),
(882, 14, '2024-10-07 00:00:00.000000', '840', '2024-10-01 07:56:39.251358'),
(883, 14, '2024-10-08 00:00:00.000000', '840', '2024-10-01 07:56:39.252145'),
(884, 14, '2024-10-09 00:00:00.000000', '840', '2024-10-01 07:56:39.252951'),
(885, 14, '2024-10-10 00:00:00.000000', '840', '2024-10-01 07:56:39.253722'),
(886, 14, '2024-10-11 00:00:00.000000', '840', '2024-10-01 07:56:39.254493'),
(887, 14, '2024-10-12 00:00:00.000000', '840', '2024-10-01 07:56:39.255221'),
(888, 14, '2024-10-13 00:00:00.000000', '840', '2024-10-01 07:56:39.255939'),
(889, 14, '2024-10-14 00:00:00.000000', '840', '2024-10-01 07:56:39.256667'),
(890, 14, '2024-10-15 00:00:00.000000', '840', '2024-10-01 07:56:39.257486'),
(891, 14, '2024-10-16 00:00:00.000000', '840', '2024-10-01 07:56:39.258240'),
(892, 14, '2024-10-17 00:00:00.000000', '840', '2024-10-01 07:56:39.258988'),
(893, 14, '2024-10-18 00:00:00.000000', '840', '2024-10-01 07:56:39.259669'),
(894, 14, '2024-10-19 00:00:00.000000', '840', '2024-10-01 07:56:39.260367'),
(895, 14, '2024-10-20 00:00:00.000000', '840', '2024-10-01 07:56:39.261122'),
(896, 14, '2024-10-21 00:00:00.000000', '840', '2024-10-01 07:56:39.261818'),
(897, 14, '2024-10-22 00:00:00.000000', '840', '2024-10-01 07:56:39.262526'),
(898, 14, '2024-10-23 00:00:00.000000', '840', '2024-10-01 07:56:39.263607'),
(899, 14, '2024-10-24 00:00:00.000000', '840', '2024-10-01 07:56:39.264801'),
(900, 14, '2024-10-25 00:00:00.000000', '840', '2024-10-01 07:56:39.265830'),
(901, 14, '2024-10-26 00:00:00.000000', '840', '2024-10-01 07:56:39.266749'),
(902, 14, '2024-10-27 00:00:00.000000', '840', '2024-10-01 07:56:39.267542'),
(903, 14, '2024-10-28 00:00:00.000000', '840', '2024-10-01 07:56:39.268288'),
(904, 14, '2024-10-29 00:00:00.000000', '840', '2024-10-01 07:56:39.269023'),
(905, 14, '2024-10-30 00:00:00.000000', '840', '2024-10-01 07:56:39.269751'),
(906, 14, '2024-10-31 00:00:00.000000', '840', '2024-10-01 07:56:39.270527'),
(907, 13, '2024-10-03 00:00:00.000000', '340', '2024-10-02 12:59:16.101517'),
(908, 13, '2024-10-04 00:00:00.000000', '340', '2024-10-02 12:59:16.103335'),
(909, 13, '2024-10-05 00:00:00.000000', '340', '2024-10-02 12:59:16.104804'),
(910, 13, '2024-10-06 00:00:00.000000', '340', '2024-10-02 12:59:16.106301'),
(911, 13, '2024-10-07 00:00:00.000000', '340', '2024-10-02 12:59:16.107803'),
(912, 13, '2024-10-08 00:00:00.000000', '340', '2024-10-02 12:59:16.109258'),
(913, 13, '2024-10-09 00:00:00.000000', '340', '2024-10-02 12:59:16.110558'),
(914, 13, '2024-10-10 00:00:00.000000', '340', '2024-10-02 12:59:16.111830'),
(915, 13, '2024-10-11 00:00:00.000000', '340', '2024-10-02 12:59:16.113130'),
(916, 13, '2024-10-12 00:00:00.000000', '340', '2024-10-02 12:59:16.114863'),
(917, 13, '2024-10-13 00:00:00.000000', '340', '2024-10-02 12:59:16.116661'),
(918, 13, '2024-10-14 00:00:00.000000', '340', '2024-10-02 12:59:16.118252'),
(919, 13, '2024-10-15 00:00:00.000000', '340', '2024-10-02 12:59:16.119786'),
(920, 13, '2024-10-16 00:00:00.000000', '340', '2024-10-02 12:59:16.121463'),
(921, 13, '2024-10-17 00:00:00.000000', '340', '2024-10-02 12:59:16.123042'),
(922, 13, '2024-10-18 00:00:00.000000', '340', '2024-10-02 12:59:16.124516'),
(923, 13, '2024-10-19 00:00:00.000000', '340', '2024-10-02 12:59:16.126056'),
(924, 13, '2024-10-20 00:00:00.000000', '340', '2024-10-02 12:59:16.127659'),
(925, 13, '2024-10-21 00:00:00.000000', '340', '2024-10-02 12:59:16.129340'),
(926, 13, '2024-10-22 00:00:00.000000', '340', '2024-10-02 12:59:16.130522'),
(927, 13, '2024-10-23 00:00:00.000000', '340', '2024-10-02 12:59:16.132228'),
(928, 13, '2024-10-24 00:00:00.000000', '340', '2024-10-02 12:59:16.133933'),
(929, 13, '2024-10-25 00:00:00.000000', '340', '2024-10-02 12:59:16.135201'),
(930, 13, '2024-10-26 00:00:00.000000', '340', '2024-10-02 12:59:16.136822'),
(931, 13, '2024-10-27 00:00:00.000000', '340', '2024-10-02 12:59:16.138430'),
(932, 13, '2024-10-28 00:00:00.000000', '340', '2024-10-02 12:59:16.139692'),
(933, 13, '2024-10-29 00:00:00.000000', '340', '2024-10-02 12:59:16.140852'),
(934, 13, '2024-10-30 00:00:00.000000', '340', '2024-10-02 12:59:16.142246'),
(935, 13, '2024-10-31 00:00:00.000000', '340', '2024-10-02 12:59:16.143809'),
(936, 13, '2024-11-01 00:00:00.000000', '340', '2024-10-02 12:59:16.145534'),
(937, 10, '2024-10-03 00:00:00.000000', '452', '2024-10-02 12:59:16.147171'),
(938, 10, '2024-10-04 00:00:00.000000', '452', '2024-10-02 12:59:16.149027'),
(939, 10, '2024-10-05 00:00:00.000000', '452', '2024-10-02 12:59:16.150583'),
(940, 10, '2024-10-06 00:00:00.000000', '452', '2024-10-02 12:59:16.152084'),
(941, 10, '2024-10-07 00:00:00.000000', '452', '2024-10-02 12:59:16.153605'),
(942, 10, '2024-10-08 00:00:00.000000', '452', '2024-10-02 12:59:16.155068'),
(943, 10, '2024-10-09 00:00:00.000000', '452', '2024-10-02 12:59:16.156687'),
(944, 10, '2024-10-10 00:00:00.000000', '452', '2024-10-02 12:59:16.158213'),
(945, 10, '2024-10-11 00:00:00.000000', '452', '2024-10-02 12:59:16.159551'),
(946, 10, '2024-10-12 00:00:00.000000', '452', '2024-10-02 12:59:16.160878'),
(947, 10, '2024-10-13 00:00:00.000000', '452', '2024-10-02 12:59:16.162325'),
(948, 10, '2024-10-14 00:00:00.000000', '452', '2024-10-02 12:59:16.164096'),
(949, 10, '2024-10-15 00:00:00.000000', '452', '2024-10-02 12:59:16.166595'),
(950, 10, '2024-10-16 00:00:00.000000', '452', '2024-10-02 12:59:16.168167'),
(951, 10, '2024-10-17 00:00:00.000000', '452', '2024-10-02 12:59:16.169522'),
(952, 10, '2024-10-18 00:00:00.000000', '452', '2024-10-02 12:59:16.171007'),
(953, 10, '2024-10-19 00:00:00.000000', '452', '2024-10-02 12:59:16.172340'),
(954, 10, '2024-10-20 00:00:00.000000', '452', '2024-10-02 12:59:16.173734'),
(955, 10, '2024-10-21 00:00:00.000000', '452', '2024-10-02 12:59:16.175159'),
(956, 10, '2024-10-22 00:00:00.000000', '452', '2024-10-02 12:59:16.176613'),
(957, 10, '2024-10-23 00:00:00.000000', '452', '2024-10-02 12:59:16.178023'),
(958, 10, '2024-10-24 00:00:00.000000', '452', '2024-10-02 12:59:16.179396'),
(959, 10, '2024-10-25 00:00:00.000000', '452', '2024-10-02 12:59:16.181250'),
(960, 10, '2024-10-26 00:00:00.000000', '452', '2024-10-02 12:59:16.183067'),
(961, 10, '2024-10-27 00:00:00.000000', '452', '2024-10-02 12:59:16.184473'),
(962, 10, '2024-10-28 00:00:00.000000', '452', '2024-10-02 12:59:16.185868'),
(963, 10, '2024-10-29 00:00:00.000000', '452', '2024-10-02 12:59:16.187157'),
(964, 10, '2024-10-30 00:00:00.000000', '452', '2024-10-02 12:59:16.188439'),
(965, 10, '2024-10-31 00:00:00.000000', '452', '2024-10-02 12:59:16.189733'),
(966, 10, '2024-11-01 00:00:00.000000', '452', '2024-10-02 12:59:16.191014'),
(967, 15, '2024-10-03 00:00:00.000000', '448', '2024-10-02 12:59:16.192348'),
(968, 15, '2024-10-04 00:00:00.000000', '448', '2024-10-02 12:59:16.193687'),
(969, 15, '2024-10-05 00:00:00.000000', '448', '2024-10-02 12:59:16.195158'),
(970, 15, '2024-10-06 00:00:00.000000', '448', '2024-10-02 12:59:16.196568'),
(971, 15, '2024-10-07 00:00:00.000000', '448', '2024-10-02 12:59:16.198136'),
(972, 15, '2024-10-08 00:00:00.000000', '448', '2024-10-02 12:59:16.199669'),
(973, 15, '2024-10-09 00:00:00.000000', '448', '2024-10-02 12:59:16.200972'),
(974, 15, '2024-10-10 00:00:00.000000', '448', '2024-10-02 12:59:16.202320'),
(975, 15, '2024-10-11 00:00:00.000000', '448', '2024-10-02 12:59:16.203669'),
(976, 15, '2024-10-12 00:00:00.000000', '448', '2024-10-02 12:59:16.204814'),
(977, 15, '2024-10-13 00:00:00.000000', '448', '2024-10-02 12:59:16.205848'),
(978, 15, '2024-10-14 00:00:00.000000', '448', '2024-10-02 12:59:16.207102'),
(979, 15, '2024-10-15 00:00:00.000000', '448', '2024-10-02 12:59:16.208686'),
(980, 15, '2024-10-16 00:00:00.000000', '448', '2024-10-02 12:59:16.209911'),
(981, 15, '2024-10-17 00:00:00.000000', '448', '2024-10-02 12:59:16.211358'),
(982, 15, '2024-10-18 00:00:00.000000', '448', '2024-10-02 12:59:16.212886'),
(983, 15, '2024-10-19 00:00:00.000000', '448', '2024-10-02 12:59:16.214692'),
(984, 15, '2024-10-20 00:00:00.000000', '448', '2024-10-02 12:59:16.216044'),
(985, 15, '2024-10-21 00:00:00.000000', '448', '2024-10-02 12:59:16.217388'),
(986, 15, '2024-10-22 00:00:00.000000', '448', '2024-10-02 12:59:16.219297'),
(987, 15, '2024-10-23 00:00:00.000000', '448', '2024-10-02 12:59:16.221030'),
(988, 15, '2024-10-24 00:00:00.000000', '448', '2024-10-02 12:59:16.222684'),
(989, 15, '2024-10-25 00:00:00.000000', '448', '2024-10-02 12:59:16.224331'),
(990, 15, '2024-10-26 00:00:00.000000', '448', '2024-10-02 12:59:16.225754'),
(991, 15, '2024-10-27 00:00:00.000000', '448', '2024-10-02 12:59:16.227144'),
(992, 15, '2024-10-28 00:00:00.000000', '448', '2024-10-02 12:59:16.228631'),
(993, 15, '2024-10-29 00:00:00.000000', '448', '2024-10-02 12:59:16.230187'),
(994, 15, '2024-10-30 00:00:00.000000', '448', '2024-10-02 12:59:16.232791'),
(995, 15, '2024-10-31 00:00:00.000000', '448', '2024-10-02 12:59:16.234464'),
(996, 15, '2024-11-01 00:00:00.000000', '448', '2024-10-02 12:59:16.235969'),
(997, 16, '2024-10-03 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.237586'),
(998, 16, '2024-10-04 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.239065'),
(999, 16, '2024-10-05 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.240248'),
(1000, 16, '2024-10-06 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.241461'),
(1001, 16, '2024-10-07 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.242684'),
(1002, 16, '2024-10-08 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.244194'),
(1003, 16, '2024-10-09 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.245449'),
(1004, 16, '2024-10-10 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.246765'),
(1005, 16, '2024-10-11 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.249162'),
(1006, 16, '2024-10-12 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.250552'),
(1007, 16, '2024-10-13 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.251857'),
(1008, 16, '2024-10-14 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.253124'),
(1009, 16, '2024-10-15 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.254361'),
(1010, 16, '2024-10-16 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.255918'),
(1011, 16, '2024-10-17 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.257183'),
(1012, 16, '2024-10-18 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.258269'),
(1013, 16, '2024-10-19 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.259340'),
(1014, 16, '2024-10-20 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.260505'),
(1015, 16, '2024-10-21 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.261667'),
(1016, 16, '2024-10-22 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.262846'),
(1017, 16, '2024-10-23 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.264010'),
(1018, 16, '2024-10-24 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.265666'),
(1019, 16, '2024-10-25 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.266949'),
(1020, 16, '2024-10-26 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.268383'),
(1021, 16, '2024-10-27 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.269531'),
(1022, 16, '2024-10-28 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.270621'),
(1023, 16, '2024-10-29 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.271653'),
(1024, 16, '2024-10-30 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.272641'),
(1025, 16, '2024-10-31 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.273652'),
(1026, 16, '2024-11-01 00:00:00.000000', '333.33333333333', '2024-10-02 12:59:16.274707'),
(1027, 11, '2024-10-03 00:00:00.000000', '120', '2024-10-02 12:59:16.275746'),
(1028, 11, '2024-10-04 00:00:00.000000', '120', '2024-10-02 12:59:16.276756'),
(1029, 11, '2024-10-05 00:00:00.000000', '120', '2024-10-02 12:59:16.277825'),
(1030, 11, '2024-10-06 00:00:00.000000', '120', '2024-10-02 12:59:16.279097'),
(1031, 11, '2024-10-07 00:00:00.000000', '120', '2024-10-02 12:59:16.280371'),
(1032, 11, '2024-10-08 00:00:00.000000', '120', '2024-10-02 12:59:16.282483'),
(1033, 11, '2024-10-09 00:00:00.000000', '120', '2024-10-02 12:59:16.284020'),
(1034, 11, '2024-10-10 00:00:00.000000', '120', '2024-10-02 12:59:16.285334'),
(1035, 11, '2024-10-11 00:00:00.000000', '120', '2024-10-02 12:59:16.286808'),
(1036, 11, '2024-10-12 00:00:00.000000', '120', '2024-10-02 12:59:16.288147'),
(1037, 11, '2024-10-13 00:00:00.000000', '120', '2024-10-02 12:59:16.289490'),
(1038, 11, '2024-10-14 00:00:00.000000', '120', '2024-10-02 12:59:16.290566'),
(1039, 11, '2024-10-15 00:00:00.000000', '120', '2024-10-02 12:59:16.291668'),
(1040, 11, '2024-10-16 00:00:00.000000', '120', '2024-10-02 12:59:16.294016'),
(1041, 11, '2024-10-17 00:00:00.000000', '120', '2024-10-02 12:59:16.295129'),
(1042, 11, '2024-10-18 00:00:00.000000', '120', '2024-10-02 12:59:16.296116'),
(1043, 11, '2024-10-19 00:00:00.000000', '120', '2024-10-02 12:59:16.297112'),
(1044, 11, '2024-10-20 00:00:00.000000', '120', '2024-10-02 12:59:16.298809'),
(1045, 11, '2024-10-21 00:00:00.000000', '120', '2024-10-02 12:59:16.300275'),
(1046, 11, '2024-10-22 00:00:00.000000', '120', '2024-10-02 12:59:16.301319'),
(1047, 11, '2024-10-23 00:00:00.000000', '120', '2024-10-02 12:59:16.302394'),
(1048, 11, '2024-10-24 00:00:00.000000', '120', '2024-10-02 12:59:16.303488'),
(1049, 11, '2024-10-25 00:00:00.000000', '120', '2024-10-02 12:59:16.304493'),
(1050, 11, '2024-10-26 00:00:00.000000', '120', '2024-10-02 12:59:16.305358'),
(1051, 11, '2024-10-27 00:00:00.000000', '120', '2024-10-02 12:59:16.306155'),
(1052, 11, '2024-10-28 00:00:00.000000', '120', '2024-10-02 12:59:16.306964'),
(1053, 11, '2024-10-29 00:00:00.000000', '120', '2024-10-02 12:59:16.307833'),
(1054, 11, '2024-10-30 00:00:00.000000', '120', '2024-10-02 12:59:16.308676'),
(1055, 11, '2024-10-31 00:00:00.000000', '120', '2024-10-02 12:59:16.309610'),
(1056, 11, '2024-11-01 00:00:00.000000', '120', '2024-10-02 12:59:16.310794'),
(1057, 14, '2024-10-03 00:00:00.000000', '840', '2024-10-02 12:59:16.312048'),
(1058, 14, '2024-10-04 00:00:00.000000', '840', '2024-10-02 12:59:16.312993'),
(1059, 14, '2024-10-05 00:00:00.000000', '840', '2024-10-02 12:59:16.313961'),
(1060, 14, '2024-10-06 00:00:00.000000', '840', '2024-10-02 12:59:16.315346'),
(1061, 14, '2024-10-07 00:00:00.000000', '840', '2024-10-02 12:59:16.316566'),
(1062, 14, '2024-10-08 00:00:00.000000', '840', '2024-10-02 12:59:16.317584'),
(1063, 14, '2024-10-09 00:00:00.000000', '840', '2024-10-02 12:59:16.318440'),
(1064, 14, '2024-10-10 00:00:00.000000', '840', '2024-10-02 12:59:16.319295'),
(1065, 14, '2024-10-11 00:00:00.000000', '840', '2024-10-02 12:59:16.320084'),
(1066, 14, '2024-10-12 00:00:00.000000', '840', '2024-10-02 12:59:16.321090'),
(1067, 14, '2024-10-13 00:00:00.000000', '840', '2024-10-02 12:59:16.321877'),
(1068, 14, '2024-10-14 00:00:00.000000', '840', '2024-10-02 12:59:16.322666'),
(1069, 14, '2024-10-15 00:00:00.000000', '840', '2024-10-02 12:59:16.323508'),
(1070, 14, '2024-10-16 00:00:00.000000', '840', '2024-10-02 12:59:16.324368'),
(1071, 14, '2024-10-17 00:00:00.000000', '840', '2024-10-02 12:59:16.325256'),
(1072, 14, '2024-10-18 00:00:00.000000', '840', '2024-10-02 12:59:16.326103'),
(1073, 14, '2024-10-19 00:00:00.000000', '840', '2024-10-02 12:59:16.327010'),
(1074, 14, '2024-10-20 00:00:00.000000', '840', '2024-10-02 12:59:16.327933'),
(1075, 14, '2024-10-21 00:00:00.000000', '840', '2024-10-02 12:59:16.329035'),
(1076, 14, '2024-10-22 00:00:00.000000', '840', '2024-10-02 12:59:16.329962'),
(1077, 14, '2024-10-23 00:00:00.000000', '840', '2024-10-02 12:59:16.330985'),
(1078, 14, '2024-10-24 00:00:00.000000', '840', '2024-10-02 12:59:16.332500'),
(1079, 14, '2024-10-25 00:00:00.000000', '840', '2024-10-02 12:59:16.333499'),
(1080, 14, '2024-10-26 00:00:00.000000', '840', '2024-10-02 12:59:16.334485'),
(1081, 14, '2024-10-27 00:00:00.000000', '840', '2024-10-02 12:59:16.335356'),
(1082, 14, '2024-10-28 00:00:00.000000', '840', '2024-10-02 12:59:16.336154'),
(1083, 14, '2024-10-29 00:00:00.000000', '840', '2024-10-02 12:59:16.337335'),
(1084, 14, '2024-10-30 00:00:00.000000', '840', '2024-10-02 12:59:16.338183'),
(1085, 14, '2024-10-31 00:00:00.000000', '840', '2024-10-02 12:59:16.338982'),
(1086, 14, '2024-11-01 00:00:00.000000', '840', '2024-10-02 12:59:16.339812'),
(1087, 13, '2024-10-10 00:00:00.000000', '340', '2024-10-09 14:07:01.911741'),
(1088, 13, '2024-10-11 00:00:00.000000', '340', '2024-10-09 14:07:01.911869'),
(1089, 13, '2024-10-12 00:00:00.000000', '340', '2024-10-09 14:07:01.911935'),
(1090, 13, '2024-10-13 00:00:00.000000', '340', '2024-10-09 14:07:01.911995'),
(1091, 13, '2024-10-14 00:00:00.000000', '340', '2024-10-09 14:07:01.912050'),
(1092, 13, '2024-10-15 00:00:00.000000', '340', '2024-10-09 14:07:01.912123'),
(1093, 13, '2024-10-16 00:00:00.000000', '340', '2024-10-09 14:07:01.912186'),
(1094, 13, '2024-10-17 00:00:00.000000', '340', '2024-10-09 14:07:01.912241'),
(1095, 13, '2024-10-18 00:00:00.000000', '340', '2024-10-09 14:07:01.912295'),
(1096, 13, '2024-10-19 00:00:00.000000', '340', '2024-10-09 14:07:01.912350'),
(1097, 13, '2024-10-20 00:00:00.000000', '340', '2024-10-09 14:07:01.912402'),
(1098, 13, '2024-10-21 00:00:00.000000', '340', '2024-10-09 14:07:01.912457'),
(1099, 13, '2024-10-22 00:00:00.000000', '340', '2024-10-09 14:07:01.912507'),
(1100, 13, '2024-10-23 00:00:00.000000', '340', '2024-10-09 14:07:01.912570'),
(1101, 13, '2024-10-24 00:00:00.000000', '340', '2024-10-09 14:07:01.912625'),
(1102, 13, '2024-10-25 00:00:00.000000', '340', '2024-10-09 14:07:01.912680'),
(1103, 13, '2024-10-26 00:00:00.000000', '340', '2024-10-09 14:07:01.912733'),
(1104, 13, '2024-10-27 00:00:00.000000', '340', '2024-10-09 14:07:01.912789'),
(1105, 13, '2024-10-28 00:00:00.000000', '340', '2024-10-09 14:07:01.912842'),
(1106, 13, '2024-10-29 00:00:00.000000', '340', '2024-10-09 14:07:01.912897'),
(1107, 13, '2024-10-30 00:00:00.000000', '340', '2024-10-09 14:07:01.912949'),
(1108, 13, '2024-10-31 00:00:00.000000', '340', '2024-10-09 14:07:01.913001'),
(1109, 13, '2024-11-01 00:00:00.000000', '340', '2024-10-09 14:07:01.913054'),
(1110, 13, '2024-11-02 00:00:00.000000', '340', '2024-10-09 14:07:01.913112'),
(1111, 13, '2024-11-03 00:00:00.000000', '340', '2024-10-09 14:07:01.913169'),
(1112, 13, '2024-11-04 00:00:00.000000', '340', '2024-10-09 14:07:01.913222'),
(1113, 13, '2024-11-05 00:00:00.000000', '340', '2024-10-09 14:07:01.913276'),
(1114, 13, '2024-11-06 00:00:00.000000', '340', '2024-10-09 14:07:01.913330'),
(1115, 13, '2024-11-07 00:00:00.000000', '340', '2024-10-09 14:07:01.913384'),
(1116, 13, '2024-11-08 00:00:00.000000', '340', '2024-10-09 14:07:01.913438'),
(1117, 10, '2024-10-10 00:00:00.000000', '452', '2024-10-09 14:07:01.913488'),
(1118, 10, '2024-10-11 00:00:00.000000', '452', '2024-10-09 14:07:01.913540'),
(1119, 10, '2024-10-12 00:00:00.000000', '452', '2024-10-09 14:07:01.913592'),
(1120, 10, '2024-10-13 00:00:00.000000', '452', '2024-10-09 14:07:01.913641'),
(1121, 10, '2024-10-14 00:00:00.000000', '452', '2024-10-09 14:07:01.913692'),
(1122, 10, '2024-10-15 00:00:00.000000', '452', '2024-10-09 14:07:01.913743'),
(1123, 10, '2024-10-16 00:00:00.000000', '452', '2024-10-09 14:07:01.913795'),
(1124, 10, '2024-10-17 00:00:00.000000', '452', '2024-10-09 14:07:01.913858'),
(1125, 10, '2024-10-18 00:00:00.000000', '452', '2024-10-09 14:07:01.913912'),
(1126, 10, '2024-10-19 00:00:00.000000', '452', '2024-10-09 14:07:01.913968'),
(1127, 10, '2024-10-20 00:00:00.000000', '452', '2024-10-09 14:07:01.914021'),
(1128, 10, '2024-10-21 00:00:00.000000', '452', '2024-10-09 14:07:01.914073'),
(1129, 10, '2024-10-22 00:00:00.000000', '452', '2024-10-09 14:07:01.914149'),
(1130, 10, '2024-10-23 00:00:00.000000', '452', '2024-10-09 14:07:01.914205'),
(1131, 10, '2024-10-24 00:00:00.000000', '452', '2024-10-09 14:07:01.914259'),
(1132, 10, '2024-10-25 00:00:00.000000', '452', '2024-10-09 14:07:01.914525'),
(1133, 10, '2024-10-26 00:00:00.000000', '452', '2024-10-09 14:07:01.914580'),
(1134, 10, '2024-10-27 00:00:00.000000', '452', '2024-10-09 14:07:01.914633'),
(1135, 10, '2024-10-28 00:00:00.000000', '452', '2024-10-09 14:07:01.914684'),
(1136, 10, '2024-10-29 00:00:00.000000', '452', '2024-10-09 14:07:01.914736'),
(1137, 10, '2024-10-30 00:00:00.000000', '452', '2024-10-09 14:07:01.914787'),
(1138, 10, '2024-10-31 00:00:00.000000', '452', '2024-10-09 14:07:01.914844'),
(1139, 10, '2024-11-01 00:00:00.000000', '452', '2024-10-09 14:07:01.914896'),
(1140, 10, '2024-11-02 00:00:00.000000', '452', '2024-10-09 14:07:01.914951'),
(1141, 10, '2024-11-03 00:00:00.000000', '452', '2024-10-09 14:07:01.915002'),
(1142, 10, '2024-11-04 00:00:00.000000', '452', '2024-10-09 14:07:01.915053'),
(1143, 10, '2024-11-05 00:00:00.000000', '452', '2024-10-09 14:07:01.915115'),
(1144, 10, '2024-11-06 00:00:00.000000', '452', '2024-10-09 14:07:01.915171'),
(1145, 10, '2024-11-07 00:00:00.000000', '452', '2024-10-09 14:07:01.915224'),
(1146, 10, '2024-11-08 00:00:00.000000', '452', '2024-10-09 14:07:01.915278'),
(1147, 15, '2024-10-10 00:00:00.000000', '448', '2024-10-09 14:07:01.915332'),
(1148, 15, '2024-10-11 00:00:00.000000', '448', '2024-10-09 14:07:01.915386'),
(1149, 15, '2024-10-12 00:00:00.000000', '448', '2024-10-09 14:07:01.915443'),
(1150, 15, '2024-10-13 00:00:00.000000', '448', '2024-10-09 14:07:01.915499'),
(1151, 15, '2024-10-14 00:00:00.000000', '448', '2024-10-09 14:07:01.915552'),
(1152, 15, '2024-10-15 00:00:00.000000', '448', '2024-10-09 14:07:01.915605'),
(1153, 15, '2024-10-16 00:00:00.000000', '448', '2024-10-09 14:07:01.915655'),
(1154, 15, '2024-10-17 00:00:00.000000', '448', '2024-10-09 14:07:01.915710'),
(1155, 15, '2024-10-18 00:00:00.000000', '448', '2024-10-09 14:07:01.915762'),
(1156, 15, '2024-10-19 00:00:00.000000', '448', '2024-10-09 14:07:01.915817'),
(1157, 15, '2024-10-20 00:00:00.000000', '448', '2024-10-09 14:07:01.915869'),
(1158, 15, '2024-10-21 00:00:00.000000', '448', '2024-10-09 14:07:01.915921'),
(1159, 15, '2024-10-22 00:00:00.000000', '448', '2024-10-09 14:07:01.915974'),
(1160, 15, '2024-10-23 00:00:00.000000', '448', '2024-10-09 14:07:01.916024'),
(1161, 15, '2024-10-24 00:00:00.000000', '448', '2024-10-09 14:07:01.916077'),
(1162, 15, '2024-10-25 00:00:00.000000', '448', '2024-10-09 14:07:01.916138'),
(1163, 15, '2024-10-26 00:00:00.000000', '448', '2024-10-09 14:07:01.916193'),
(1164, 15, '2024-10-27 00:00:00.000000', '448', '2024-10-09 14:07:01.916247'),
(1165, 15, '2024-10-28 00:00:00.000000', '448', '2024-10-09 14:07:01.916301'),
(1166, 15, '2024-10-29 00:00:00.000000', '448', '2024-10-09 14:07:01.916352'),
(1167, 15, '2024-10-30 00:00:00.000000', '448', '2024-10-09 14:07:01.916406'),
(1168, 15, '2024-10-31 00:00:00.000000', '448', '2024-10-09 14:07:01.916460'),
(1169, 15, '2024-11-01 00:00:00.000000', '448', '2024-10-09 14:07:01.916514'),
(1170, 15, '2024-11-02 00:00:00.000000', '448', '2024-10-09 14:07:01.916580'),
(1171, 15, '2024-11-03 00:00:00.000000', '448', '2024-10-09 14:07:01.916674'),
(1172, 15, '2024-11-04 00:00:00.000000', '448', '2024-10-09 14:07:01.916731'),
(1173, 15, '2024-11-05 00:00:00.000000', '448', '2024-10-09 14:07:01.916785'),
(1174, 15, '2024-11-06 00:00:00.000000', '448', '2024-10-09 14:07:01.916941'),
(1175, 15, '2024-11-07 00:00:00.000000', '448', '2024-10-09 14:07:01.917019'),
(1176, 15, '2024-11-08 00:00:00.000000', '448', '2024-10-09 14:07:01.917075'),
(1177, 16, '2024-10-10 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.917158'),
(1178, 16, '2024-10-11 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.917222'),
(1179, 16, '2024-10-12 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.917280'),
(1180, 16, '2024-10-13 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.917333'),
(1181, 16, '2024-10-14 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.917385'),
(1182, 16, '2024-10-15 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.917437'),
(1183, 16, '2024-10-16 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.917494'),
(1184, 16, '2024-10-17 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.917547'),
(1185, 16, '2024-10-18 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.917601'),
(1186, 16, '2024-10-19 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.917653'),
(1187, 16, '2024-10-20 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.917729'),
(1188, 16, '2024-10-21 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.917784'),
(1189, 16, '2024-10-22 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.917835'),
(1190, 16, '2024-10-23 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.917890'),
(1191, 16, '2024-10-24 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.918010'),
(1192, 16, '2024-10-25 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.918101'),
(1193, 16, '2024-10-26 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.918219'),
(1194, 16, '2024-10-27 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.918298'),
(1195, 16, '2024-10-28 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.918411'),
(1196, 16, '2024-10-29 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.918488'),
(1197, 16, '2024-10-30 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.918594'),
(1198, 16, '2024-10-31 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.919872'),
(1199, 16, '2024-11-01 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.919950'),
(1200, 16, '2024-11-02 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.920017'),
(1201, 16, '2024-11-03 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.920074'),
(1202, 16, '2024-11-04 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.920139'),
(1203, 16, '2024-11-05 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.920196'),
(1204, 16, '2024-11-06 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.920250'),
(1205, 16, '2024-11-07 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.920304'),
(1206, 16, '2024-11-08 00:00:00.000000', '333.33333333333', '2024-10-09 14:07:01.920375'),
(1207, 11, '2024-10-10 00:00:00.000000', '120', '2024-10-09 14:07:01.920429'),
(1208, 11, '2024-10-11 00:00:00.000000', '120', '2024-10-09 14:07:01.920480'),
(1209, 11, '2024-10-12 00:00:00.000000', '120', '2024-10-09 14:07:01.920532'),
(1210, 11, '2024-10-13 00:00:00.000000', '120', '2024-10-09 14:07:01.920585'),
(1211, 11, '2024-10-14 00:00:00.000000', '120', '2024-10-09 14:07:01.920635'),
(1212, 11, '2024-10-15 00:00:00.000000', '120', '2024-10-09 14:07:01.920695'),
(1213, 11, '2024-10-16 00:00:00.000000', '120', '2024-10-09 14:07:01.920747'),
(1214, 11, '2024-10-17 00:00:00.000000', '120', '2024-10-09 14:07:01.920799'),
(1215, 11, '2024-10-18 00:00:00.000000', '120', '2024-10-09 14:07:01.920849'),
(1216, 11, '2024-10-19 00:00:00.000000', '120', '2024-10-09 14:07:01.920900'),
(1217, 11, '2024-10-20 00:00:00.000000', '120', '2024-10-09 14:07:01.920952'),
(1218, 11, '2024-10-21 00:00:00.000000', '120', '2024-10-09 14:07:01.921003'),
(1219, 11, '2024-10-22 00:00:00.000000', '120', '2024-10-09 14:07:01.921058'),
(1220, 11, '2024-10-23 00:00:00.000000', '120', '2024-10-09 14:07:01.921116'),
(1221, 11, '2024-10-24 00:00:00.000000', '120', '2024-10-09 14:07:01.921171'),
(1222, 11, '2024-10-25 00:00:00.000000', '120', '2024-10-09 14:07:01.921224'),
(1223, 11, '2024-10-26 00:00:00.000000', '120', '2024-10-09 14:07:01.921275'),
(1224, 11, '2024-10-27 00:00:00.000000', '120', '2024-10-09 14:07:01.921328'),
(1225, 11, '2024-10-28 00:00:00.000000', '120', '2024-10-09 14:07:01.921380'),
(1226, 11, '2024-10-29 00:00:00.000000', '120', '2024-10-09 14:07:01.921441'),
(1227, 11, '2024-10-30 00:00:00.000000', '120', '2024-10-09 14:07:01.921496'),
(1228, 11, '2024-10-31 00:00:00.000000', '120', '2024-10-09 14:07:01.921551'),
(1229, 11, '2024-11-01 00:00:00.000000', '120', '2024-10-09 14:07:01.921604'),
(1230, 11, '2024-11-02 00:00:00.000000', '120', '2024-10-09 14:07:01.921655'),
(1231, 11, '2024-11-03 00:00:00.000000', '120', '2024-10-09 14:07:01.921707'),
(1232, 11, '2024-11-04 00:00:00.000000', '120', '2024-10-09 14:07:01.921759'),
(1233, 11, '2024-11-05 00:00:00.000000', '120', '2024-10-09 14:07:01.921811'),
(1234, 11, '2024-11-06 00:00:00.000000', '120', '2024-10-09 14:07:01.921862'),
(1235, 11, '2024-11-07 00:00:00.000000', '120', '2024-10-09 14:07:01.921914'),
(1236, 11, '2024-11-08 00:00:00.000000', '120', '2024-10-09 14:07:01.921968'),
(1237, 14, '2024-10-10 00:00:00.000000', '840', '2024-10-09 14:07:01.922019'),
(1238, 14, '2024-10-11 00:00:00.000000', '840', '2024-10-09 14:07:01.922070'),
(1239, 14, '2024-10-12 00:00:00.000000', '840', '2024-10-09 14:07:01.922128'),
(1240, 14, '2024-10-13 00:00:00.000000', '840', '2024-10-09 14:07:01.922186'),
(1241, 14, '2024-10-14 00:00:00.000000', '840', '2024-10-09 14:07:01.922240'),
(1242, 14, '2024-10-15 00:00:00.000000', '840', '2024-10-09 14:07:01.922291'),
(1243, 14, '2024-10-16 00:00:00.000000', '840', '2024-10-09 14:07:01.922344'),
(1244, 14, '2024-10-17 00:00:00.000000', '840', '2024-10-09 14:07:01.922397'),
(1245, 14, '2024-10-18 00:00:00.000000', '840', '2024-10-09 14:07:01.922448'),
(1246, 14, '2024-10-19 00:00:00.000000', '840', '2024-10-09 14:07:01.922499'),
(1247, 14, '2024-10-20 00:00:00.000000', '840', '2024-10-09 14:07:01.922551'),
(1248, 14, '2024-10-21 00:00:00.000000', '840', '2024-10-09 14:07:01.922601'),
(1249, 14, '2024-10-22 00:00:00.000000', '840', '2024-10-09 14:07:01.922660'),
(1250, 14, '2024-10-23 00:00:00.000000', '840', '2024-10-09 14:07:01.922713'),
(1251, 14, '2024-10-24 00:00:00.000000', '840', '2024-10-09 14:07:01.922765'),
(1252, 14, '2024-10-25 00:00:00.000000', '840', '2024-10-09 14:07:01.922816'),
(1253, 14, '2024-10-26 00:00:00.000000', '840', '2024-10-09 14:07:01.922868'),
(1254, 14, '2024-10-27 00:00:00.000000', '840', '2024-10-09 14:07:01.922922'),
(1255, 14, '2024-10-28 00:00:00.000000', '840', '2024-10-09 14:07:01.922973'),
(1256, 14, '2024-10-29 00:00:00.000000', '840', '2024-10-09 14:07:01.923027'),
(1257, 14, '2024-10-30 00:00:00.000000', '840', '2024-10-09 14:07:01.923082'),
(1258, 14, '2024-10-31 00:00:00.000000', '840', '2024-10-09 14:07:01.923151'),
(1259, 14, '2024-11-01 00:00:00.000000', '840', '2024-10-09 14:07:01.923207'),
(1260, 14, '2024-11-02 00:00:00.000000', '840', '2024-10-09 14:07:01.923262'),
(1261, 14, '2024-11-03 00:00:00.000000', '840', '2024-10-09 14:07:01.923315'),
(1262, 14, '2024-11-04 00:00:00.000000', '840', '2024-10-09 14:07:01.923367'),
(1263, 14, '2024-11-05 00:00:00.000000', '840', '2024-10-09 14:07:01.923419'),
(1264, 14, '2024-11-06 00:00:00.000000', '840', '2024-10-09 14:07:01.923473'),
(1265, 14, '2024-11-07 00:00:00.000000', '840', '2024-10-09 14:07:01.923524'),
(1266, 14, '2024-11-08 00:00:00.000000', '840', '2024-10-09 14:07:01.923578'),
(1267, 13, '2024-10-17 00:00:00.000000', '340', '2024-10-16 14:14:27.501812'),
(1268, 13, '2024-10-18 00:00:00.000000', '340', '2024-10-16 14:14:27.501950'),
(1269, 13, '2024-10-19 00:00:00.000000', '340', '2024-10-16 14:14:27.502032'),
(1270, 13, '2024-10-20 00:00:00.000000', '340', '2024-10-16 14:14:27.502093'),
(1271, 13, '2024-10-21 00:00:00.000000', '340', '2024-10-16 14:14:27.502162'),
(1272, 13, '2024-10-22 00:00:00.000000', '340', '2024-10-16 14:14:27.502211'),
(1273, 13, '2024-10-23 00:00:00.000000', '340', '2024-10-16 14:14:27.502258'),
(1274, 13, '2024-10-24 00:00:00.000000', '340', '2024-10-16 14:14:27.502303'),
(1275, 13, '2024-10-25 00:00:00.000000', '340', '2024-10-16 14:14:27.502348'),
(1276, 13, '2024-10-26 00:00:00.000000', '340', '2024-10-16 14:14:27.502389'),
(1277, 13, '2024-10-27 00:00:00.000000', '340', '2024-10-16 14:14:27.502449'),
(1278, 13, '2024-10-28 00:00:00.000000', '340', '2024-10-16 14:14:27.502508'),
(1279, 13, '2024-10-29 00:00:00.000000', '340', '2024-10-16 14:14:27.502556'),
(1280, 13, '2024-10-30 00:00:00.000000', '340', '2024-10-16 14:14:27.502601'),
(1281, 13, '2024-10-31 00:00:00.000000', '340', '2024-10-16 14:14:27.502639'),
(1282, 13, '2024-11-01 00:00:00.000000', '340', '2024-10-16 14:14:27.502674'),
(1283, 13, '2024-11-02 00:00:00.000000', '340', '2024-10-16 14:14:27.502707'),
(1284, 13, '2024-11-03 00:00:00.000000', '340', '2024-10-16 14:14:27.502741'),
(1285, 13, '2024-11-04 00:00:00.000000', '340', '2024-10-16 14:14:27.502790'),
(1286, 13, '2024-11-05 00:00:00.000000', '340', '2024-10-16 14:14:27.502839'),
(1287, 13, '2024-11-06 00:00:00.000000', '340', '2024-10-16 14:14:27.502885'),
(1288, 13, '2024-11-07 00:00:00.000000', '340', '2024-10-16 14:14:27.502933'),
(1289, 13, '2024-11-08 00:00:00.000000', '340', '2024-10-16 14:14:27.502982'),
(1290, 13, '2024-11-09 00:00:00.000000', '340', '2024-10-16 14:14:27.503033'),
(1291, 13, '2024-11-10 00:00:00.000000', '340', '2024-10-16 14:14:27.503085'),
(1292, 13, '2024-11-11 00:00:00.000000', '340', '2024-10-16 14:14:27.503156'),
(1293, 13, '2024-11-12 00:00:00.000000', '340', '2024-10-16 14:14:27.503267'),
(1294, 13, '2024-11-13 00:00:00.000000', '340', '2024-10-16 14:14:27.503469'),
(1295, 13, '2024-11-14 00:00:00.000000', '340', '2024-10-16 14:14:27.503530'),
(1296, 13, '2024-11-15 00:00:00.000000', '340', '2024-10-16 14:14:27.503583'),
(1297, 10, '2024-10-17 00:00:00.000000', '452', '2024-10-16 14:14:27.503647'),
(1298, 10, '2024-10-18 00:00:00.000000', '452', '2024-10-16 14:14:27.503702'),
(1299, 10, '2024-10-19 00:00:00.000000', '452', '2024-10-16 14:14:27.503751'),
(1300, 10, '2024-10-20 00:00:00.000000', '452', '2024-10-16 14:14:27.503797'),
(1301, 10, '2024-10-21 00:00:00.000000', '452', '2024-10-16 14:14:27.503840'),
(1302, 10, '2024-10-22 00:00:00.000000', '452', '2024-10-16 14:14:27.503900'),
(1303, 10, '2024-10-23 00:00:00.000000', '452', '2024-10-16 14:14:27.503950'),
(1304, 10, '2024-10-24 00:00:00.000000', '452', '2024-10-16 14:14:27.503998'),
(1305, 10, '2024-10-25 00:00:00.000000', '452', '2024-10-16 14:14:27.504047'),
(1306, 10, '2024-10-26 00:00:00.000000', '452', '2024-10-16 14:14:27.504105'),
(1307, 10, '2024-10-27 00:00:00.000000', '452', '2024-10-16 14:14:27.504160'),
(1308, 10, '2024-10-28 00:00:00.000000', '452', '2024-10-16 14:14:27.504208'),
(1309, 10, '2024-10-29 00:00:00.000000', '452', '2024-10-16 14:14:27.504255'),
(1310, 10, '2024-10-30 00:00:00.000000', '452', '2024-10-16 14:14:27.504303'),
(1311, 10, '2024-10-31 00:00:00.000000', '452', '2024-10-16 14:14:27.504352'),
(1312, 10, '2024-11-01 00:00:00.000000', '452', '2024-10-16 14:14:27.504400'),
(1313, 10, '2024-11-02 00:00:00.000000', '452', '2024-10-16 14:14:27.504448'),
(1314, 10, '2024-11-03 00:00:00.000000', '452', '2024-10-16 14:14:27.504501'),
(1315, 10, '2024-11-04 00:00:00.000000', '452', '2024-10-16 14:14:27.504547'),
(1316, 10, '2024-11-05 00:00:00.000000', '452', '2024-10-16 14:14:27.504595'),
(1317, 10, '2024-11-06 00:00:00.000000', '452', '2024-10-16 14:14:27.504652'),
(1318, 10, '2024-11-07 00:00:00.000000', '452', '2024-10-16 14:14:27.504700'),
(1319, 10, '2024-11-08 00:00:00.000000', '452', '2024-10-16 14:14:27.504746'),
(1320, 10, '2024-11-09 00:00:00.000000', '452', '2024-10-16 14:14:27.504790'),
(1321, 10, '2024-11-10 00:00:00.000000', '452', '2024-10-16 14:14:27.504833'),
(1322, 10, '2024-11-11 00:00:00.000000', '452', '2024-10-16 14:14:27.504876'),
(1323, 10, '2024-11-12 00:00:00.000000', '452', '2024-10-16 14:14:27.504922'),
(1324, 10, '2024-11-13 00:00:00.000000', '452', '2024-10-16 14:14:27.504968'),
(1325, 10, '2024-11-14 00:00:00.000000', '452', '2024-10-16 14:14:27.505015'),
(1326, 10, '2024-11-15 00:00:00.000000', '452', '2024-10-16 14:14:27.505060'),
(1327, 15, '2024-10-17 00:00:00.000000', '448', '2024-10-16 14:14:27.505106'),
(1328, 15, '2024-10-18 00:00:00.000000', '448', '2024-10-16 14:14:27.505154'),
(1329, 15, '2024-10-19 00:00:00.000000', '448', '2024-10-16 14:14:27.505209'),
(1330, 15, '2024-10-20 00:00:00.000000', '448', '2024-10-16 14:14:27.505345'),
(1331, 15, '2024-10-21 00:00:00.000000', '448', '2024-10-16 14:14:27.505397'),
(1332, 15, '2024-10-22 00:00:00.000000', '448', '2024-10-16 14:14:27.505582'),
(1333, 15, '2024-10-23 00:00:00.000000', '448', '2024-10-16 14:14:27.505637'),
(1334, 15, '2024-10-24 00:00:00.000000', '448', '2024-10-16 14:14:27.505685'),
(1335, 15, '2024-10-25 00:00:00.000000', '448', '2024-10-16 14:14:27.505732'),
(1336, 15, '2024-10-26 00:00:00.000000', '448', '2024-10-16 14:14:27.505779'),
(1337, 15, '2024-10-27 00:00:00.000000', '448', '2024-10-16 14:14:27.505828'),
(1338, 15, '2024-10-28 00:00:00.000000', '448', '2024-10-16 14:14:27.505876'),
(1339, 15, '2024-10-29 00:00:00.000000', '448', '2024-10-16 14:14:27.505925'),
(1340, 15, '2024-10-30 00:00:00.000000', '448', '2024-10-16 14:14:27.505974'),
(1341, 15, '2024-10-31 00:00:00.000000', '448', '2024-10-16 14:14:27.506024'),
(1342, 15, '2024-11-01 00:00:00.000000', '448', '2024-10-16 14:14:27.506072'),
(1343, 15, '2024-11-02 00:00:00.000000', '448', '2024-10-16 14:14:27.506177'),
(1344, 15, '2024-11-03 00:00:00.000000', '448', '2024-10-16 14:14:27.506231'),
(1345, 15, '2024-11-04 00:00:00.000000', '448', '2024-10-16 14:14:27.506282'),
(1346, 15, '2024-11-05 00:00:00.000000', '448', '2024-10-16 14:14:27.506328'),
(1347, 15, '2024-11-06 00:00:00.000000', '448', '2024-10-16 14:14:27.506371'),
(1348, 15, '2024-11-07 00:00:00.000000', '448', '2024-10-16 14:14:27.506416'),
(1349, 15, '2024-11-08 00:00:00.000000', '448', '2024-10-16 14:14:27.506458'),
(1350, 15, '2024-11-09 00:00:00.000000', '448', '2024-10-16 14:14:27.506504'),
(1351, 15, '2024-11-10 00:00:00.000000', '448', '2024-10-16 14:14:27.506549'),
(1352, 15, '2024-11-11 00:00:00.000000', '448', '2024-10-16 14:14:27.506593'),
(1353, 15, '2024-11-12 00:00:00.000000', '448', '2024-10-16 14:14:27.506640'),
(1354, 15, '2024-11-13 00:00:00.000000', '448', '2024-10-16 14:14:27.506703'),
(1355, 15, '2024-11-14 00:00:00.000000', '448', '2024-10-16 14:14:27.506752'),
(1356, 15, '2024-11-15 00:00:00.000000', '448', '2024-10-16 14:14:27.506796'),
(1357, 16, '2024-10-17 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.506856'),
(1358, 16, '2024-10-18 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.506906'),
(1359, 16, '2024-10-19 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.506971'),
(1360, 16, '2024-10-20 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.507021'),
(1361, 16, '2024-10-21 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.507068'),
(1362, 16, '2024-10-22 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.507126');
INSERT INTO `product_forecast` (`id`, `prod_id`, `forecast_date`, `forecast_value`, `created_at`) VALUES
(1363, 16, '2024-10-23 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.507194'),
(1364, 16, '2024-10-24 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.507253'),
(1365, 16, '2024-10-25 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.507325'),
(1366, 16, '2024-10-26 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.507384'),
(1367, 16, '2024-10-27 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.507456'),
(1368, 16, '2024-10-28 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.507504'),
(1369, 16, '2024-10-29 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.507562'),
(1370, 16, '2024-10-30 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.507611'),
(1371, 16, '2024-10-31 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.507670'),
(1372, 16, '2024-11-01 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.507718'),
(1373, 16, '2024-11-02 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.507769'),
(1374, 16, '2024-11-03 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.507817'),
(1375, 16, '2024-11-04 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.507864'),
(1376, 16, '2024-11-05 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.507908'),
(1377, 16, '2024-11-06 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.507956'),
(1378, 16, '2024-11-07 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.508002'),
(1379, 16, '2024-11-08 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.508062'),
(1380, 16, '2024-11-09 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.508107'),
(1381, 16, '2024-11-10 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.508157'),
(1382, 16, '2024-11-11 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.508215'),
(1383, 16, '2024-11-12 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.508263'),
(1384, 16, '2024-11-13 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.508310'),
(1385, 16, '2024-11-14 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.508358'),
(1386, 16, '2024-11-15 00:00:00.000000', '333.33333333333', '2024-10-16 14:14:27.508405'),
(1387, 11, '2024-10-17 00:00:00.000000', '120', '2024-10-16 14:14:27.508452'),
(1388, 11, '2024-10-18 00:00:00.000000', '120', '2024-10-16 14:14:27.508497'),
(1389, 11, '2024-10-19 00:00:00.000000', '120', '2024-10-16 14:14:27.508541'),
(1390, 11, '2024-10-20 00:00:00.000000', '120', '2024-10-16 14:14:27.508589'),
(1391, 11, '2024-10-21 00:00:00.000000', '120', '2024-10-16 14:14:27.508635'),
(1392, 11, '2024-10-22 00:00:00.000000', '120', '2024-10-16 14:14:27.508681'),
(1393, 11, '2024-10-23 00:00:00.000000', '120', '2024-10-16 14:14:27.508725'),
(1394, 11, '2024-10-24 00:00:00.000000', '120', '2024-10-16 14:14:27.508771'),
(1395, 11, '2024-10-25 00:00:00.000000', '120', '2024-10-16 14:14:27.508813'),
(1396, 11, '2024-10-26 00:00:00.000000', '120', '2024-10-16 14:14:27.508859'),
(1397, 11, '2024-10-27 00:00:00.000000', '120', '2024-10-16 14:14:27.508904'),
(1398, 11, '2024-10-28 00:00:00.000000', '120', '2024-10-16 14:14:27.508949'),
(1399, 11, '2024-10-29 00:00:00.000000', '120', '2024-10-16 14:14:27.508995'),
(1400, 11, '2024-10-30 00:00:00.000000', '120', '2024-10-16 14:14:27.509040'),
(1401, 11, '2024-10-31 00:00:00.000000', '120', '2024-10-16 14:14:27.509085'),
(1402, 11, '2024-11-01 00:00:00.000000', '120', '2024-10-16 14:14:27.509146'),
(1403, 11, '2024-11-02 00:00:00.000000', '120', '2024-10-16 14:14:27.509198'),
(1404, 11, '2024-11-03 00:00:00.000000', '120', '2024-10-16 14:14:27.509246'),
(1405, 11, '2024-11-04 00:00:00.000000', '120', '2024-10-16 14:14:27.509290'),
(1406, 11, '2024-11-05 00:00:00.000000', '120', '2024-10-16 14:14:27.509341'),
(1407, 11, '2024-11-06 00:00:00.000000', '120', '2024-10-16 14:14:27.509390'),
(1408, 11, '2024-11-07 00:00:00.000000', '120', '2024-10-16 14:14:27.509437'),
(1409, 11, '2024-11-08 00:00:00.000000', '120', '2024-10-16 14:14:27.509483'),
(1410, 11, '2024-11-09 00:00:00.000000', '120', '2024-10-16 14:14:27.509530'),
(1411, 11, '2024-11-10 00:00:00.000000', '120', '2024-10-16 14:14:27.509577'),
(1412, 11, '2024-11-11 00:00:00.000000', '120', '2024-10-16 14:14:27.509624'),
(1413, 11, '2024-11-12 00:00:00.000000', '120', '2024-10-16 14:14:27.509670'),
(1414, 11, '2024-11-13 00:00:00.000000', '120', '2024-10-16 14:14:27.509716'),
(1415, 11, '2024-11-14 00:00:00.000000', '120', '2024-10-16 14:14:27.509764'),
(1416, 11, '2024-11-15 00:00:00.000000', '120', '2024-10-16 14:14:27.509808'),
(1417, 14, '2024-10-17 00:00:00.000000', '840', '2024-10-16 14:14:27.509856'),
(1418, 14, '2024-10-18 00:00:00.000000', '840', '2024-10-16 14:14:27.509902'),
(1419, 14, '2024-10-19 00:00:00.000000', '840', '2024-10-16 14:14:27.509949'),
(1420, 14, '2024-10-20 00:00:00.000000', '840', '2024-10-16 14:14:27.510001'),
(1421, 14, '2024-10-21 00:00:00.000000', '840', '2024-10-16 14:14:27.510048'),
(1422, 14, '2024-10-22 00:00:00.000000', '840', '2024-10-16 14:14:27.510101'),
(1423, 14, '2024-10-23 00:00:00.000000', '840', '2024-10-16 14:14:27.510154'),
(1424, 14, '2024-10-24 00:00:00.000000', '840', '2024-10-16 14:14:27.510202'),
(1425, 14, '2024-10-25 00:00:00.000000', '840', '2024-10-16 14:14:27.510251'),
(1426, 14, '2024-10-26 00:00:00.000000', '840', '2024-10-16 14:14:27.510296'),
(1427, 14, '2024-10-27 00:00:00.000000', '840', '2024-10-16 14:14:27.510343'),
(1428, 14, '2024-10-28 00:00:00.000000', '840', '2024-10-16 14:14:27.510389'),
(1429, 14, '2024-10-29 00:00:00.000000', '840', '2024-10-16 14:14:27.510433'),
(1430, 14, '2024-10-30 00:00:00.000000', '840', '2024-10-16 14:14:27.510479'),
(1431, 14, '2024-10-31 00:00:00.000000', '840', '2024-10-16 14:14:27.510521'),
(1432, 14, '2024-11-01 00:00:00.000000', '840', '2024-10-16 14:14:27.510565'),
(1433, 14, '2024-11-02 00:00:00.000000', '840', '2024-10-16 14:14:27.510607'),
(1434, 14, '2024-11-03 00:00:00.000000', '840', '2024-10-16 14:14:27.510651'),
(1435, 14, '2024-11-04 00:00:00.000000', '840', '2024-10-16 14:14:27.510698'),
(1436, 14, '2024-11-05 00:00:00.000000', '840', '2024-10-16 14:14:27.510742'),
(1437, 14, '2024-11-06 00:00:00.000000', '840', '2024-10-16 14:14:27.510786'),
(1438, 14, '2024-11-07 00:00:00.000000', '840', '2024-10-16 14:14:27.510828'),
(1439, 14, '2024-11-08 00:00:00.000000', '840', '2024-10-16 14:14:27.510874'),
(1440, 14, '2024-11-09 00:00:00.000000', '840', '2024-10-16 14:14:27.510922'),
(1441, 14, '2024-11-10 00:00:00.000000', '840', '2024-10-16 14:14:27.510964'),
(1442, 14, '2024-11-11 00:00:00.000000', '840', '2024-10-16 14:14:27.511031'),
(1443, 14, '2024-11-12 00:00:00.000000', '840', '2024-10-16 14:14:27.511077'),
(1444, 14, '2024-11-13 00:00:00.000000', '840', '2024-10-16 14:14:27.511135'),
(1445, 14, '2024-11-14 00:00:00.000000', '840', '2024-10-16 14:14:27.511183'),
(1446, 14, '2024-11-15 00:00:00.000000', '840', '2024-10-16 14:14:27.511226');

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE `ratings` (
  `id` int(20) NOT NULL,
  `prod_id` varchar(200) NOT NULL,
  `prod_rate` varchar(200) NOT NULL,
  `rated_at` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ratings`
--

INSERT INTO `ratings` (`id`, `prod_id`, `prod_rate`, `rated_at`) VALUES
(1, '10', '3', '2024-09-13 12:41:44.351788'),
(2, '10', '2', '2024-09-13 12:41:44.351788'),
(3, '10', '4', '2024-09-16 04:27:26.000000'),
(4, '15', '4', '2024-09-16 04:27:26.000000'),
(5, '10', '4', '2024-09-16 10:29:29.992782'),
(6, '16', '5', '2024-09-16 14:29:33.287500'),
(7, '10', '5', '2024-09-16 14:30:24.352338'),
(8, '16', '5', '2024-09-16 14:30:24.362563'),
(9, '10', '5', '2024-09-16 14:31:35.656821');

-- --------------------------------------------------------

--
-- Table structure for table `refunds`
--

CREATE TABLE `refunds` (
  `refund_id` int(20) NOT NULL,
  `prod_code` varchar(200) DEFAULT NULL,
  `prod_name` varchar(200) NOT NULL,
  `prod_price` varchar(200) NOT NULL,
  `reason` varchar(250) NOT NULL,
  `buyer_id` varchar(100) NOT NULL,
  `buyer_name` varchar(150) NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `refunds`
--

INSERT INTO `refunds` (`refund_id`, `prod_code`, `prod_name`, `prod_price`, `reason`, `buyer_id`, `buyer_name`, `created_at`) VALUES
(1, '123', 'Pants for Men - XL', '280', 'Product Defective', '123', 'Jason Cruz', '2024-10-01 12:16:01.000000'),
(2, '124', 'Varsity Jacket - High School', '450', 'Invalid Size', '246', 'Allyzandra Smith', '2024-10-01 12:16:01.000000'),
(3, '1111', 'RIBBONS', '120', 'DEFECTIVE ITEM', '23', 'CLARK', '2024-10-01 14:22:01.817840'),
(4, '3424234', 'Ballpoint', '090239', 'Not working properly', '123 123 13', 'Juan Dela Cruz', '2024-10-01 18:38:06.666416');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(11) NOT NULL,
  `order_id` int(50) NOT NULL,
  `user_id` int(50) NOT NULL,
  `user_name` varchar(250) NOT NULL,
  `prod_id` int(50) NOT NULL,
  `prod_qty` int(50) NOT NULL,
  `prod_name` varchar(250) NOT NULL,
  `prod_price` int(50) NOT NULL,
  `prod_image` varchar(250) NOT NULL,
  `total_price` int(50) NOT NULL,
  `ordered_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `overall_total` int(50) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `order_id`, `user_id`, `user_name`, `prod_id`, `prod_qty`, `prod_name`, `prod_price`, `prod_image`, `total_price`, `ordered_at`, `overall_total`, `status`) VALUES
(24, 64672384, 6, 'Allyzandra Smith', 13, 1, 'School Skirt for Women Version 1 ', 220, '1718713149.jpg', 120, '2024-06-20 13:54:56.000000', 220, 'paid'),
(35, 9159696, 6, 'Allyzandra Smith', 10, 4, 'Id lace for all genders', 120, '1717284906.png', 480, '2024-09-05 04:27:51.000000', 480, 'paid'),
(38, 5618666, 6, 'Allyzandra Smith', 10, 1, 'Id lace for all genders', 120, '1717284906.png', 120, '2024-09-05 04:29:15.000000', 520, 'cancelled'),
(43, 664534, 0, 'n/a', 10, 1, 'Id lace for all genders', 120, '1717284906.png', 1, '2024-09-05 20:17:04.630945', 120, 'completed'),
(44, 439582, 0, 'n/a', 10, 1, 'Id lace for all genders', 120, '1717284906.png', 3, '2024-09-05 20:23:31.841060', 320, 'completed'),
(45, 439582, 0, 'n/a', 15, 1, 'Medal Of Honor - Bronze', 200, '1724561367.jpg', 2, '2024-09-05 20:23:31.842925', 320, 'completed'),
(46, 387918, 0, 'n/a', 15, 1, 'Medal Of Honor - Bronze', 200, '1724561367.jpg', 2, '2024-09-05 20:24:39.349915', 200, 'completed'),
(47, 896601, 0, 'n/a', 10, 1, 'Id lace for all genders', 120, '1717284906.png', 1, '2024-09-05 20:33:14.874612', 120, 'completed'),
(48, 306942, 0, 'n/a', 15, 1, 'Medal Of Honor - Bronze', 200, '1724561367.jpg', 2, '2024-09-05 20:33:58.185747', 200, 'completed'),
(49, 749853, 0, 'n/a', 10, 3, 'Id lace for all genders', 120, '1717284906.png', 3, '2024-09-06 10:56:21.147811', 360, 'completed'),
(50, 478255, 0, 'n/a', 10, 1, 'Id lace for all genders', 120, '1717284906.png', 1, '2024-09-10 11:07:09.563023', 120, 'completed'),
(51, 900257, 0, 'n/a', 10, 1, 'Id lace for all genders', 120, '1717284906.png', 1, '2024-09-10 11:07:29.278957', 120, 'completed'),
(52, 839069, 0, 'n/a', 10, 1, 'Id lace for all genders', 120, '1717284906.png', 1, '2024-09-10 11:10:06.563058', 120, 'completed'),
(53, 48736, 3, 'Pedro Cruz', 10, 1, 'Id lace for all genders', 120, '1717284906.png', 120, '2024-09-16 12:45:15.524069', 1720, 'completed'),
(54, 48736, 3, 'Pedro Cruz', 15, 8, 'Medal Of Honor - Bronze', 200, '1724561367.jpg', 1600, '2024-09-16 12:45:15.533924', 1720, 'completed'),
(55, 5361276, 3, 'Pedro Cruz', 10, 1, 'Id lace for all genders', 120, '1717284906.png', 120, '2024-09-16 13:01:26.132536', 120, 'completed'),
(56, 68324739, 3, 'Pedro Cruz', 10, 2, 'Id lace for all genders', 120, '1717284906.png', 120, '2024-09-16 13:12:48.195179', 460, 'completed'),
(57, 68324739, 3, 'Pedro Cruz', 13, 1, 'School Skirt for Women Version 1 ', 220, '1718713149.jpg', 240, '2024-09-16 13:12:48.205373', 460, 'completed'),
(58, 1817096, 3, 'Pedro Cruz', 16, 1, 'Black and White 6x4 - Sticker', 200, '1726197430.png', 200, '2024-09-16 13:14:51.480993', 400, 'completed'),
(59, 1817096, 3, 'Pedro Cruz', 15, 1, 'Medal Of Honor - Bronze', 200, '1724561367.jpg', 200, '2024-09-16 13:14:51.482431', 400, 'completed'),
(60, 2147483647, 3, 'Pedro Cruz', 11, 1, 'WHITE POLO SHIRT FOR MEN', 120, '1717295270.png', 120, '2024-09-16 13:19:12.475158', 120, 'completed'),
(61, 2147483647, 3, 'Pedro Cruz', 14, 1, 'White Long Sleeves Uniform', 180, '1718713520.jpg', 180, '2024-09-16 13:19:12.481484', 840, 'completed'),
(62, 2147483647, 3, 'Pedro Cruz', 15, 1, 'Medal Of Honor - Bronze', 200, '1724561367.jpg', 200, '2024-09-16 13:19:12.482066', 200, 'completed'),
(63, 2147483647, 3, 'Pedro Cruz', 10, 1, 'Id lace for all genders', 120, '1717284906.png', 120, '2024-09-16 13:19:12.482643', 520, 'completed'),
(64, 2147483647, 3, 'Pedro Cruz', 15, 2, 'Medal Of Honor - Bronze', 200, '1724561367.jpg', 400, '2024-09-16 13:19:12.483095', 520, 'completed'),
(65, 2147483647, 3, 'Pedro Cruz', 10, 6, 'Id lace for all genders', 120, '1717284906.png', 720, '2024-09-16 13:19:12.483526', 920, 'completed'),
(66, 2147483647, 3, 'Pedro Cruz', 15, 1, 'Medal Of Honor - Bronze', 200, '1724561367.jpg', 200, '2024-09-16 13:19:12.484259', 920, 'completed'),
(67, 1574756, 3, 'Pedro Cruz', 10, 2, 'Id lace for all genders', 120, '1717284906.png', 240, '2024-09-16 13:22:23.552575', 240, 'completed'),
(68, 4652546, 3, 'Pedro Cruz', 16, 1, 'Black and White 6x4 - Sticker', 200, '1726197430.png', 200, '2024-09-16 13:22:56.865935', 400, 'completed'),
(69, 4652546, 3, 'Pedro Cruz', 15, 1, 'Medal Of Honor - Bronze', 200, '1724561367.jpg', 200, '2024-09-16 13:22:56.867339', 400, 'completed'),
(70, 829493, 3, 'Pedro Cruz', 10, 1, 'Id lace for all genders', 120, '1717284906.png', 1, '2024-09-16 13:56:21.297580', 120, 'completed'),
(72, 2877006, 3, 'Pedro Cruz', 16, 1, 'Black and White 6x4 - Sticker', 200, '1726197430.png', 200, '2024-09-16 14:03:13.697417', 200, 'completed'),
(73, 3565486, 3, 'Pedro Cruz', 15, 1, 'Medal Of Honor - Bronze', 200, '1724561367.jpg', 200, '2024-09-17 14:03:45.358323', 200, 'completed');

-- --------------------------------------------------------

--
-- Table structure for table `store_status`
--

CREATE TABLE `store_status` (
  `id` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT 'VALUE SHOULD BE 1 OR 0 ONLY',
  `updated_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_by` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `store_status`
--

INSERT INTO `store_status` (`id`, `status`, `updated_at`, `updated_by`) VALUES
(1, 1, '0000-00-00 00:00:00.000000', 'Juan Dela Cruz');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `transaction_id` int(11) NOT NULL,
  `transaction_type` varchar(120) NOT NULL,
  `staff_id` varchar(120) NOT NULL,
  `staff_name` varchar(120) NOT NULL,
  `order_id` varchar(120) NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`transaction_id`, `transaction_type`, `staff_id`, `staff_name`, `order_id`, `created_at`) VALUES
(1, 'over the counter orders', '3', 'Pedro Cruz', '306942', '2024-09-05 20:33:59.655143'),
(2, 'over the counter orders', '3', 'Pedro Cruz', '233797', '2024-09-05 21:04:38.409010'),
(3, 'over the counter orders', '3', 'Pedro Cruz', '933113', '2024-09-06 10:56:08.920349'),
(4, 'over the counter orders', '3', 'Pedro Cruz', '749853', '2024-09-06 10:56:21.167066'),
(5, 'over the counter orders', '3', 'Pedro Cruz', '727074', '2024-09-06 11:00:01.738166'),
(6, 'over the counter orders', '3', 'Pedro Cruz', '478255', '2024-09-10 11:07:09.594869'),
(7, 'over the counter orders', '3', 'Pedro Cruz', '900257', '2024-09-10 11:07:29.297148'),
(8, 'over the counter orders', '3', 'Pedro Cruz', '839069', '2024-09-10 11:10:06.589217'),
(9, 'over the counter orders', '3', 'Pedro Cruz', '829493', '2024-09-16 13:56:21.502803');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `firstName` varchar(200) NOT NULL,
  `lastName` varchar(200) NOT NULL,
  `role` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'approved',
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_id`, `firstName`, `lastName`, `role`, `password`, `status`, `created_at`) VALUES
(1, '123', 'Juan ', 'Dela Cruz', 'admin', '$2y$10$ku5TfsLBF8fHlkyfBA2HQOon3V9aWQk.GNRATmqPYeTPQbj.5mEiS', 'approved', '2024-06-01 11:19:49.348243'),
(3, '369', 'Pedro', 'Cruz', 'staff', '$2y$10$cuTXtOlRGFY7OWMlBbHugOLG/yS8FcfW5SnoBBsGN5MLxMoPyUlE.', 'approved', '2024-06-01 11:19:49.348243'),
(6, '246', 'Allyzandra', 'Smith', 'user', '$2y$10$ku5TfsLBF8fHlkyfBA2HQOon3V9aWQk.GNRATmqPYeTPQbj.5mEiS', 'approved', '2024-06-02 08:28:45.437307'),
(7, '20-08664', 'Sandro', 'Cruz', 'staff', '$2y$10$ku5TfsLBF8fHlkyfBA2HQOon3V9aWQk.GNRATmqPYeTPQbj.5mEiS', 'approved', '2024-06-02 10:31:57.233056'),
(12, '12-2345-679', 'Alberto', 'Santiago', 'user', '$2y$10$V13YsDCkargL87IAhNvBDef7WbnNjhRcHgXX33q/elH8gOOaBJE7y', 'pending', '2024-10-02 12:11:32.753388'),
(13, '00-0000-000', 'Carlos', 'Abdon', 'user', '$2y$10$riByOXCe0bNCmT/LsWO5Be/xGcEsZm4jJVw8hQSlGqk5ZD.PR.31W', 'pending', '2024-10-02 12:16:59.785685'),
(14, '12-3456-789', 'Jake', 'Dimaano', 'user', '$2y$10$PMl1HRqjsRUk2CWUjlb4HOtLtwjFz4UW4d23dHFng.nIGZQSsQ.aC', 'pending', '2024-10-02 12:18:41.822640'),
(15, '23-4567-890', 'Mark ', 'Mazo', 'user', '$2y$10$NhTWWp9mc8MqMraaclLDzePd//eXtdjlXT6fXpn8Zsah6Xr4dVyVW', 'pending', '2024-10-02 12:39:02.155207'),
(16, '34-2311-235', 'John', 'Amores', 'user', '$2y$10$9C61j7fWdspSBTDHpt/.R.4lkse/HEA5z.S4r0XT/VwiMOEm7I8pC', 'pending', '2024-10-02 12:40:30.769744'),
(17, '89-1263-137', 'Gregorio', 'Concepcion', 'user', '$2y$10$gNltK1GvCHlODLL8V4Jv..mdoYjysvbbkhCHiXIyZJvBG9I9F9xNi', 'pending', '2024-10-02 12:43:55.058696'),
(18, '18-5391-378', 'Fernando', 'Poe Jr.', 'user', '$2y$10$MU6dvVhgSuU25b6PD4ls5OVHyiI/VUdRxn3fFrQTw32BnEYImyA3i', 'declined', '2024-10-02 12:56:54.683307'),
(19, '12-3845-184', 'Kian', 'Muyco', 'user', '$2y$10$twWGFqpzwFgjuV6T9SCVAuUFrThGzL/eBb3WOpDfT9g4pE5Lcy.LW', 'approved', '2024-10-09 16:21:06.611982');

-- --------------------------------------------------------

--
-- Table structure for table `void`
--

CREATE TABLE `void` (
  `id` int(11) NOT NULL,
  `user_name` varchar(150) NOT NULL,
  `password` varchar(150) NOT NULL,
  `updated_at` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `void`
--

INSERT INTO `void` (`id`, `user_name`, `password`, `updated_at`) VALUES
(1, 'admin', 'password', '2024-09-13 13:54:51.000000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `email`
--
ALTER TABLE `email`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`prod_id`);

--
-- Indexes for table `product_forecast`
--
ALTER TABLE `product_forecast`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `refunds`
--
ALTER TABLE `refunds`
  ADD PRIMARY KEY (`refund_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `store_status`
--
ALTER TABLE `store_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `void`
--
ALTER TABLE `void`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT for table `email`
--
ALTER TABLE `email`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=214;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `prod_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `product_forecast`
--
ALTER TABLE `product_forecast`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1447;

--
-- AUTO_INCREMENT for table `ratings`
--
ALTER TABLE `ratings`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `refunds`
--
ALTER TABLE `refunds`
  MODIFY `refund_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT for table `store_status`
--
ALTER TABLE `store_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `void`
--
ALTER TABLE `void`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
