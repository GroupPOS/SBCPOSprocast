<?php
require '../database/db_conn.php';


// Function to update the product
function updateProduct($conn, $data) {
    // Extract data and validate
    $prod_name = trim($data['prod_name']);
    $prod_price = filter_var($data['prod_price'], FILTER_VALIDATE_FLOAT);
    $prod_image = trim($data['prod_image']);
    $prod_qty = filter_var($data['prod_qty'], FILTER_VALIDATE_INT);
    $id = filter_var($data['id'], FILTER_VALIDATE_INT); 

    if (!$prod_price || !$prod_qty || !$id) {
        return ['success' => false, 'message' => 'Invalid product data'];
    }

    // Prepare the SQL statement for updating
    $sql = "UPDATE products SET prod_name = :prod_name, prod_price = :prod_price, prod_image = :prod_image, prod_qty = :prod_qty WHERE prod_id = :id";

    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':prod_name', $prod_name);
    $stmt->bindParam(':prod_price', $prod_price);
    $stmt->bindParam(':prod_image', $prod_image);
    $stmt->bindParam(':prod_qty', $prod_qty);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);

    if ($stmt->execute()) {
        return ['success' => true, 'message' => 'Product updated successfully'];
    } else {
        return ['success' => false, 'message' => 'Failed to update product'];
    }
}

// Example usage
$received_data = json_decode(file_get_contents("php://input"), true); // Parse JSON request as associative array

if (!empty($received_data['prod_name']) && !empty($received_data['prod_price']) && !empty($received_data['prod_image']) && !empty($received_data['prod_qty']) && !empty($received_data['id'])) {
    $result = updateProduct($conn, $received_data);

    // Log the product update action
    try {
        session_start();
        $admin_id = $_SESSION['admin_id'];
        $admin_name = $_SESSION['admin_name'];
        $log_type = 'update_product';
        $log_info = "Admin \"$admin_name\" updated product ID: ";

        $logStmt = $conn->prepare("
            INSERT INTO logs (user_type, user_name, user_id, log_type, log_info) 
            VALUES ('admin', :admin_name, :admin_id, :log_type, :log_info)
        ");
        $logStmt->bindParam(':admin_name', $admin_name);
        $logStmt->bindParam(':admin_id', $admin_id);
        $logStmt->bindParam(':log_type', $log_type);
        $logStmt->bindParam(':log_info', $log_info);

        if (!$logStmt->execute()) {
            throw new PDOException("Failed to insert log entry");
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => "Logging error: " . $e->getMessage()]);
    }

    echo json_encode($result);
} else {
    echo json_encode(['error' => 'Required fields are missing in the request']);
}

// Close the connection
$conn = null;