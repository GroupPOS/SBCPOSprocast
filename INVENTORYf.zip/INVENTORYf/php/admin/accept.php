<?php
session_start();

require '../database/db_conn.php';

$received_data = json_decode(file_get_contents("php://input"), true);

// Get user_id from URL
if (isset($received_data['user_id'])) {
    $userId = $received_data['user_id'];

    // Update user status to "approved"
    $sql = "UPDATE users SET status = 'approved' WHERE user_id = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt->execute([$userId])) {
        echo "User approved successfully. Please close this page.";

        // Log the approval action
        $adminName = $_SESSION['admin_name'] ?? 'Anonymous'; // Assuming the admin's name is stored in session
        insertLoginLog($conn, "admin", $adminName, $userId, "Account Approval", "User ID {$userId} was approved.");
    } else {
        echo "Error: " . $stmt->errorInfo()[2];
    }
} else {
    echo "User ID not provided.";
}

// Function to insert logs
function insertLoginLog($conn, $user_type, $user_name, $user_id, $log_type, $log_info) {
    try {
        $logStmt = $conn->prepare("INSERT INTO logs (user_type, user_name, user_id, log_type, log_info) VALUES (?, ?, ?, ?, ?)");
        $logStmt->execute([$user_type, $user_name, $user_id, $log_type, $log_info]);
    } catch (PDOException $e) {
        error_log('Error logging action: ' . $e->getMessage());
    }
}