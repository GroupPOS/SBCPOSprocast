<?php

//CONNECTION FOR ONLINE HOSTING
try {
    $conn = new PDO("mysql:host=localhost;dbname=u723757521_sbc_inventory", "u723757521_sbc_inventory", "aPeMGh=3");
    // Set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo json_encode(['success' => false, 'message' => "Connection failed: ". $e->getMessage()]);
    exit;
}

//CONNECTION FOR LOCALHOST

//  try {
//     $conn = new PDO("mysql:host=localhost;dbname=sbc_inventory", "root", "");
//     // Set the PDO error mode to exception
//     $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
// } catch(PDOException $e) {
//     echo json_encode(['success' => false, 'message' => "Connection failed: ". $e->getMessage()]);
//     exit;
// }
