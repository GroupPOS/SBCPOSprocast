<?php

session_start();
$received_data = json_decode(file_get_contents("php://input"), true);
$orders = $received_data['orders'];

$order_id = (string)$orders[0]['order_id'];
$line_items = [];

// Populate line_items dynamically from received data
foreach ($orders as $order) {
    $line_items[] = [
        'currency' => 'PHP', // Ensure the currency is correctly set for all items
        'images' => ['http://localhost/INVENTORYs/assets/images/'.$order['prod_image']], // Assuming there is an image_url field in each order
        'amount' => $order['prod_price'] * 100, // Amount should be in cents, so multiply by 100
        'description' => 'desc', // Use appropriate fields from the order
        'name' => $order['prod_name'], // Product name
        'quantity' => (int)$order['prod_qty'] // Product quantity
    ];
}

$curl = curl_init();

curl_setopt_array($curl, [
    CURLOPT_URL => "https://api.paymongo.com/v1/checkout_sessions",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => json_encode([
        'data' => [
            'attributes' => [
                'send_email_receipt' => true,
                'show_description' => true,
                'show_line_items' => true,
                'cancel_url' => 'http://localhost/INVENTORYs/user/userTransaction',
                'line_items' => $line_items, // Populated line items
                'payment_method_types' => [
                    'gcash',
                    'paymaya'
                ],
                'reference_number' => $order_id, 
                'success_url' => 'http://localhost/INVENTORYs/user/success',
                'description' => 'Order Payment'
            ]
        ]
    ]),
    CURLOPT_HTTPHEADER => [
        "Content-Type: application/json",
        "accept: application/json",
        "authorization: Basic c2tfdGVzdF9HTndweHhFeTN5WmdDakF1bUhaSndIc3U6" // Make sure this is the correct API key
    ],
]);

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
    echo "cURL Error #:" . $err;
} else {
    echo $response;
}
