<?php 
session_start();

// Check if the session variable 'user_id' is set
if (!isset($_SESSION['staff_id'])) {
    // If not set, redirect to the home page or any other page
    header("Location: ../");
    exit();
}
?>
<!DOCTYPE html>
<html class="h-100" lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="../assets/sbc_icon.gif">
  <title>Inventory | Staff Reports </title>

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
  <!-- Bootstrap 5 -->

  <!-- CSS -->
  <link href="../css/sidebar.css" rel="stylesheet">

</head>
<body class="h-100"> 

<div class="container-fluid h-100"  id="app">
  <div class="row h-100">

    <!-- SIDEBAR -->
    <div class="col-md-2 col-sm-1 col-12 d-flex flex-column flex-shrink-0 h-100 p-3 text-white position-fixed" style="background:#1167b1;"id="sidebar">
      <div class="d-flex justify-content-between align-items-center">
        <a href="." class="d-flex align-items-center text-white text-decoration-none">
          <ion-icon size="large" class="bi me-3 ms-2" width="40" height="32" name="happy-outline"></ion-icon>
          <span class="d-none d-md-inline fs-4">Staff Profile</span>
        </a>
      </div>
      <hr>
      <ul class="nav nav-pills flex-column mb-auto">
      <li class="nav-item mb-2">
          <a href="./staffPos" class="nav-link text-white" aria-current="page" data-bs-toggle="tooltip" data-bs-placement="right" title="Home">
          <ion-icon class="bi me-2" name="card"></ion-icon>
            <span class="d-none d-md-inline">POS</span>
          </a>
        </li>
        <li class="nav-item mb-2">
            <a href="./staffOnline" class="nav-link text-white" aria-current="page" data-bs-toggle="tooltip"
              data-bs-placement="right" title="E-payment">
              <ion-icon class="bi me-2" name="card"></ion-icon>
              <span class="d-none d-md-inline">E-payments</span>
            </a>
          </li>
          <li class="nav-item mb-2">
            <a href="./staffPayment" class="nav-link text-white" aria-current="page" data-bs-toggle="tooltip"
              data-bs-placement="right" title="Refunds">
              <ion-icon class="bi me-2" name="arrow-undo-circle-outline"></ion-icon>
              <span class="d-none d-md-inline">Refunds</span>
            </a>
          </li>
        <li class="mb-2">
          <a href="./staffTransaction.php" class="nav-link text-white" data-bs-toggle="tooltip" data-bs-placement="right" title="Cart">
            <ion-icon class="bi me-2" name="cart"><use xlink:href="#cart"></use></ion-icon>
            <span class="d-none d-md-inline">Transaction</span>
          </a>
        </li>
        <li class="mb-2">
          <a href="./staffReports.php" class="nav-link active" data-bs-toggle="tooltip" data-bs-placement="right" title="Reports">
            <ion-icon class="bi me-2" name="document"><use xlink:href="#reports"></use></ion-icon>
            <span class="d-none d-md-inline">Reports</span>
          </a>
        </li>
        <li class="mb-2">
          <a href="./staffSettings.php" class="nav-link text-white" data-bs-toggle="tooltip" data-bs-placement="right" title="Settings">
            <ion-icon class="bi me-2" name="settings"><use xlink:href="#settings"></use></ion-icon>
            <span class="d-none d-md-inline">Settings</span>
          </a>
        </li>
      </ul>
      <div class="mt-auto"> 
        <hr>
        <ul class="nav nav-pills flex-column">
          <li>
            <a href="#" @click="logout" class="nav-link text-white" data-bs-toggle="tooltip" data-bs-placement="right" title="Log Out">
              <ion-icon class="bi me-2" name="log-out"><use xlink:href="#log-out"></use></ion-icon>
              <span class="d-none d-md-inline">Log Out</span>
            </a>
          </li>
        </ul>
      </div>
    </div>
    <!-- SIDEBAR -->

    
  <!-- CONTENT -->
  <div class="col-md-10 col-sm-11 offset-md-2 offset-sm-1">
        <!-- Header -->
        <div class="p-3 d-flex align-items-center justify-content-between position-fixed bg-light"
          style="width: 82%; z-index: 100">
          <div>
            <span class="fs-4 fw-bold text-primary">POSProcast</span>
          </div>
          <div class="d-flex align-items-center">
            <span class="fs-6"><?php echo $_SESSION['staff_name']; ?></span>
            <ion-icon class="ms-3" size="large" name="person-circle"></ion-icon>
          </div>
        </div>
        <!-- Header -->

        <div class="px-4 pt-5 pb-4 mt-5">
          <div class="row g-0 align-items-center">
            <div class="col-md-6 d-flex align-items-center justify-content-start">
              <h4>Generate Reports</h4>
            </div>
          </div>

          <!-- FORM -->
          <!-- Date Range -->
          <div class="row g-0 pt-4">
            <div class="col-md-6 d-flex justify-content-start">
              <div class="input-group">
                <label class="input-group-text" for="inputGroupSelect01">Date Range</label>
                <span class="input-group-text">Min</span>
                <input type="date" class="form-control" v-model="minDate" required>
                <span class="input-group-text">Max</span>
                <input type="date" class="form-control" v-model="maxDate" required>
                <!-- <button class="btn btn-sm btn-secondary"  @click="fetchReports">Filter</button> -->
              </div>
            </div>
            <!-- Combobox -->
            <div class="col-md-3 d-flex ms-5">
              <div class="input-group">
                <label class="input-group-text" for="dataType">Data Type</label>
                <select class="form-select" v-model="dataType" required>
                  <option value="" disabled selected>Choose...</option>
                  <option value="CSV">CSV</option>
                  <option value="PDF">PDF</option>
                  <option value="XLSX">XLSX</option>
                </select>
              </div>
            </div>
            <!-- Export Button -->
            <div class="col-md-2 d-flex justify-content-end ms-5">
              <!-- Show All Button -->
              <button class="btn btn-secondary mx-2" @click="resetFilters">Show All</button>
              <button class="btn btn-primary" type="submit" @click="exportData">Export</button>
            </div>

            <!-- Sales Report Table -->
            <div class="mt-4">
              <h5>Sales Report</h5>
              <div class="overflow-auto" style="max-height: 200px;">
                <table class="table table-striped text-center">
                  <thead class="bg-primary text-white" style="position:sticky; top:0;">
                    <tr>
                      <th class="col-2" scope="col">Product ID</th>
                      <th class="col-2" scope="col">Product Name</th>
                      <th class="col-2" scope="col">Quantity</th>
                      <th class="col-2" scope="col">Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="sale in filteredSales" :key="sale.prod_id" class="align-middle">
                      <td>{{ sale.prod_id }}</td>
                      <td>{{ sale.prod_name }}</td>
                      <td>{{ sale.prod_qty }}</td>
                      <td>{{ sale.total_price.toFixed(2) }}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <!-- Overall Total Sales Table -->
            <div class="mt-4">
              <h5>Overall Total Sales</h5>
              <div class="overflow-auto" style="max-height: 100px;">
                <table class="table table-bordered text-center">
                  <thead class="bg-secondary text-white">
                    <tr>
                      <th class="col-3">Total Quantity</th>
                      <th class="col-3">Total Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>{{ overallTotalSales.totalQuantity }}</td>
                      <td>{{ overallTotalSales.totalAmount.toFixed(2) }}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
             <!-- Low Products Qty Table -->
             <div class="mt-4">
              <h5>Low Products Qty Report</h5>
              <div class="overflow-auto" style="max-height: 500px;">
                <table class="table table-striped text-center">
                  <thead class="bg-secondary text-white">
                    <tr>
                      <th class="col-2" scope="col">Product Name</th>
                      <th class="col-2" scope="col">Product Qty</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="product, index in lowStocks" :key="index" class="align-middle">
                      <td>{{ product.prod_name }}</td>
                      <td>{{ product.prod_qty }}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <!-- Products Report Table -->
            <div class="mt-4">
              <h5>Products Rating Report</h5>
              <div class="overflow-auto" style="max-height: 500px;">
                <table class="table table-striped text-center">
                  <thead class="bg-secondary text-white">
                    <tr>
                      <th class="col-2" scope="col">Product ID</th>
                      <th class="col-2" scope="col">Product Name</th>
                      <th class="col-2" scope="col">Average Rating</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="product in averageRatings" :key="product.prod_id" class="align-middle">
                      <td>{{ product.prod_id }}</td>
                      <td>{{ product.prod_name }}</td>
                      <td>{{ product.avg_rating }}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        </div>
      </div>
      <!-- CONTENT -->

  </div>
</div>
 <!-- SheetJS for Excel Export -->
 <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>

<!-- Include jsPDF and jsPDF AutoTable Plugin -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.20/jspdf.plugin.autotable.min.js"></script>

<!-- Resources Script -->
<script src="https://unpkg.com/axios/dist/axios.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/vue@2.7.16/dist/vue.js"></script>
<!-- Resources Script -->

<!-- Ionicons -->
<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
<!-- Ionicons -->
<script>
  var app = new Vue({
    el: '#app',
    data: {
      lowStocks:[],
      allProducts: [],
      allSales: [],
      minDate: '',
      maxDate: '',
      dataType: ''
    },
    computed: {
      averageRatings() {
        const ratings = {};

        // Aggregate ratings for each product
        this.allProducts.forEach(product => {
          if (!ratings[product.prod_id]) {
            ratings[product.prod_id] = { prod_name: product.prod_name, totalRating: 0, count: 0 };
          }
          ratings[product.prod_id].totalRating += parseFloat(product.prod_rate);
          ratings[product.prod_id].count += 1;
        });

        // Calculate average ratings
        return Object.keys(ratings).map(prod_id => {
          const rating = ratings[prod_id];
          return {
            prod_id: prod_id,
            prod_name: rating.prod_name,
            avg_rating: (rating.totalRating / rating.count).toFixed(2) // Average rating rounded to 2 decimal places
          };
        });
      },
      filteredSales() {
        if (!this.minDate || !this.maxDate) return this.aggregateSales(this.allSales); // Return aggregated sales if no date range

        // Filter sales based on date range and then aggregate
        const filtered = this.allSales.filter(sale => {
          const saleDate = new Date(sale.ordered_at);
          return saleDate >= new Date(this.minDate) && saleDate <= new Date(this.maxDate);
        });
        return this.aggregateSales(filtered);
      },
      // Computed property for filtering products
      filteredProducts() {
        if (!this.minDate || !this.maxDate) return this.allProducts; // Return all if no date range
        return this.allProducts.filter(product => {
          const productDate = new Date(product.rated_at);
          return productDate >= new Date(this.minDate) && productDate <= new Date(this.maxDate);
        });
      },
      // Computed property to calculate overall total sales
      overallTotalSales() {
        return this.filteredSales.reduce((total, sale) => {
          total.totalQuantity += sale.prod_qty;
          total.totalAmount += sale.total_price;
          return total;
        }, { totalQuantity: 0, totalAmount: 0 });
      }
    },
    methods: {
      exportData() {
        const today = new Date().toISOString().slice(0, 10); // Format date as YYYY-MM-DD
        let fileName = `report_${today}`;

        if (this.dataType === 'CSV') {
          this.exportCSV(fileName);
        } else if (this.dataType === 'XLSX') {
          this.exportExcel(fileName);
        } else if (this.dataType === 'PDF') {
          this.exportPDF(fileName);
        }
      },
      exportCSV(fileName) {
          let csvContent = "data:text/csv;charset=utf-8,";

          // Sales Report
          csvContent += "Sales Report\n";
          csvContent += "Product ID,Product Name,Quantity,Amount\n";
          this.filteredSales.forEach(sale => {
            csvContent += `${sale.prod_id},${sale.prod_name},${sale.prod_qty},${sale.total_price.toFixed(2)}\n`;
          });

          // Overall Total Sales
          csvContent += "\nOverall Total Sales\n";
          csvContent += "Total Quantity,Total Amount\n";
          csvContent += `${this.overallTotalSales.totalQuantity},${this.overallTotalSales.totalAmount.toFixed(2)}\n`;

          // Products Rating Report
          csvContent += "\nLow Products Qty Report\n";
          csvContent += "Product Name,Product Quantity\n";
          this.lowStocks.forEach(product => {
            csvContent += `${product.prod_name},${product.prod_qty}\n`;
          });
          // Products Rating Report
          csvContent += "\nProducts Rating Report\n";
          csvContent += "Product ID,Product Name,Average Rating\n";
          this.averageRatings.forEach(product => {
            csvContent += `${product.prod_id},${product.prod_name},${product.avg_rating}\n`;
          });

          const encodedUri = encodeURI(csvContent);
          const link = document.createElement("a");
          link.setAttribute("href", encodedUri);
          link.setAttribute("download", `${fileName}.csv`);
          document.body.appendChild(link);
          link.click();
        },
        exportExcel(fileName) {
          const workbook = XLSX.utils.book_new();

          // Sales Report Sheet
          const salesData = this.filteredSales.map(sale => ({
            "Product ID": sale.prod_id,
            "Product Name": sale.prod_name,
            "Quantity": sale.prod_qty,
            "Amount": sale.total_price.toFixed(2)
          }));
          const salesSheet = XLSX.utils.json_to_sheet(salesData);
          XLSX.utils.book_append_sheet(workbook, salesSheet, "Sales Report");

          // Add borders and colors for sales sheet
          const salesSheetRange = XLSX.utils.decode_range(salesSheet['!ref']);
          for (let R = salesSheetRange.s.r; R <= salesSheetRange.e.r; ++R) {
            for (let C = salesSheetRange.s.c; C <= salesSheetRange.e.c; ++C) {
              const cell_address = { c: C, r: R };
              const cell_ref = XLSX.utils.encode_cell(cell_address);
              if (!salesSheet[cell_ref]) continue;
              salesSheet[cell_ref].s = {
                border: {
                  top: { style: 'thin' },
                  left: { style: 'thin' },
                  bottom: { style: 'thin' },
                  right: { style: 'thin' }
                }
              };
              if (R === salesSheetRange.s.r) {
                salesSheet[cell_ref].s.fill = {
                  fgColor: { rgb: "4F81BD" }
                };
                salesSheet[cell_ref].s.font = { bold: true, color: { rgb: "FFFFFF" } };
              }
            }
          }

          // Overall Total Sales Sheet
          const overallTotalData = [
            {
              "Total Quantity": this.overallTotalSales.totalQuantity,
              "Total Amount": this.overallTotalSales.totalAmount.toFixed(2)
            }
          ];
          const totalSalesSheet = XLSX.utils.json_to_sheet(overallTotalData);
          XLSX.utils.book_append_sheet(workbook, totalSalesSheet, "Overall Total Sales");

          // Low Products Qty Report Sheet
          const lowStockData = this.lowStocks.map(product => ({
            "Product Name": product.prod_name,
            "Product Quantity": product.prod_qty
          }));
          const lowStockSheet = XLSX.utils.json_to_sheet(lowStockData);
          XLSX.utils.book_append_sheet(workbook, lowStockSheet, "Low Products Qty Report");

          // Add borders and colors for low stock sheet
          const lowStockSheetRange = XLSX.utils.decode_range(lowStockSheet['!ref']);
          for (let R = lowStockSheetRange.s.r; R <= lowStockSheetRange.e.r; ++R) {
            for (let C = lowStockSheetRange.s.c; C <= lowStockSheetRange.e.c; ++C) {
              const cell_address = { c: C, r: R };
              const cell_ref = XLSX.utils.encode_cell(cell_address);
              if (!lowStockSheet[cell_ref]) continue;
              lowStockSheet[cell_ref].s = {
                border: {
                  top: { style: 'thin' },
                  left: { style: 'thin' },
                  bottom: { style: 'thin' },
                  right: { style: 'thin' }
                }
              };
              if (R === lowStockSheetRange.s.r) {
                lowStockSheet[cell_ref].s.fill = {
                  fgColor: { rgb: "4F81BD" }
                };
                lowStockSheet[cell_ref].s.font = { bold: true, color: { rgb: "FFFFFF" } };
              }
            }
          }

          // Products Rating Report Sheet
          const ratingsData = this.averageRatings.map(product => ({
            "Product ID": product.prod_id,
            "Product Name": product.prod_name,
            "Average Rating": product.avg_rating
          }));
          const ratingsSheet = XLSX.utils.json_to_sheet(ratingsData);
          XLSX.utils.book_append_sheet(workbook, ratingsSheet, "Products Rating Report");

          // Add borders and colors for ratings sheet
          const ratingsSheetRange = XLSX.utils.decode_range(ratingsSheet['!ref']);
          for (let R = ratingsSheetRange.s.r; R <= ratingsSheetRange.e.r; ++R) {
            for (let C = ratingsSheetRange.s.c; C <= ratingsSheetRange.e.c; ++C) {
              const cell_address = { c: C, r: R };
              const cell_ref = XLSX.utils.encode_cell(cell_address);
              if (!ratingsSheet[cell_ref]) continue;
              ratingsSheet[cell_ref].s = {
                border: {
                  top: { style: 'thin' },
                  left: { style: 'thin' },
                  bottom: { style: 'thin' },
                  right: { style: 'thin' }
                }
              };
              if (R === ratingsSheetRange.s.r) {
                ratingsSheet[cell_ref].s.fill = {
                  fgColor: { rgb: "4F81BD" }
                };
                ratingsSheet[cell_ref].s.font = { bold: true, color: { rgb: "FFFFFF" } };
              }
            }
          }

          // Save Excel file
          XLSX.writeFile(workbook, `${fileName}.xlsx`);
        },
        exportPDF(fileName) {
          const { jsPDF } = window.jspdf;
          const doc = new jsPDF();
          const tableColumn = ["Product ID", "Product Name", "Quantity", "Amount"];
          const tableRows = this.filteredSales.map(sale => [
            sale.prod_id,
            sale.prod_name,
            sale.prod_qty,
            sale.total_price.toFixed(2)
          ]);

          // Add date range
          doc.text(`Date Range: ${this.minDate} to ${this.maxDate}`, 10, 10);
          doc.text("Sales Report", 10, 20);

          doc.autoTable({
            startY: 30,
            head: [tableColumn],
            body: tableRows,
            theme: 'striped',
            headStyles: { fillColor: [0, 51, 102] },
            styles: { fontSize: 10 },
          });

          doc.autoTable({
            startY: doc.autoTable.previous.finalY + 10,
            head: [["Total Quantity", "Total Amount"]],
            body: [[
              this.overallTotalSales.totalQuantity,
              this.overallTotalSales.totalAmount.toFixed(2)
            ]],
            theme: 'striped',
            headStyles: { fillColor: [102, 102, 102] },
            styles: { fontSize: 10 },
          });
          const stocksColumn = ["Product Name", "Product Qty"];
          const stocksRows = this.lowStocks.map(product => [
            product.prod_name,
            product.prod_qty
          ]);
          // doc.text("Products Low Products Qty Report", 10, 20);


          doc.autoTable({
            startY: doc.autoTable.previous.finalY + 10,
            head: [stocksColumn],
            body: stocksRows,
            theme: 'striped',
            headStyles: { fillColor: [102, 102, 102] },
            styles: { fontSize: 10 },
          });

          const ratingTableColumn = ["Product ID", "Product Name", "Average Rating"];
          const ratingTableRows = this.averageRatings.map(product => [
            product.prod_id,
            product.prod_name,
            product.avg_rating
          ]);
          // doc.text("Products Rating Report", 10, 100);

          doc.autoTable({
            startY: doc.autoTable.previous.finalY + 10,
            head: [ratingTableColumn],
            body: ratingTableRows,
            theme: 'striped',
            headStyles: { fillColor: [102, 102, 102] },
            styles: { fontSize: 10 },
          });

          doc.save(`${fileName}.pdf`);
        },
      fetchReports() {
        // Fetching data without filtering on the server-side
        axios.post('../php/admin/fetchRatings.php', {}).then((response) => {
          this.allProducts = response.data;
        });
        axios.post('../php/admin/fetchLowStocks.php', {}).then((response) => {
            this.lowStocks = response.data;
          });
        axios.post('../php/admin/fetchSales.php', {}).then((response) => {
          this.allSales = response.data;
        });
      },
      // Method to aggregate sales by product ID
      aggregateSales(sales) {
        // Use reduce to aggregate sales by product ID
        const aggregated = sales.reduce((acc, sale) => {
          const existingSale = acc.find(item => item.prod_id === sale.prod_id);
          if (existingSale) {
            existingSale.prod_qty += parseInt(sale.prod_qty);
            existingSale.total_price += parseFloat(sale.total_price);
          } else {
            acc.push({
              prod_id: sale.prod_id,
              prod_name: sale.prod_name,
              prod_qty: parseInt(sale.prod_qty),
              total_price: parseFloat(sale.total_price)
            });
          }
          return acc;
        }, []);
        return aggregated;
      },
      // Method to reset filters
      resetFilters() {
        this.minDate = '';
        this.maxDate = '';
      },
      logout() {
        // Ask user for confirmation
        if (confirm('Are you sure you want to log out?')) {
          // If user confirms, proceed with logout
          axios.post('../php/staff/logout.php')
            .then(response => {
              // Check if the response indicates success or handle according to your needs
              if (response.status === 200) {
                // Redirect to home page or refresh the current page
                window.location.href = '../'; // Redirect to the home page
                // or use the following line to simply refresh the page
                // window.location.reload();
              } else {
                // Handle errors or unsuccessful logout if needed
                console.error('Logout failed:', response);
              }
            })
            .catch(error => {
              // Handle network or other errors
              console.error('Logout error:', error);
            });
        } else {
          // If the user cancels, do nothing
          console.log('Logout cancelled by user.');
        }
      }

    },
    created() {
      this.fetchReports();
    }
  });
</script>

</body>

</html>