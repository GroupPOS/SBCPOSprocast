<?php
session_start();

// Check if the session variable 'user_id' is set
if (!isset($_SESSION['user_id'])) {
  // If not set, redirect to the home page or any other page
  header("Location: ../");
  exit();
}
?>
<!DOCTYPE html>
<html class="h-100" lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" type="image/x-icon" href="../assets/sbc_icon.gif">
  <title>Inventory | Home</title>

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
    crossorigin="anonymous"></script>
  <!-- Bootstrap 5 -->

  <!-- CSS -->
  <link href="../css/sidebar.css" rel="stylesheet">

</head>
<style>
  .btn-square {
    width: 170px;
    height: 150px;
    text-align: center;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  /* Sidebar styles */
  #sidebar {
    background-color: #1167b1;
    transition: transform 0.3s ease;
  }

  /* Initially hide the sidebar on small screens */
  @media (max-width: 768px) {
    #sidebar {
      transform: translateX(-100%);
      position: fixed;
      z-index: 999;
    }

    .sidebar-visible #sidebar {
      width: 20%;
      transform: translateX(0);
    }

    #content {
      padding: 0;
      width: 100%;

    }

    .sidebar-visible #content {
      transition: transform 0.3s ease;
      margin-left: 20%;
    }
  }

  /* Hamburger icon styles */
  .hamburger {
    display: none;
  }

  @media (max-width: 768px) {
    .hamburger {
      display: block;
      font-size: 1.5rem;
      cursor: pointer;
      margin-left: 5px;
      margin-right: 10px;
    }
  }

  @media (max-width: 400px) {
    #username{
      display: none;
    }
  }
  /* Ensure content adjusts when sidebar is hidden */
  @media (max-width: 768px) {
    .content {
      padding-left: 0;
    }
  }
</style>

<body class="h-100">

  <div class="container-fluid h-100" id="app">
    <div class="row h-100">

      <!-- SIDEBAR -->
      <div class="col-md-2 col-sm-1 col-12 d-flex flex-column flex-shrink-0 h-100 p-3 text-white position-fixed"
        id="sidebar">
        <div class="d-flex justify-content-between align-items-center">
          <a href="/" class="d-flex align-items-center text-white text-decoration-none">
            <ion-icon size="large" class="bi me-3 ms-2" width="40" height="32" name="happy-outline"></ion-icon>
            <span class="d-none d-md-inline fs-4">User Profile</span>
          </a>
        </div>
        <hr>
        <ul class="nav nav-pills flex-column mb-auto">
          <li class="nav-item mb-2">
            <a href="#" class="nav-link active" aria-current="page" data-bs-toggle="tooltip" data-bs-placement="right"
              title="Home">
              <ion-icon class="bi me-2" name="home">
                <use xlink:href="#home"></use>
              </ion-icon>
              <span class="d-none d-md-inline">Home</span>
            </a>
          </li>
          <li class="mb-2">
            <a href="./userCart" class="nav-link text-white" data-bs-toggle="tooltip" data-bs-placement="right"
              title="Cart">
              <ion-icon class="bi me-2" name="cart">
                <use xlink:href="#cart"></use>
              </ion-icon>
              <span class="d-none d-md-inline">Cart</span>
            </a>
          </li>
          <li class="mb-2">
            <a href="./userTransaction" class="nav-link text-white" data-bs-toggle="tooltip" data-bs-placement="right"
              title="Cart">
              <ion-icon class="bi me-2" name="newspaper">
                <use xlink:href="#cart"></use>
              </ion-icon>
              <span class="d-none d-md-inline">Transaction</span>
            </a>
          </li>
          <li class="mb-2">
            <a href="./userSettings" class="nav-link text-white" data-bs-toggle="tooltip" data-bs-placement="right"
              title="Settings">
              <ion-icon class="bi me-2" name="settings">
                <use xlink:href="#settings"></use>
              </ion-icon>
              <span class="d-none d-md-inline">Settings</span>
            </a>
          </li>
        </ul>
        <div class="mt-auto">
          <hr>
          <ul class="nav nav-pills flex-column">
            <li>
              <a href="#" @click="logout" class="nav-link text-white" data-bs-toggle="tooltip" data-bs-placement="right"
                title="Log Out">
                <ion-icon class="bi me-2" name="log-out">
                  <use xlink:href="#log-out"></use>
                </ion-icon>
                <span class="d-none d-md-inline">Log Out</span>
              </a>
            </li>
          </ul>
        </div>
      </div>
      <!-- SIDEBAR -->


      <!-- CONTENT -->
      <div class="col-md-10 col-sm-11 offset-md-2 offset-sm-1 p-0" id="content">
        <!-- Header -->
        <!-- Hamburger icon for small screens -->
        <div class="d-flex align-items-center justify-content-between p-3 bg-light" style="top:0; position: sticky; z-index:999;">
          <div style="display:flex; width: fit-content; align-items:center;">
            <div class="hamburger" @click="toggleSidebar">
              <ion-icon name="menu-outline"></ion-icon>
            </div>
            <div>
              <span class="fs-4 text-primary"><strong>POSProcast</strong></span>
            </div>
          </div>

          <div class="d-flex align-items-center">
            <span class="fs-6" id="username"><?php echo $_SESSION['user_name']; ?></span>
            <ion-icon class="ms-3" size="large" name="person-circle"></ion-icon>
          </div>
        </div>
        <!-- Header -->


        <div class="px-4 pt-4 pb-4  bg-light" style="top:50px; position: sticky; z-index:999;">
          <!-- Store status alert -->
          <div v-if="!storeStatus" class="alert alert-warning d-flex align-items-center gap-2" role="alert">
            <ion-icon name="warning-outline" style="font-size:20px; font-weight:bold;"></ion-icon>
            <div>
              The store is currently <strong>closed</strong>. Please come back later.
            </div>
          </div>
          <!-- Store status alert -->
          <!-- Search Input Field -->
          <div class="input-group">
            <div class="col-md-4 position-relative">
              <input type="text" v-model="searchQuery" class="form-control" placeholder="Search Product..."
                aria-label="Search" aria-describedby="button-addon2">

              <button v-if="searchQuery" class="btn btn-outline-light position-absolute end-0 top-0 me-2 "
                @click="clearSearch" style="border:none; background:transparent; color:#555;">
                <ion-icon name="close-circle"></ion-icon>
              </button>
            </div>
            <button class="btn btn-primary" type="button" id="button-addon2"><ion-icon
                name="search"></ion-icon></button>
          </div>
          <!-- Search Input Field -->

        </div>
        <!-- Alert Message -->
        <div v-if="showAlert" class="px-4" style="top:150px; position: sticky; z-index:999;">
          <div v-if="showAlert" class="alert mt-2" :class="'alert-' + alertType" role="alert">
            {{ alertMessage }}
          </div>
        </div>
        <!-- Alert Message -->
        <!-- Category Section -->
        <div class="px-4 mt-3">
          <span class="fs-5">Categories</span>
          <div class="d-flex flex-wrap mt-2">
            <button v-for="category in categories" :key="category" class="btn btn-outline-secondary me-2 mb-2"
              @click="setCategory(category)">
              {{ category }}
            </button>
          </div>
        </div>
        <!-- Category Section -->

     <!-- Suggested -->
    <div v-if="!searchQuery" class="p-4">
      <span class="fs-5">Suggested for you</span>
      <div class="row mt-4">
        <div class="col-lg-3 col-md-4 col-sm-6 col-12 mb-3" v-for="product in allSuggested" :key="product.id">
          <div class="card bg-primary h-100 d-flex align-items-center">
            <div class="row g-0 w-100">
              <div class="col-5 d-flex align-items-center ps-3">
                <img :src="'../assets/images/' + product.prod_image"
                  onerror="this.src='../assets/images/default.webp';" class="card-img-top rounded img-fluid"
                  style="max-height:100px; width:auto;" alt="Product Image">
              </div>
              <div class="col-7">
                <div class="card-body">
                  <span class="card-title fs-6 text-light">{{ product.prod_name }}</span>
                  <div class="text-light d-flex align-items-center">
                    <span v-if="product.rating_count > 0" class="me-2">{{ product.average_rating.toFixed(1) }}</span>
                    <ion-icon v-for="n in 5" :name="n <= Math.round(product.average_rating) ? 'star' : 'star-outline'"></ion-icon>
                  </div>
                  <p class="card-text text-light fw-bold">₱{{ product.prod_price }}</p>
                  <!-- Conditionally display button or "No Stocks" -->
                  <div v-if="product.prod_qty > 2">
                    <button class="btn btn-sm btn-light text-primary btn-cart" @click="addToCart(product)">Add to Cart</button>
                  </div>
                  <div v-else>
                    <span class="text-warning fw-bold">Out of Stocks</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>


        <!-- All Products -->
        <div v-if="filteredProducts.length > 0" class="p-4">
          <span class="fs-5">All Products</span>
          <div class="row mt-4">
            <div class="col-lg-3 col-md-4 col-sm-6 col-12 mb-3" v-for="product in filteredProducts" :key="product.id">
              <div class="card bg-primary h-100 d-flex align-items-center">
                <div class="row g-0 w-100">
                  <div class="col-5 d-flex align-items-center ps-3">
                    <img :src="'../assets/images/' + product.prod_image"
                      onerror="this.src='../assets/images/default.webp';" class="card-img-top rounded img-fluid"
                      style="max-height:100px; width:auto;" alt="Product Image">
                  </div>
                  <div class="col-7">
                    <div class="card-body">
                      <span class="card-title fs-6 text-light">{{ product.prod_name }}</span>
                      <div class="text-light d-flex align-items-center">
                        <span v-if="product.rating_count > 0" class="me-2">{{ product.average_rating.toFixed(1)
                          }}</span>
                        <ion-icon v-for="n in 5"
                          :name="n <= Math.round(product.average_rating) ? 'star' : 'star-outline'"></ion-icon>
                      </div>
                      <p class="card-text text-light fw-bold">₱{{ product.prod_price }}</p>
                      <!-- Conditionally display button or "No Stocks" -->
                      <div v-if="product.prod_qty > 2">
                        <button class="btn btn-sm btn-light text-primary btn-cart" @click="addToCart(product)">Add to Cart</button>
                      </div>
                      <div v-else>
                        <span class="text-warning fw-bold">Out of Stocks</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>


        <!-- All Products -->

        <!-- No Products Found -->
        <div v-if="searchQuery && filteredProducts.length === 0" class="p-4">
          <span class="fs-5">No products found</span>
        </div>
        <!-- No Products Found -->

        <!-- All Products -->
      </div>
      <!-- CONTENT -->

    </div>
  </div>

  <!-- Resources Script -->
  <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/vue@2.7.16/dist/vue.js"></script>
  <!-- Resources Script -->

  <!-- Ionicons -->
  <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
  <!-- Ionicons -->

  <script>
    new Vue({
      el: '#app',
      data: {
        searchQuery: '',
        allProducts: [],
        allSuggested: [],
        categories: ['Ballpen', 'Uniform', 'Men Pants', 'PE Uniform', 'ID Lace', 'Notebook', 'Medal', 'Sticker', 'Kids', 'Elementary', 'High School', 'College'],
        alertMessage: '',
        alertType: '',
        storeStatus:false,
        showAlert: false,
        sidebarVisible: false,
      },
      computed: {
        filteredProducts() {
          if (this.searchQuery) {
            return this.allProducts.filter(product =>
              product.prod_name.toLowerCase().includes(this.searchQuery.toLowerCase())
            );
          }
          return this.allProducts;
        }
      },
      methods: {
        fetchStoreStatus(){
          axios.post('../php/admin/fetchStoreStatus.php')
          .then(response => {
            // console.log(response.data.status);
            this.storeStatus = response.data.status;
          });
        },
        toggleSidebar() {
          this.sidebarVisible = !this.sidebarVisible;
          document.body.classList.toggle('sidebar-visible', this.sidebarVisible);
        },
        setCategory(category) {
          this.searchQuery = category;
        },
        addToCart(product) {
          axios.post('../php/user/addToCart.php', {
            prod_id: product.prod_id,
            prod_name: product.prod_name,
            prod_image: product.prod_image,
            prod_price: product.prod_price,
            prod_qty: 1
          })
            .then(response => {
              if (response.data.status === 'success') {
                this.showAlertMessage('success', response.data.message);
              } else {
                this.showAlertMessage('danger', response.data.message);
              }
            })
            .catch(error => {
              this.showAlertMessage('danger', "There was an error adding the product to the cart.");
              console.error("There was an error adding the product to the cart:", error);
            });
        },
        clearSearch() {
          this.searchQuery = '';  // Clear the search field
        },
        showAlertMessage(type, message) {
          this.alertType = type;
          this.alertMessage = message;
          this.showAlert = true;
          setTimeout(() => {
            this.showAlert = false;
          }, 3000);  // Hide alert after 3 seconds
        },
        getSuggested() {
          axios.post('../php/user/getSuggested.php').then(response => {
            this.allSuggested = response.data;
          });
        },
        getAllProducts() {
          axios.post('../php/user/fetchAllProduct.php').then(response => {
            this.allProducts = response.data;
          });
        },
        logout() {

          if (confirm('Are you sure you want to log out?')) {
            axios.post('../php/user/logout.php')
              .then(response => {
                // Check if the response indicates success or handle according to your needs
                if (response.status === 200) {
                  // Redirect to home page or refresh the current page
                  window.location.href = '../'; // Redirect to the home page
                  // or use the following line to simply refresh the page
                  // window.location.reload();
                } else {
                  // Handle errors or unsuccessful logout if needed
                  console.error('Logout failed:', response);
                }
              })
              .catch(error => {
                // Handle network or other errors
                console.error('Logout error:', error);
              });
          } else {
            // If the user cancels, do nothing
            console.log('Logout cancelled by user.');
          }
        }
      },
      created() {
        this.fetchStoreStatus();
        this.getAllProducts();
        this.getSuggested();
      }
    });

  </script>


</body>

</html>