<html>
              <head>
                  <title>Receipt</title>
                  <style>
                      @media print {
                          body {
                              margin: 0;
                              padding: 0;
                              width: 57mm; /* Adjust width to fit your thermal printer */
                              height: 50mm; /* Adjust height to fit your thermal printer */
                              font-size: 12px; /* Adjust font size as needed */
                          }
                      }
                  </style>
              </head>
              <body>
                  <div>
                      <div>Company Name</div>
                      <div>Customer Name</div>
                      <div>Order No</div>
                      <div>1 x Item</div>
                      <div>1 x Item</div>
                      <div>1 x Item</div>
                      <div>12.00</div>
                  </div>
              </body>
              </html>