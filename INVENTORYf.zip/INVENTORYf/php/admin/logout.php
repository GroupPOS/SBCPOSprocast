<?php
session_start();

// Check if the admin is logged in and retrieve their information before logging out
$admin_id = $_SESSION['admin_id'] ?? null;
$admin_name = $_SESSION['admin_name'] ?? null;

require '../database/db_conn.php';

if ($admin_id && $admin_name) {
    try {
        // Prepare and execute the log entry for logout
        $log_type = 'logout';
        $user_type = 'admin';
        $log_info = "Admin \"$admin_name\" logged out.";

        $logStmt = $conn->prepare("INSERT INTO logs (user_type, user_name, user_id, log_type, log_info) VALUES (?, ?, ?, ?, ?)");
        $logStmt->execute([$user_type, $admin_name, $admin_id, $log_type, $log_info]);
    } catch (PDOException $e) {
        // Handle error if logging fails (optional)
        error_log('Error logging admin logout action: ' . $e->getMessage());
    }
}

// Unset specific session variables
unset($_SESSION['admin_id']);
unset($_SESSION['admin_role']);
unset($_SESSION['admin_name']);

// Optionally destroy the session if you want to clear all session data
// session_destroy();

// Redirect to login page or another page after logout
header("Location: ../");
exit();
