
<?php
require '../database/db_conn.php';


// SQL query to fetch the count of products
$sql = "SELECT COALESCE(FORMAT(SUM(order_total), 2), '0.00') AS total_sales
FROM (
    SELECT order_id, SUM(overall_total) AS order_total
    FROM sales
    WHERE YEAR(ordered_at) = YEAR(CURDATE()) AND MONTH(ordered_at) = MONTH(CURDATE())
    GROUP BY order_id
) AS monthly_totals;
";
$stmt = $conn->prepare($sql);
$stmt->execute();

// Fetching the product count
$monthlySales  = $stmt->fetch(PDO::FETCH_ASSOC);

// Close the connection
$conn = null;

// Convert the result to JSON
$jsonData = json_encode($monthlySales , JSON_PRETTY_PRINT);

echo $jsonData;
