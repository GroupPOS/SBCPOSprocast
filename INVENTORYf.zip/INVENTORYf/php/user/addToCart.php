<?php
require '../database/db_conn.php';

session_start();

$received_data = json_decode(file_get_contents("php://input"), true);

try {
    // Get the POST data
    $prod_id = $received_data['prod_id'];
    $prod_name = $received_data['prod_name'];
    $prod_image = $received_data['prod_image'];
    $prod_price = $received_data['prod_price'];
    $prod_qty = $received_data['prod_qty'];
    $user_id = $_SESSION['user_id'];  
    $user_name = $_SESSION['user_name']; 

    // Check if the product is already in the cart for this user
    $check_sql = "SELECT * FROM cart WHERE prod_id = :prod_id AND user_id = :user_id";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bindParam(':prod_id', $prod_id);
    $check_stmt->bindParam(':user_id', $user_id);
    $check_stmt->execute();

    if ($check_stmt->rowCount() > 0) {
        // If the product is already in the cart, return a message
        echo json_encode(['status' => 'info', 'message' => 'Item already in cart.']);
    } else {
        // SQL query to insert the product into the cart table
        $sql = "INSERT INTO cart (prod_id, prod_name, prod_image, prod_price, prod_qty, user_id, user_name)
                VALUES (:prod_id, :prod_name, :prod_image, :prod_price, :prod_qty, :user_id, :user_name)";
        $stmt = $conn->prepare($sql);

        // Bind parameters
        $stmt->bindParam(':prod_id', $prod_id);
        $stmt->bindParam(':prod_name', $prod_name);
        $stmt->bindParam(':prod_image', $prod_image);
        $stmt->bindParam(':prod_price', $prod_price);
        $stmt->bindParam(':prod_qty', $prod_qty);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':user_name', $user_name);

        // Execute the query
        if ($stmt->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'Product added to cart successfully.']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to add product to cart.']);
        }
    }

} catch(PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => 'Connection failed: ' . $e->getMessage()]);
    exit;
}

// Close the connection
$conn = null;
