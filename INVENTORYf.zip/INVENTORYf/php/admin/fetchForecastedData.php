<?php

require '../database/db_conn.php';

// Function to fetch average forecasted data for the current month with product names
function fetchMonthlyAverageForecastedData($conn) {
    $sql = "SELECT p.prod_id, p.prod_name, AVG(pf.forecast_value) AS average_forecast_value 
            FROM product_forecast pf
            INNER JOIN products p ON pf.prod_id = p.prod_id
            WHERE MONTH(pf.forecast_date) = MONTH(CURRENT_DATE) 
            AND YEAR(pf.forecast_date) = YEAR(CURRENT_DATE)
            GROUP BY p.prod_id, p.prod_name";
    $stmt = $conn->prepare($sql);
    $stmt->execute();

    // Fetch average forecast data for the current month with product names
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Fetch monthly average forecasted data
$averageForecastData = fetchMonthlyAverageForecastedData($conn);

// Format average forecast values to two decimals
foreach ($averageForecastData as &$data) {
    $data['average_forecast_value'] = number_format($data['average_forecast_value'], 2, '.', '');
}

// Return the average forecast data as JSON
$response = [
    'average_forecast_data' => $averageForecastData
];

header('Content-Type: application/json');
echo json_encode($response);

?>
