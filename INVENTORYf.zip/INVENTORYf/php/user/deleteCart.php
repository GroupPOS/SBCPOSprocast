<?php
require '../database/db_conn.php';

session_start();
$received_data = json_decode(file_get_contents("php://input"));

$user_id = $received_data->user_id;
$product_ids = $received_data->product_ids;

if (!is_array($product_ids) || empty($product_ids)) {
    echo json_encode(['success' => false, 'message' => 'Invalid product IDs']);
    exit;
}

// Use placeholders for product IDs
$placeholders = implode(',', array_fill(0, count($product_ids), '?'));

// Prepare the SQL statement using PDO placeholders
$sql = "DELETE FROM cart WHERE user_id = ? AND prod_id IN ($placeholders)";
$stmt = $conn->prepare($sql);

// Bind the user ID as the first parameter
$params = array_merge([$user_id], $product_ids);
$result = $stmt->execute($params);

if ($result) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false]);
}
