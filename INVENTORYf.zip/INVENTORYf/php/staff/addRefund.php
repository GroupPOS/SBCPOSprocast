<?php
session_start();

require '../database/db_conn.php';

// Retrieve JSON input
$received_data = json_decode(file_get_contents("php://input"));

if ($received_data) {
    // Prepare and bind for refund insertion
    $stmt = $conn->prepare("INSERT INTO refunds (prod_code, prod_name, prod_price, reason, buyer_id, buyer_name) 
                             VALUES (:prod_code, :prod_name, :prod_price, :reason, :buyer_id, :buyer_name)");

    $stmt->bindParam(':prod_code', $received_data->prodCode);
    $stmt->bindParam(':prod_name', $received_data->prodName);
    $stmt->bindParam(':prod_price', $received_data->refundAmount);
    $stmt->bindParam(':reason', $received_data->refundReason);
    $stmt->bindParam(':buyer_id', $received_data->buyerId);
    $stmt->bindParam(':buyer_name', $received_data->buyerName);

    try {
        // Execute the statement
        $stmt->execute();

        // Log the transaction with log type 'refund'
        $log_type = 'refund';
        $log_info = "Product Code: {$received_data->prodCode}, Product Name: {$received_data->prodName}, Amount: {$received_data->refundAmount}, Reason: {$received_data->refundReason}";

        // Assuming $user_name and $user_id are available from session or passed in the request
        $user_name = $_SESSION['staff_name']; // Adjust as necessary to retrieve the staff name
        $user_id = $_SESSION['staff_id']; // Adjust as necessary to retrieve the staff ID

        $logStmt = $conn->prepare("INSERT INTO logs (user_type, user_name, user_id, log_type, log_info) VALUES (?, ?, ?, ?, ?)");
        $logStmt->execute(['staff', $user_name, $user_id, $log_type, $log_info]);

        echo json_encode(['success' => true, 'message' => "Refund request added successfully!"]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => "Error adding refund: " . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => "Invalid input."]);
}

$conn = null; // Close the connection
?>
