<?php
require '../database/db_conn.php';

session_start();

$received_data = json_decode(file_get_contents("php://input"));
$order_id = $received_data->order_id;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        // Begin transaction
        $conn->beginTransaction();

        // Update the order status to 'paid'
        $query = "UPDATE orders SET status = 'paid' WHERE order_id = :order_id";
        $stmt = $conn->prepare($query);
        $stmt->bindValue(':order_id', $order_id, PDO::PARAM_INT);

        if ($stmt->execute()) {
            // Retrieve products and their quantities from the order
            $productQuery = "SELECT prod_id, prod_qty FROM orders WHERE order_id = :order_id";
            $productStmt = $conn->prepare($productQuery);
            $productStmt->bindParam(':order_id', $order_id);
            $productStmt->execute();
            $orderItems = $productStmt->fetchAll(PDO::FETCH_ASSOC);

            // Loop through each product and update its stock
            foreach ($orderItems as $item) {
                $prod_id = $item['prod_id'];
                $prod_qty = $item['prod_qty'];

                // Update the product stock in the products table
                $updateStockQuery = "UPDATE products SET prod_qty = prod_qty - :prod_qty WHERE prod_id = :prod_id";
                $updateStockStmt = $conn->prepare($updateStockQuery);
                $updateStockStmt->bindParam(':prod_qty', $prod_qty, PDO::PARAM_INT);
                $updateStockStmt->bindParam(':prod_id', $prod_id, PDO::PARAM_INT);
                $updateStockStmt->execute();
            }

            // Commit the transaction for order status and stock updates
            $conn->commit();

            // Insert log entry for online payment
            $logStmt = $conn->prepare("
                INSERT INTO logs (user_type, user_name, user_id, log_type, log_info) 
                VALUES (:user_type, :user_name, :user_id, :log_type, :log_info)
            ");

            $user_id = $_SESSION['user_id'];
            $user_name = $_SESSION['user_name'];
            $user_type = 'user';
            $log_type = 'online_payment';
            $log_info = $user_name . " made a payment for Order ID: " . $order_id;

            $logStmt->bindParam(':user_type', $user_type);
            $logStmt->bindParam(':user_name', $user_name);
            $logStmt->bindParam(':user_id', $user_id);
            $logStmt->bindParam(':log_type', $log_type);
            $logStmt->bindParam(':log_info', $log_info);

            if ($logStmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'Payment successful, stock updated, and log created']);
            } else {
                echo json_encode(['success' => true, 'message' => 'Payment successful, stock updated, but log creation failed']);
            }
        } else {
            $conn->rollBack();
            echo json_encode(['success' => false, 'message' => 'Failed to update order status']);
        }
    } catch (PDOException $e) {
        $conn->rollBack();
        echo json_encode(['success' => false, 'message' => "Error: " . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>
