<?php
require '../database/db_conn.php';


$received_data = json_decode(file_get_contents("php://input"));
$user_id = $received_data->user_id;

// Prepare SQL statement with placeholders
$sql = "SELECT * FROM orders 
        WHERE user_id = :user_id
        GROUP BY order_id
        ORDER BY ordered_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
$stmt->execute();

// Fetching the products
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Close the connection
$conn = null;

// Convert the fetched data to JSON
$jsonData = json_encode($products);
echo $jsonData;
?>
