<?php
session_start();
require '../database/db_conn.php';

// Check if the user is logged in and retrieve their information before logging out
$user_id = $_SESSION['staff_id'] ?? null;
$user_name = $_SESSION['staff_name'] ?? null;

if ($user_id && $user_name) {
    try {
        // Prepare and execute the log entry for logout
        $log_type = 'logout';
        $log_info = "User $user_name (ID: $user_id) logged out.";

        $logStmt = $conn->prepare("INSERT INTO logs (user_type, user_name, user_id, log_type, log_info) VALUES (?, ?, ?, ?, ?)");
        $logStmt->execute(['staff', $user_name, $user_id, $log_type, $log_info]);
    } catch (PDOException $e) {
        // Handle error if logging fails (optional)
        error_log('Error logging logout action: ' . $e->getMessage());
    }
}

// Unset specific session variables
unset($_SESSION['staff_id']);
unset($_SESSION['staff_role']);
unset($_SESSION['staff_name']);

// Optionally destroy the session if you want to clear all session data
// session_destroy();

// Redirect to login page or another page after logout
header("Location: ../");
exit();
