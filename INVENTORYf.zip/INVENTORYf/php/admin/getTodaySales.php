
<?php
require '../database/db_conn.php';


// SQL query to fetch the count of products
$sql = "SELECT COALESCE(FORMAT(SUM(order_total), 2), '0.00') AS total_sales
FROM (
    SELECT order_id, SUM(overall_total) AS order_total
    FROM sales
    WHERE DATE(ordered_at) = CURDATE()
    GROUP BY order_id
) AS daily_totals;";
$stmt = $conn->prepare($sql);
$stmt->execute();

// Fetching the product count
$todaySales = $stmt->fetch(PDO::FETCH_ASSOC);

// Close the connection
$conn = null;

// Convert the result to JSON
$jsonData = json_encode($todaySales, JSON_PRETTY_PRINT);

echo $jsonData;
