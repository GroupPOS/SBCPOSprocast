<?php
require '../database/db_conn.php';


$received_data = json_decode(file_get_contents("php://input"));
$user_id = $received_data->user_id;


// SQL query to fetch orders
$sql = "SELECT * FROM logs  WHERE user_id = '$user_id'" ;
$stmt = $conn->prepare($sql);
$stmt->execute();

// Fetching orders
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Close the connection
$conn = null;

// Convert the aggregated data to JSON
$jsonData = json_encode($orders);

echo $jsonData;
