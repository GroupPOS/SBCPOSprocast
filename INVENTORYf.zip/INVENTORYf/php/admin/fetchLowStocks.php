<?php
require '../database/db_conn.php';

// Prepare and execute the SQL query to fetch products with low stock
$sql = "SELECT prod_name, prod_qty FROM products WHERE prod_qty < 10";
$stmt = $conn->prepare($sql);
$stmt->execute();

// Fetch the results as an associative array
$lowStockProducts = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Return the low stock products as JSON
header('Content-Type: application/json');
echo json_encode($lowStockProducts);

// Close the connection by setting the PDO object to null
$conn = null;