<?php
// Connect to the database
require '../database/db_conn.php';

    // SQL query to fetch the product by barcode
    $sql = "SELECT * FROM refunds ORDER BY created_at DESC";
    $stmt = $conn->prepare($sql);
    $stmt->execute();

    // Fetch the product
    $product = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($product) {
        // Convert the product data to JSON
        echo json_encode($product);
    } else {
        // If no product found, return an empty response
        echo json_encode([]);
    }   
// Close the connection
$conn = null;
