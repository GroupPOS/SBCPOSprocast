<?php
require '../database/db_conn.php';


// SQL query to fetch the count of products
$sql = "SELECT COUNT(*) as order_count FROM sales WHERE DATE(ordered_at) = CURDATE();";
$stmt = $conn->prepare($sql);
$stmt->execute();

// Fetching the product count
$ordersCount = $stmt->fetch(PDO::FETCH_ASSOC);

// Close the connection
$conn = null;

// Convert the result to JSON
$jsonData = json_encode($ordersCount, JSON_PRETTY_PRINT);

echo $jsonData;
