<?php

require '../database/db_conn.php';

$finalSale = "SELECT prod_name, SUM(overall_total) AS total_sales
        FROM sales
        WHERE YEAR(ordered_at) = YEAR(CURDATE())
        GROUP BY prod_name";

$finalSalestmt = $conn->prepare($finalSale);
$finalSalestmt->execute();

$finalSaleData = $finalSalestmt->fetchAll(PDO::FETCH_ASSOC);


// Fetch sales data
$sql = "SELECT prod_id, ordered_at, SUM(overall_total) AS total_sales
        FROM sales
        WHERE YEAR(ordered_at) = YEAR(CURDATE())
        GROUP BY prod_id, ordered_at
        ORDER BY ordered_at";

$stmt = $conn->prepare($sql);
$stmt->execute();

$salesData = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Function to forecast sales using a simple moving average
function forecastSales($salesData, $periods = 30) {
    $forecasts = [];
    $productSales = [];

    // Group sales data by product
    foreach ($salesData as $row) {
        $prodId = $row['prod_id'];
        $orderedAt = $row['ordered_at'];
        $totalSales = $row['total_sales'];

        // Store sales by product
        if (!isset($productSales[$prodId])) {
            $productSales[$prodId] = [];
        }
        $productSales[$prodId][$orderedAt] = $totalSales;
    }

    // Calculate forecasts
    foreach ($productSales as $prodId => $sales) {
        // Sort sales by date
        ksort($sales);
        $salesValues = array_values($sales);
        
        // Use the last n sales for forecasting
        $recentSales = array_slice($salesValues, -5); // Last 5 sales for moving average
        
        // Calculate the moving average
        $forecastValue = count($recentSales) > 0 ? array_sum($recentSales) / count($recentSales) : 0;

        // Prepare forecast for the next 'periods' days
        for ($i = 1; $i <= $periods; $i++) {
            $forecastDate = date('Y-m-d', strtotime("+$i days"));
            $forecasts[] = [
                'prod_id' => $prodId,
                'forecast_date' => $forecastDate,
                'forecast_value' => $forecastValue
            ];
        }
    }
    
    return $forecasts;
}

// Generate forecasts
$forecastData = forecastSales($salesData);

$sqlCheck = "SELECT COUNT(*) FROM product_forecast WHERE  DATE(created_at) = CURDATE()";
$stmtCheck = $conn->prepare($sqlCheck);
$stmtCheck->execute();

$exists = $stmtCheck->fetchColumn();

// If no existing forecast for today, insert the new forecast
if ($exists == 0) {
        // Check if forecasts for today already exist
        foreach ($forecastData as $forecast) {
        $forecastDate = $forecast['forecast_date'];
        
                $sqlInsert = "INSERT INTO product_forecast (prod_id, forecast_date, forecast_value) VALUES (:prod_id, :forecast_date, :forecast_value)";
                $stmtInsert = $conn->prepare($sqlInsert);
                $stmtInsert->bindParam(':prod_id', $forecast['prod_id']);
                $stmtInsert->bindParam(':forecast_date', $forecastDate);
                $stmtInsert->bindParam(':forecast_value', $forecast['forecast_value']);
                $stmtInsert->execute();
        }
}

// Return the sales data and forecasts as JSON
$response = [
    'sales_data' => $finalSaleData,
    'forecast_data' => $forecastData
];

echo json_encode($response);
