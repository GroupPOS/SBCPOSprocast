<?php
require '../database/db_conn.php';


$received_data = json_decode(file_get_contents("php://input"));
$order_id = $received_data->order_id;

// Prepare SQL statement with placeholders
$sql = "SELECT * FROM orders 
        WHERE order_id = :order_id
        ORDER BY ordered_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':order_id', $order_id, PDO::PARAM_INT);
$stmt->execute();

// Fetching the products
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Close the connection
$conn = null;

// Convert the fetched data to JSON
$jsonData = json_encode($products);
echo $jsonData;
?>
