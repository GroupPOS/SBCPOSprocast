<?php

require '../database/db_conn.php';

    $stmt = $conn->prepare("SELECT status FROM store_status ORDER BY updated_at DESC LIMIT 1");
    $stmt->execute();
    
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result) {
        echo json_encode(['success' => true, 'status' => $result['status']]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Store not found']);
    }

