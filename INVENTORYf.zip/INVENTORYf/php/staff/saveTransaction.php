<?php
session_start(); 
require '../database/db_conn.php';


// Receive data from the request body
$data = json_decode(file_get_contents("php://input"), true);

// Validate received data
if (!isset($data['transaction_type']) || !isset($data['staff_id']) || !isset($data['staff_name']) || !isset($data['order_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Incomplete data provided.']);
    exit();
}

$transaction_type = $data['transaction_type'];
$staff_id = $data['staff_id'];
$staff_name = $data['staff_name'];
$order_id = $data['order_id'];

try {
    // Prepare and execute the SQL query to insert transaction details
    $stmt = $conn->prepare("INSERT INTO transactions (transaction_type, staff_id, staff_name, order_id) 
                            VALUES (:transaction_type, :staff_id, :staff_name, :order_id)");

    $stmt->bindParam(':transaction_type', $transaction_type);
    $stmt->bindParam(':staff_id', $staff_id);
    $stmt->bindParam(':staff_name', $staff_name);
    $stmt->bindParam(':order_id', $order_id);

    $stmt->execute();

    echo json_encode(['status' => 'success', 'message' => 'Transaction saved successfully.']);
} catch(PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => 'Failed to save transaction: ' . $e->getMessage()]);
}
