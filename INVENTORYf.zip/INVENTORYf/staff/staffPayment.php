<?php
session_start();

// Check if the session variable 'user_id' is set
if (!isset($_SESSION['staff_id'])) {
  // If not set, redirect to the home page or any other page
  header("Location: ../");
  exit();
}
?>
<!DOCTYPE html>
<html class="h-100" lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="../assets/sbc_icon.gif">
  <title>Inventory | Refund Option</title>

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
    crossorigin="anonymous"></script>
  <!-- Bootstrap 5 -->

  <!-- CSS -->
  <link href="../css/sidebar.css" rel="stylesheet">

</head>

<body class="h-100">

  <div class="container-fluid h-100" id="app">
    <div class="row h-100">

      <!-- SIDEBAR -->
      <div class="col-md-2 col-sm-1 col-12 d-flex flex-column flex-shrink-0 h-100 p-3 text-white  position-fixed"
        style="background:#1167b1;" id="sidebar">
        <div class="d-flex justify-content-between align-items-center">
          <a href="." class="d-flex align-items-center text-white text-decoration-none">
            <ion-icon size="large" class="bi me-3 ms-2" width="40" height="32" name="happy-outline"></ion-icon>
            <span class="d-none d-md-inline fs-4">Staff Profile</span>
          </a>
        </div>
        <hr>
        <ul class="nav nav-pills flex-column mb-auto">
          <li class="nav-item mb-2">
            <a href="./staffPos" class="nav-link text-white" aria-current="page" data-bs-toggle="tooltip"
              data-bs-placement="right" title="Home">
              <ion-icon class="bi me-2" name="card"></ion-icon>
              <span class="d-none d-md-inline">POS</span>
            </a>
          </li>
          <li class="nav-item mb-2">
            <a href="./staffOnline" class="nav-link text-white " aria-current="page" data-bs-toggle="tooltip"
              data-bs-placement="right" title="E-payment">
              <ion-icon class="bi me-2" name="card"></ion-icon>
              <span class="d-none d-md-inline">E-payments</span>
            </a>
          </li>
          <li class="nav-item mb-2">
            <a href="#" class="nav-link active" aria-current="page" data-bs-toggle="tooltip" data-bs-placement="right"
              title="Refunds">
              <ion-icon class="bi me-2" name="arrow-undo-circle-outline"></ion-icon>
              <span class="d-none d-md-inline">Refunds</span>
            </a>
          </li>
          <li class="mb-2">
            <a href="./staffTransaction" class="nav-link text-white" data-bs-toggle="tooltip" data-bs-placement="right"
              title="Transaction">
              <ion-icon class="bi me-2" name="cart">
                <use xlink:href="#cart"></use>
              </ion-icon>
              <span class="d-none d-md-inline">Transaction</span>
            </a>
          </li>
          <li class="mb-2">
            <a href="./staffReports.php" class="nav-link text-white" data-bs-toggle="tooltip" data-bs-placement="right"
              title="Reports">
              <ion-icon class="bi me-2" name="document">
                <use xlink:href="#reports"></use>
              </ion-icon>
              <span class="d-none d-md-inline">Reports</span>
            </a>
          </li>
          <li class="mb-2">
            <a href="./staffSettings.php" class="nav-link text-white" data-bs-toggle="tooltip" data-bs-placement="right"
              title="Settings">
              <ion-icon class="bi me-2" name="settings">
                <use xlink:href="#settings"></use>
              </ion-icon>
              <span class="d-none d-md-inline">Settings</span>
            </a>
          </li>
        </ul>
        <div class="mt-auto">
          <hr>
          <ul class="nav nav-pills flex-column">
            <li>
              <a href="#" @click="logout" class="nav-link text-white" data-bs-toggle="tooltip" data-bs-placement="right"
                title="Log Out">
                <ion-icon class="bi me-2" name="log-out">
                  <use xlink:href="#log-out"></use>
                </ion-icon>
                <span class="d-none d-md-inline">Log Out</span>
              </a>
            </li>
          </ul>
        </div>
      </div>
      <!-- SIDEBAR -->

      <!-- CONTENT -->
      <div class="col-md-10 col-sm-11 offset-md-2 offset-sm-1">
        <!-- Header -->
        <div class="p-3 d-flex align-items-center justify-content-between position-fixed bg-light"
          style="width: 82%; z-index: 100">
          <div>
            <span class="fs-4 fw-bold text-primary">POSProcast</span>
          </div>
          <div class="d-flex align-items-center">
            <span class="fs-6"><?php echo $_SESSION['staff_name']; ?></span>
            <ion-icon class="ms-3" size="large" name="person-circle"></ion-icon>
          </div>
        </div>

        <div class="row mt-5">
          <div class="col-md-7 mt-5">
            <!-- Left column -->
            <div class="p-3 bg-light h-100">
              <h4 class="text-primary">Refund Request Form</h4>

              <!-- Refund Form -->
              <div class="p-3 bg-light h-100">
                <form>
                  <div class="row">
                    <!-- Product Code -->
                    <div class="col-md-6 mb-3">
                      <label for="prodCode" class="form-label text-primary">Product Code</label>
                      <input type="text" class="form-control" id="prodCode" v-model="prodCode" required placeholder="Enter Product Code">
                    </div>

                    <!-- Product Name -->
                    <div class="col-md-6 mb-3">
                      <label for="prodName" class="form-label text-primary">Product Name</label>
                      <input type="text" class="form-control" id="prodName" v-model="prodName" required placeholder="Enter Product Name">
                    </div>
                  </div>

                  <div class="row">
                    <!-- Buyer's Name -->
                    <div class="col-md-6 mb-3">
                      <label for="buyerName" class="form-label text-primary">Buyer's Name</label>
                      <input type="text" class="form-control" id="buyerName" v-model="buyerName" required placeholder="Enter Buyer's Name">
                    </div>

                    <!-- Buyer's ID -->
                    <div class="col-md-6 mb-3">
                      <label for="buyerId" class="form-label text-primary">Buyer's ID</label>
                      <input type="text" class="form-control" id="buyerId" v-model="buyerId" required placeholder="Enter Buyer's ID">
                    </div>
                  </div>

                  <!-- Refund Amount -->
                  <div class="mb-3">
                    <label for="refundAmount" class="form-label text-primary">Refund Amount</label>
                    <input type="number" class="form-control" id="refundAmount" v-model="refundAmount" required placeholder="Enter Refund Amount">
                  </div>

                  <!-- Reason for Refund -->
                  <div class="mb-3">
                    <label for="refundReason" class="form-label text-primary">Reason for Refund</label>
                    <textarea class="form-control" id="refundReason" v-model="refundReason" required rows="3" placeholder="Explain the reason for refund"></textarea>
                  </div>

                  <!-- Submit Button -->
                  <div class="mt-4">
                    <button type="submit" class="btn btn-primary w-100" @click.prevent="submitRefund">Submit Refund Request</button>
                  </div>
                </form>
              </div>
              <!-- Refund Form -->
              <!-- Filter Modal -->
              <div class="modal fade" id="filterModal" tabindex="-1" aria-labelledby="filterModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="filterModalLabel">Filter Refunds</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                      <div class="mb-3">
                        <label for="filterProdName" class="form-label">Product Name</label>
                        <input type="text" class="form-control" id="filterProdName" v-model="filterProdName" placeholder="Enter Product Name">
                      </div>
                      <div class="mb-3">
                        <label for="filterAmount" class="form-label">Minimum Amount</label>
                        <input type="number" class="form-control" id="filterAmount" v-model="filterAmount" placeholder="Enter Minimum Amount">
                      </div>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" @click="cancelFilter">Cancel</button>
                      <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Apply Filter</button>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
          <div class="col-md-5 mt-5">
            <!-- Right column  -->
            <div class="p-3 bg-light h-100">
              <!-- Filter Button -->
              <div class="d-flex justify-content-between my-3">
                <h4 class="text-primary">Refund History</h4>

                <button type="button" class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#filterModal">
                  Filter Options
                </button>
              </div>

              <!-- Table -->
              <div class="my-3">
                <table class="table table-striped text-center">
                  <thead class="bg-primary text-white">
                    <tr>
                      <th class="col-2 " scope="col">Refund ID</th>
                      <th class="col-4" scope="col">Product</th>
                      <th class="col-4" scope="col">Amount</th>
                      <!-- <th class="col-2" scope="col">Date</th> -->
                      <th class="col-2" scope="col">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="refund in filteredRefundHistory" :key="refund.refund_id">
                      <td>{{ refund.refund_id }}</td>
                      <td>{{ refund.prod_name }}</td>
                      <td>₱{{ refund.prod_price }}</td>
                      <td>
                        <button type="button" class="btn btn-info btn-sm" @click="viewDetails(refund)">Details</button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <!-- Table -->
            </div>
          </div>
        </div>

        <!-- Modal for Viewing Refund Details -->
        <div class="modal fade" id="refundDetailsModal" tabindex="-1" aria-labelledby="refundDetailsModalLabel"
          aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="refundDetailsModalLabel">Refund Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <p><strong>Refund ID:</strong> {{selectedRefund.refund_id}}</p>
                <p><strong>Product Code:</strong> {{selectedRefund.prod_code}}</p>
                <p><strong>Product:</strong> {{selectedRefund.prod_name}}</p>
                <p><strong>Refund Amount:</strong> ₱{{selectedRefund.prod_price}}</p>
                <p><strong>Reason:</strong> {{selectedRefund.reason}}</p>
                <p><strong>Returnee:</strong> {{selectedRefund.buyer_name}}</p>
                <p><strong>Date:</strong> {{formatDate(selectedRefund.created_at)}}</p>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>

      </div>
      <!-- CONTENT -->
    </div>
  </div>

        <!-- Resources Script -->
        <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/vue@2.7.16/dist/vue.js"></script>
      <!-- Resources Script -->

      <!-- Ionicons -->
      <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
      <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
      <!-- Ionicons -->

  <!-- Vue.js -->
  <script src="https://cdn.jsdelivr.net/npm/vue@2"></script>
  <script>
    new Vue({
      el: '#app',
      data() {
        return {
          prodCode: '',
          prodName: '',
          refundAmount: '',
          refundReason: '',
          buyerName: '',
          buyerId: '',
          filterProdName: '',
          filterAmount: null,
          refundHistory: [], // Ensure this is populated with your refund history data
          selectedRefund: {}
        }
      },
      computed: {
        filteredRefundHistory() {
          return this.refundHistory.filter(refund => {
            const matchesProdName = this.filterProdName ? refund.prod_name.toLowerCase().includes(this.filterProdName.toLowerCase()) : true;
            const matchesAmount = this.filterAmount !== null ? refund.prod_price >= this.filterAmount : true;
            return matchesProdName && matchesAmount;
          });
        }
      },
      methods: {
        cancelFilter(){
          this.filterProdName = '';
          this.filterAmount = null;
        },
        formatDate(dateString) {
          const date = new Date(dateString);

          // Extract the year, month, and day
          const year = date.getFullYear();
          const month = String(date.getMonth() + 1).padStart(2, '0'); // Month is 0-based
          const day = String(date.getDate()).padStart(2, '0');

          // Extract the hours and minutes
          let hours = date.getHours();
          const minutes = String(date.getMinutes()).padStart(2, '0');
          const ampm = hours >= 12 ? 'pm' : 'am';
          hours = hours % 12 || 12; // Convert 24-hour format to 12-hour format

          return `${year}-${month}-${day} ${hours}:${minutes}${ampm}`;
        },
        fetchRefundDetails() {
          axios.post('../php/staff/fetchRefunds.php')
          .then(response => {
            console.log(response.data);
            this.refundHistory = response.data;
          });
        },
        submitRefund() {
          // Logic to submit the form data via an API or form submission
          const refundData = {
            prodCode: this.prodCode,
            prodName: this.prodName,
            refundAmount: this.refundAmount,
            refundReason: this.refundReason,
            buyerName: this.buyerName,
            buyerId: this.buyerId,
          };

          axios.post('../php/staff/addRefund.php', refundData)
            .then(response => {
              if (response.data.success) {
                alert('Refund request submitted successfully.');n
                this.clearForm();
                this.fetchRefundDetails;
              } else {
                alert('Failed to submit refund request.');
              }
            });
        },
        clearForm() {
          this.prodCode = '';
          this.prodName = '';
          this.refundAmount = '';
          this.refundReason = '';
          this.buyerName = '';
          this.buyerId = '';
        },
        viewDetails(refund) {
          this.selectedRefund = refund;
          const modal = new bootstrap.Modal(document.getElementById('refundDetailsModal'));
          modal.show();
        },
        logout() {
          if (confirm('Are you sure you want to log out?')) {
            axios.post('../php/staff/logout.php')
              .then(response => {
                if (response.status === 200) {
                  window.location.href = '../'; // Redirect to the home page
                } else {
                  console.error('Logout failed:', response);
                }
              })
              .catch(error => {
                console.error('Logout error:', error);
              });
          } else {
            console.log('Logout cancelled by user.');
          }
        },
      },
      mounted() {
       this.fetchRefundDetails();
      }
    });
  </script>
  <!-- Vue.js -->

</body>

</html>