<?php
class thermal_printer
{
    const CHARS_PER_LINE = 32;
    const NEWLINE        = "\x0A";
    const TRAIL_SPACE    = "\x1B\x4A\x9B";

    var $handle;

    function __construct($path) {
        if (!file_exists($path)) {
            throw new Exception("Printer path does not exist: $path");
        }

        $this->handle = fopen($path, "w");

        if (!$this->handle) {
            throw new Exception("Failed to open printer path: $path");
        }
    }

    function print_string($string, $newline = TRUE){
        if ($this->handle) {
            fwrite($this->handle, $string);
            $this->print_newline($newline);
        }
    }

    function print_centered_string($string, $newline = TRUE){
        if ($this->handle) {
            $len = strlen($string);
            $diff = (self::CHARS_PER_LINE - $len) / 2;

            for($i = 0; $i < $diff; $i++){
                fwrite($this->handle, " ");
            }

            fwrite($this->handle, $string);

            for($i = 0; $i < $diff; $i++){
                fwrite($this->handle, " ");
            }

            $this->print_newline($newline);
        }
    }

    function print_rule($char = '*', $newline = TRUE){
        if ($this->handle) {
            for($i = 0; $i < self::CHARS_PER_LINE; $i++){
                fwrite($this->handle, $char);
            }
            $this->print_newline($newline);
        }
    }

    function print_cart_item($left_string, $right_string, $newline = TRUE){
        if ($this->handle) {
            $l_len = strlen($left_string);
            $r_len = strlen($right_string);
            $total_length = $l_len + $r_len;

            if($total_length <= self::CHARS_PER_LINE){
                $diff = self::CHARS_PER_LINE - $total_length;

                fwrite($this->handle, $left_string);

                for($i = 0; $i < $diff; $i++){
                    fwrite($this->handle, " ");
                }

                fwrite($this->handle, $right_string);
            } else {
                $diff = self::CHARS_PER_LINE - $total_length - 5;
                $left_string = substr($left_string, 0, $diff);
                $left_string .= "...";

                $this->print_cart_item($left_string, $right_string, $newline);
                return;
            }

            $this->print_newline($newline);
        }
    }

    function print_newline($bool){
        if ($this->handle && $bool){
            fwrite($this->handle, self::NEWLINE);
        }
    }

    function print_trail_space(){
        if ($this->handle){
            fwrite($this->handle, self::TRAIL_SPACE);
        }
    }
}
?>
