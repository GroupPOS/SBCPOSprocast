<?php
require '../database/db_conn.php';



// SQL query to fetch orders
$sql = "SELECT  p.prod_name, r.*
FROM products as p
INNER JOIN ratings as r
ON p.prod_id = r.prod_id
ORDER BY r.rated_at DESC" ;
$stmt = $conn->prepare($sql);
$stmt->execute();

// Fetching orders
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Close the connection
$conn = null;

// Convert the aggregated data to JSON
$jsonData = json_encode($orders);

echo $jsonData;
