<?php
session_start();

// Check if the session variable 'user_id' is set
if (!isset($_SESSION['user_id'])) {
  // If not set, redirect to the home page or any other page
  header("Location: ../");
  exit();
}
?>
<!DOCTYPE html>
<html class="h-100" lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="../assets/sbc_icon.gif">

  <title>Inventory | Cart</title>

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
    crossorigin="anonymous"></script>
  <!-- Bootstrap 5 -->

  <!-- CSS -->
  <link href="../css/sidebar.css" rel="stylesheet">

</head>
<style>
  .btn-square {
    width: 170px;
    height: 150px;
    text-align: center;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  /* Sidebar styles */
  #sidebar {
    background-color: #1167b1;
    transition: transform 0.3s ease;
  }

  /* Initially hide the sidebar on small screens */
  @media (max-width: 768px) {
    #sidebar {
      transform: translateX(-100%);
      position: fixed;
      z-index: 999;
    }

    .sidebar-visible #sidebar {
      width: 20%;
      transform: translateX(0);
    }
    #content{
      padding:0;
      width: 100%;

    }
    .sidebar-visible #content{
      transition: transform 0.3s ease;
      margin-left: 20%;
    }
  }

  /* Hamburger icon styles */
  .hamburger {
    display: none;
  }

  @media (max-width: 768px) {
    .hamburger {
      display: block;
      font-size: 1.5rem;
      cursor: pointer;
      margin-left: 5px;
      margin-right: 10px;
    }
  }
  @media (max-width: 400px) {
    #username{
      display: none;
    }
  }
  /* Ensure content adjusts when sidebar is hidden */
  @media (max-width: 768px) {
    .content {
      padding-left: 0;
    }
  }
</style>

<body class="h-100">

  <div class="container-fluid h-100" id="app">
    <div class="row h-100">

      <!-- SIDEBAR -->
      <div class="col-md-2 col-sm-1 col-12 d-flex flex-column flex-shrink-0 h-100 p-3 text-white position-fixed"
        id="sidebar">
        <div class="d-flex justify-content-between align-items-center">
          <a href="" class="d-flex align-items-center text-white text-decoration-none">
            <ion-icon size="large" class="bi me-3 ms-2" width="40" height="32" name="happy-outline"></ion-icon>
            <span class="d-none d-md-inline fs-4">User Profile</span>
          </a>
        </div>
        <hr>
        <ul class="nav nav-pills flex-column mb-auto">
          <li class="nav-item mb-2">
            <a href="./userDash" class="nav-link text-white" aria-current="page">
              <ion-icon class="bi me-2" name="home"></ion-icon>
              <span class="d-none d-md-inline">Home</span>
            </a>
          </li>
          <li class="mb-2">
            <a href="" class="nav-link active">
              <ion-icon class="bi me-2" name="cart"></ion-icon>
              <span class="d-none d-md-inline">Cart</span>
            </a>
          </li>
          <li class="mb-2">
            <a href="./userTransaction" class="nav-link text-white">
              <ion-icon class="bi me-2" name="newspaper"></ion-icon>
              <span class="d-none d-md-inline">Transaction</span>
            </a>
          </li>
          <li class="mb-2">
            <a href="./userSettings" class="nav-link text-white">
              <ion-icon class="bi me-2" name="settings"></ion-icon>
              <span class="d-none d-md-inline">Settings</span>
            </a>
          </li>
        </ul>
        <div class="mt-auto">
          <hr>
          <ul class="nav nav-pills flex-column">
            <li>
              <a href="#" @click="logout" class="nav-link text-white">
                <ion-icon class="bi me-2" name="log-out"></ion-icon>
                <span class="d-none d-md-inline">Log Out</span>
              </a>
            </li>
          </ul>
        </div>
      </div>
      <!-- SIDEBAR -->


      <!-- CONTENT -->
      <div class="col-md-10 col-sm-11 offset-md-2 offset-sm-1" id="content">
        <!-- Modal -->
        <div class="modal fade" id="checkoutModal" tabindex="-1" aria-labelledby="checkoutModalLabel"
          aria-hidden="true">
          <div class="modal-dialog modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="checkoutModalLabel">Confirm Checkout?</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body d-flex justify-content-around py-5">
                <button type="button" class="btn btn-secondary btn-lg " id="qrCheckoutButton" data-bs-dismiss="modal"
                  @click="handleQRCheckout">Confirm Checkout</button>
                <button type="button" class="btn btn-danger btn-lg " id="qrCheckoutButton"
                  data-bs-dismiss="modal">Cancel Checkout</button>
              </div>
            </div>
          </div>
        </div>
        <!-- Header -->
        <!-- Hamburger icon for small screens -->
        <div class="d-flex align-items-center justify-content-between p-3 bg-light">
          <div style="display:flex; width: fit-content; align-items:center;">
            <div class="hamburger"  @click="toggleSidebar">
              <ion-icon name="menu-outline"></ion-icon>
            </div>
            <div>
              <span class="fs-4 text-primary"><strong>POSProcast</strong></span>
            </div>
          </div>
          
          <div class="d-flex align-items-center">
            <span class="fs-6" id="username"><?php echo $_SESSION['user_name']; ?></span>
            <ion-icon class="ms-3" size="large" name="person-circle"></ion-icon>
          </div>
        </div>
        <!-- Header -->
        
        <div class="px-4 pt-4 pb-4 mt-5">
          <!-- Store status alert -->
          <div v-if="!storeStatus" class="alert alert-warning d-flex align-items-center gap-2" role="alert">
            <ion-icon name="warning-outline" style="font-size:20px; font-weight:bold;"></ion-icon>
            <div>
              The store is currently <strong>closed</strong>. Checkout unavailable.
            </div>
          </div>
          <!-- Store status alert -->
          <!-- Search Input Field -->
          <div class="row g-0 align-items-center">
            <div class="col-md-6 d-flex align-items-center justify-content-start">
              <!-- <div class="input-group">
                <input type="text" class="form-control" placeholder="Search Product..." aria-label="Search" aria-describedby="button-addon2">
                <button class="btn btn-primary" type="button" id="button-addon2"><ion-icon name="search"></ion-icon></button>
            </div> -->
              <h2 class="text-primary">My Cart</h2>
            </div>
            <!-- Search Input Field -->

            <div class="col-md-6 d-flex justify-content-end align-items-center gap-2">
              <button class="btn btn-primary" type="button" @click="selectAllProducts">{{ selectAllText }}</button>
              <button class="btn btn-secondary" type="button" @click="deleteSelectedItems">Delete Selected</button>

            </div>
          </div>
        </div>
        <!-- Table -->
        <!-- Alert Message -->
        <div v-if="showAlert" class="px-4">
          <div v-if="showAlert" class="alert mt-2" :class="'alert-' + alertType" role="alert">
            {{ alertMessage }}
          </div>
        </div>
        <!-- Alert Message -->
        <div class="table-responsive px-4">
          <table class="table table-striped text-center" v-if="allCart.length > 0">
            <thead class="bg-primary text-white">
              <tr>
                <th class="col-1" scope="col"></th>
                <!-- <th class="col-2" scope="col">Product Code</th> -->
                <th colspan="2" class="col-5" scope="col">Description</th>
                <th class="col-2" scope="col">Price</th>
                <th class="col-2" scope="col">QTY</th>
                <th class="col-2" scope="col">Total Price</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(data, index) in allCart" :key="data.prod_id">
                <th scope="row">
                  <!-- Bind checkbox to the selected property -->
                  <input class="form-check-input" type="checkbox" v-model="data.selected"
                    @change="updateOverallTotalPrice" />
                </th>
                <!-- <td>{{ data.barcode }}</td> -->
                <td colspan="2" >{{ data.prod_name }}</td>
                <td>₱{{ data.prod_price }}</td>
                <td>
                    <div class="px-2">
                      <input type="number" v-model.number="data.qty" min="0" class="form-control form-control-sm"
                        @input="handleQtyInput(index)" />
                    </div>
                  </td>
                <!-- Calculate total price per row -->
                <td>₱{{ totalPricePerRow(data) }}</td>
              </tr>
            </tbody>
            <tfoot class="bg-primary text-white">
              <tr>
                <td colspan="5" class="text-start">
                  <div class="d-flex align-items-center">
                    <div class="px-4 border-end border-3">
                      Overall Price <br>
                      <h4>₱{{ overallTotalPrice }}</h4>
                    </div>
                    <div class="px-4" style="font-size: 12px">
                      Checkout using QR <br>
                      and proceed to counter
                    </div>
                  </div>
                </td>
                <td colspan="1">
                  <!-- Disable Checkout Button when no items are selected -->
                  <button type="button" class="btn btn-light" data-bs-toggle="modal" data-bs-target="#checkoutModal"
                    :disabled="!anyItemSelected || !storeStatus">
                    Checkout
                  </button>
                </td>
              </tr>
            </tfoot>
          </table>

          <!-- No Items Found Message -->
          <div v-else class="text-center py-5">
            <h4>No Items Found</h4>
          </div>
        </div>

        <!-- Table -->
      </div>
      <!-- CONTENT -->

    </div>
  </div>

  <!-- Resources Script -->
  <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/vue@2.7.16/dist/vue.js"></script>
  <!-- Resources Script -->

  <!-- Ionicons -->
  <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
  <!-- Ionicons -->

  <script>
    new Vue({
      el: '#app',
      data: {
        user: <?php echo json_encode($_SESSION['user_id']); ?>,
        name: <?php echo json_encode($_SESSION['user_name']); ?>,
        allCart: [],
        alertMessage: '',
        alertType: '',
        storeStatus:false,
        showAlert: false,
        selectAll: false,
        sidebarVisible: false,
      },
      computed: {
        // Compute the overall total price based on selected rows
        overallTotalPrice() {
          return this.allCart.reduce((acc, item) => {
            if (item.selected) {
              return acc + item.qty * item.prod_price;
            }
            return acc;
          }, 0).toFixed(2);
        },
        // Determine if any item is selected
        anyItemSelected() {
          return this.allCart.some(item => item.selected);
        },
        // Determine the text for the Select All button
        selectAllText() {
          return this.selectAll ? "Deselect All" : "Select All";
        }
      },
      methods: {
        fetchStoreStatus(){
          axios.post('../php/admin/fetchStoreStatus.php')
          .then(response => {
            console.log(response.data.status);
            this.storeStatus = response.data.status;
          });
        },
        toggleSidebar() {
          this.sidebarVisible = !this.sidebarVisible;
          document.body.classList.toggle('sidebar-visible', this.sidebarVisible);
        },
        showAlertMessage(type, message) {
          this.alertType = type;
          this.alertMessage = message;
          this.showAlert = true;
          setTimeout(() => {
            this.showAlert = false;
          }, 3000);  // Hide alert after 3 seconds
        },
        getAllCart() {
          axios.post('../php/user/getCart.php', {
            user_id: this.user,
          }).then(response => {
            console.log(response.data);
            // Set default qty to 1 and selected to false for all items
            this.allCart = response.data.map(item => ({ ...item, qty: 1, selected: false }));
          });
        },
        // Method to calculate total price per row
        totalPricePerRow(data) {
          return (data.qty * data.prod_price).toFixed(2);
        },
        handleQtyInput(index) {
          if (this.allCart[index].qty < 0) {
            this.allCart[index].qty = 0; // Ensure qty is never negative
          }
          this.updateTotalPrice(index); // Call the existing method to update total price
        },
        // Update total price when quantity changes
        updateTotalPrice(index) {
          this.$forceUpdate(); // Force reactivity update
        },
        // Update the overall total price whenever selection changes
        updateOverallTotalPrice() {
          this.$forceUpdate(); // Force reactivity update
        },
        // Select or Deselect All Products
        selectAllProducts() {
          this.selectAll = !this.selectAll;
          this.allCart.forEach(item => item.selected = this.selectAll);
          this.updateOverallTotalPrice();
        },
        deleteSelectedItems() {
          const selectedItems = this.allCart.filter(item => item.selected);
          if (selectedItems.length === 0) {
            alert("No items selected for deletion.");
            return;
          }

          // Send the IDs of selected items to the server for deletion
          const idsToDelete = selectedItems.map(item => item.prod_id);
          axios.post('../php/user/deleteCart.php', {
            user_id: this.user,
            product_ids: idsToDelete
          }).then(response => {
            if (response.data.success) {
              this.allCart = this.allCart.filter(item => !item.selected);
              // alert("Selected items have been deleted.");
            } else {
              alert("An error occurred while deleting the items.");
            }
          }).catch(error => {
            console.error(error);
            alert("An error occurred while deleting the items.");
          });
        },
        async handleQRCheckout() {
          const selectedItems = this.allCart.filter(item => item.selected);
          if (selectedItems.length === 0) {
            this.showAlertMessage('danger', "No items selected for checkout.");
            return;
          }

          // Generate a unique transaction number
          const transactionNumber = this.generateTransactionNumber();

          // Prepare data to send
          const orderData = selectedItems.map(item => ({
            order_id: transactionNumber,
            user_id: this.user,
            user_name: this.name,
            prod_id: item.prod_id,
            prod_qty: item.qty,
            prod_name: item.prod_name,
            prod_price: item.prod_price,
            prod_image: item.prod_image,
            total_price: item.qty * item.prod_price,
            ordered_at: new Date().toISOString().slice(0, 19).replace('T', ' '), // Current timestamp
            overall_total: this.overallTotalPrice,
            status: 'pending'
          }));

          try {
            const response = await axios.post('../php/user/submitOrder.php', {
              orders: orderData
            });
            if (response.data.success) {

              this.deleteSelectedItems();
              this.showAlertMessage('success', "Order submitted successfully! Go to transaction to view orders.");

              // Optionally, you can redirect or clear the cart
              this.allCart = this.allCart.filter(item => !item.selected);
            } else {
              this.showAlertMessage('danger', response.data.message);

            }
          } catch (error) {
            console.error(error);
            this.showAlertMessage('danger', "An error occurred while submitting the order.");
          }
        },

        generateTransactionNumber() {
          // Get the current timestamp in milliseconds
          const timestamp = Date.now(); // Unix timestamp in milliseconds

          // Generate a random number between 1000 and 9999
          const randomNum = Math.floor(100000 + Math.random() * 900000);
          // Concatenate the parts to form a unique transaction number
          return `${randomNum}${this.user}`;
        },
        logout() {

          if (confirm('Are you sure you want to log out?')) {
            axios.post('../php/user/logout.php')
              .then(response => {
                // Check if the response indicates success or handle according to your needs
                if (response.status === 200) {
                  // Redirect to home page or refresh the current page
                  window.location.href = '../'; // Redirect to the home page
                  // or use the following line to simply refresh the page
                  // window.location.reload();
                } else {
                  // Handle errors or unsuccessful logout if needed
                  console.error('Logout failed:', response);
                }
              })
              .catch(error => {
                // Handle network or other errors
                console.error('Logout error:', error);
              });
          } else {
            // If the user cancels, do nothing
            console.log('Logout cancelled by user.');
          }
        }

      },
      created() {
        this.fetchStoreStatus();
        this.getAllCart();
      }
    });
  </script>

</body>

</html>
