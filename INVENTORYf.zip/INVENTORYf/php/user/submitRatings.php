<?php
require '../database/db_conn.php';


session_start();

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Check if input is valid
if (is_array($input) && isset($input['ratings'])) {
    $ratings = $input['ratings'];

    try {
        // Begin transaction
        $conn->beginTransaction();

        foreach ($ratings as $rating) {
            // Check if the necessary fields are set
            if (isset($rating['prod_id']) && isset($rating['prod_rate'])) {
                $prod_id = $rating['prod_id'];
                $prod_rate = $rating['prod_rate'];

                // Insert rating into the 'ratings' table
                $stmt = $conn->prepare("INSERT INTO ratings (prod_id, prod_rate) VALUES (?, ?)");
                $stmt->execute([$prod_id, $prod_rate]);
            } else {
                echo json_encode(['success' => false, 'message' => "Missing required fields: prod_id or prod_rate"]);
                exit;
            }
        }

        // Commit the transaction for ratings
        $conn->commit();

        // Insert log entry for rating submission
        $logStmt = $conn->prepare("
            INSERT INTO logs (user_type, user_name, user_id, log_type, log_info) 
            VALUES (:user_type, :user_name, :user_id, :log_type, :log_info)
        ");

        $user_id = $_SESSION['user_id'];
        $user_name = $_SESSION['user_name'];
        $user_type = 'user';
        $log_type = 'rating_submission';
        $log_info = $user_name . " submitted ratings for product IDs: " . implode(", ", array_column($ratings, 'prod_id'));

        $logStmt->bindParam(':user_type', $user_type );
        $logStmt->bindParam(':user_name', $user_name);
        $logStmt->bindParam(':user_id', $user_id);
        $logStmt->bindParam(':log_type', $log_type);
        $logStmt->bindParam(':log_info', $log_info);

        if ($logStmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Ratings submitted and log created']);
        } else {
            echo json_encode(['success' => true, 'message' => 'Ratings submitted but log creation failed']);
        }
    } catch (PDOException $e) {
        $conn->rollBack();
        echo json_encode(['success' => false, 'message' => "Failed to submit ratings: " . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => "Invalid input"]);
}
