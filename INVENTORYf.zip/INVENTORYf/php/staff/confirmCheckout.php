<?php
session_start(); // Start the session

require '../database/db_conn.php';

// Receive data from the request body
$received_data = json_decode(file_get_contents("php://input"), true);

// Extract common data
$order_id = $received_data['order_id'];
$status = 'completed';

// Retrieve user information from session
$user_id = $_SESSION['staff_id'] ?? null;
$user_name = $_SESSION['staff_name'] ?? null;

if (empty($order_id) || empty($user_id) || empty($user_name)) {
    echo json_encode(['status' => 'error', 'message' => 'Order ID, user ID, and user name are required']);
    exit;
}

try {
    $conn->beginTransaction(); // Start a transaction

    // Retrieve order details from the orders table based on the order_id
    $query = "SELECT * FROM orders WHERE order_id = :order_id";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':order_id', $order_id);
    $stmt->execute();
    $orderDetails = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!$orderDetails) {
        echo json_encode(['status' => 'error', 'message' => 'Order not found']);
        $conn->rollBack();
        exit;
    }

    // Prepare and execute the SQL query to insert into the sales table
    $insertStmt = $conn->prepare("INSERT INTO sales (order_id, user_id, user_name, prod_id, prod_qty, prod_name, prod_price, prod_image, total_price, overall_total, status) 
                                VALUES (:order_id, :user_id, :user_name, :prod_id, :prod_qty, :prod_name, :prod_price, :prod_image, :total_price, :overall_total, :status)");

    // Loop through each product and insert a record
    foreach ($orderDetails as $order) {
        $prod_id = $order['prod_id'];
        $prod_qty = $order['prod_qty'];
        $prod_name = $order['prod_name'];
        $prod_price = $order['prod_price'];
        $prod_image = $order['prod_image'] ?? ''; // Default to empty if not provided
        $total_price = $order['total_price'];
        $overall_total = $order['overall_total'];

        // Bind parameters and execute the insert query
        $insertStmt->bindParam(':order_id', $order_id);
        $insertStmt->bindParam(':user_id', $user_id);
        $insertStmt->bindParam(':user_name', $user_name);
        $insertStmt->bindParam(':prod_id', $prod_id);
        $insertStmt->bindParam(':prod_qty', $prod_qty);
        $insertStmt->bindParam(':prod_name', $prod_name);
        $insertStmt->bindParam(':prod_price', $prod_price);
        $insertStmt->bindParam(':prod_image', $prod_image);
        $insertStmt->bindParam(':total_price', $total_price);
        $insertStmt->bindParam(':overall_total', $overall_total);
        $insertStmt->bindParam(':status', $status);

        $insertStmt->execute();

        // Update the product quantity in the products table
        $updateProdStmt = $conn->prepare("UPDATE products SET prod_qty = prod_qty - :prod_qty WHERE prod_id = :prod_id AND prod_qty >= :prod_qty");
        $updateProdStmt->bindParam(':prod_qty', $prod_qty);
        $updateProdStmt->bindParam(':prod_id', $prod_id);
        $updateProdStmt->execute();
    }

    // Update the order status to 'completed'
    $updateStmt = $conn->prepare("UPDATE orders SET status = :status WHERE order_id = :order_id");
    $updateStmt->bindParam(':status', $status);
    $updateStmt->bindParam(':order_id', $order_id);
    $updateStmt->execute();

    // Log the transaction with log type 'qr checkout'
    $log_type = 'qr checkout';
    $log_info = "Order ID: $order_id, Total: $overall_total";

    $logStmt = $conn->prepare("INSERT INTO logs (user_type, user_name, user_id, log_type, log_info) VALUES (?, ?, ?, ?, ?)");
    $logStmt->execute(['staff', $user_name, $user_id, $log_type, $log_info]);

    $conn->commit(); // Commit the transaction

    echo json_encode(['status' => 'success', 'message' => 'Payment confirmed, records inserted, and stock updated successfully.']);
} catch(PDOException $e) {
    $conn->rollBack(); // Roll back the transaction on error
    echo json_encode(['status' => 'error', 'message' => 'Failed to insert records: ' . $e->getMessage()]);
}
