<?php
session_start(); // Ensure session is started before usage

require '../database/db_conn.php';


// Get data from the Vue.js request
$data = json_decode(file_get_contents("php://input"), true);
$userId = $data['id'];
$fname = $data['fname'];
$lname = $data['lname'];
$password = $data['password'];


// Check if the user ID already exists
$sql = "SELECT * FROM users WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->execute([$userId]);

if ($stmt->rowCount() > 0) {
    // Log failed signup attempt
    insertLoginLog($conn, "user", "Anonymous" , " ", "Signup", "failed - user ID exists");

    echo json_encode(["message" => "User ID already exists"]);
    exit();
}

// Hash the password
$hashed_password = password_hash($password, PASSWORD_BCRYPT);

// Insert the new user into the database
$sql = "INSERT INTO users (user_id, firstName, lastName, password, status, role) VALUES (?, ?, ?, ?, 'pending', 'user')";
$stmt = $conn->prepare($sql);

if ($stmt->execute([$userId, $fname, $lname, $hashed_password])) {
    // Log successful signup attempt
    insertLoginLog($conn, "user", "Anonymous" , " ", "Signup", "successful");

    echo json_encode(["message" => "Registration successful", "signup" => "yes"]);
} else {
    // Log failed signup attempt due to error
    insertLoginLog($conn,  "user", "Anonymous" , " ", "Signup", "failed - error");

    echo json_encode(["message" => "Error: " . $stmt->errorInfo()[2]]);
}

// Function to insert logs for signup attempts
function insertLoginLog($conn, $user_type, $user_name, $user_id, $log_type, $log_info) {
    try {
        $logStmt = $conn->prepare("INSERT INTO logs (user_type, user_name, user_id, log_type, log_info) VALUES (?, ?, ?, ?, ?)");
        $logStmt->execute([$user_type, $user_name, $user_id, $log_type, $log_info]);
    } catch (PDOException $e) {
        // Handle error if logging fails
        error_log('Error logging login action: ' . $e->getMessage());
    }
}

