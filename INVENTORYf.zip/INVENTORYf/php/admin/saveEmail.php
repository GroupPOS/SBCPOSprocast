<?php
require '../database/db_conn.php';


// Function to update the email
function updateEmail($conn, $data) {
    // Extract data from the passed array
    $email = filter_var($data['email'], FILTER_VALIDATE_EMAIL); // Validate email format
    $id = $data['id'];

    // Check if the email is valid
    if ($email === false) {
        return ['success' => false, 'message' => 'Invalid email format'];
    }

    // Prepare the SQL statement for updating
    $sql = "UPDATE email SET email = :email WHERE id = :id"; 

    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT); // Bind ID securely

    if ($stmt->execute()) {
        return ['success' => true, 'message' => 'Email updated successfully'];
    } else {
        return ['success' => false, 'message' => 'Failed to update email'];
    }
}

// Example usage
$received_data = json_decode(file_get_contents("php://input"), true); // Parse JSON request

if (!empty($received_data['email']) && !empty($received_data['id'])) {
    $result = updateEmail($conn, $received_data);

    // Log the email update action
    try {
        session_start();
        $admin_id = $_SESSION['admin_id'];
        $admin_name = $_SESSION['admin_name'];
        $log_type = 'update_email';
        $log_info = "Admin \"$admin_name\" updated the email for User ID: " ;

        $logStmt = $conn->prepare("
            INSERT INTO logs (user_type, user_name, user_id, log_type, log_info) 
            VALUES ('admin', :admin_name, :admin_id, :log_type, :log_info)
        ");
        $logStmt->bindParam(':admin_name', $admin_name);
        $logStmt->bindParam(':admin_id', $admin_id);
        $logStmt->bindParam(':log_type', $log_type);
        $logStmt->bindParam(':log_info', $log_info);

        if (!$logStmt->execute()) {
            throw new PDOException("Failed to insert log entry");
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => "Logging error: " . $e->getMessage()]);
    }

    echo json_encode($result);
} else {
    echo json_encode(['error' => 'Required fields are missing in the request']);
}

// Close the connection
$conn = null;
