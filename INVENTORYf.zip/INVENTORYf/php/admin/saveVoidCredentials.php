<?php
require '../database/db_conn.php';

// Function to update void credentials
function updateVoidCredentials($conn, $data) {
    // Extract and validate data
    $username = trim($data['username']);
    $password = trim($data['password']);
    $id = filter_var($data['id'], FILTER_VALIDATE_INT); 

    if (!$id) {
        return ['success' => false, 'message' => 'Invalid ID'];
    }

    // Hash the password securely before updating
    $hashedPassword = $password;

    // Prepare the SQL statement for updating
    $sql = "UPDATE void SET user_name = :username, password = :password WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $hashedPassword); // Store the hashed password
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);

    if ($stmt->execute()) {
        return ['success' => true, 'message' => 'Void credentials updated successfully'];
    } else {
        return ['success' => false, 'message' => 'Failed to update void credentials'];
    }
}

// Example usage
$received_data = json_decode(file_get_contents("php://input"), true); // Parse JSON as an associative array

if (!empty($received_data['username']) && !empty($received_data['password']) && !empty($received_data['id'])) {
    $result = updateVoidCredentials($conn, $received_data);

    // Log the action
    try {
        session_start();
        $admin_id = $_SESSION['admin_id'];
        $admin_name = $_SESSION['admin_name'];
        $log_type = 'update_void_credentials';
        $log_info = "Admin \"$admin_name\" updated void credentials for user ID: ";

        $logStmt = $conn->prepare("
            INSERT INTO logs (user_type, user_name, user_id, log_type, log_info) 
            VALUES ('admin', :admin_name, :admin_id, :log_type, :log_info)
        ");
        $logStmt->bindParam(':admin_name', $admin_name);
        $logStmt->bindParam(':admin_id', $admin_id);
        $logStmt->bindParam(':log_type', $log_type);
        $logStmt->bindParam(':log_info', $log_info);

        if (!$logStmt->execute()) {
            throw new PDOException("Failed to insert log entry");
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => "Logging error: " . $e->getMessage()]);
    }

    echo json_encode($result);
} else {
    echo json_encode(['error' => 'Required fields are missing in the request']);
}

// Close the connection
$conn = null;
?>
